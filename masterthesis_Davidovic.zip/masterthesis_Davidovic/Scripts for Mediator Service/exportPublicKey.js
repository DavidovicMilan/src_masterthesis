const debugMode = true;

const path = require('path');
const fs = require('fs');
const solc = require('solc')
const keyth = require('keythereum-node');
const Web3 = require('web3');
const crypto = require('crypto');
const ecies = require('standard-ecies');


const keystorePath = "/Users/milandavidovic/masterthesis/localNode/private";
const keyPairFolder = "/Users/milandavidovic/masterthesis/localNode/keyPairsForEncryption/";
const localNodeFolder = "/Users/milandavidovic/masterthesis/localNode/";
const url = "http://localhost:8545";
const contractName = 'DeployKey.sol';
const addressFileName = 'contractAddresses.json';
const publicKeyFileName = 'publicKeys.json';
const keyType = 'secp256k1';

var accountNumber = "";
var password = "";
var sphereId = "";
var publicKeysObject;


// ###########################################################
// RUNNING MAIN()
// ###########################################################
main();
// ###########################################################
// ###########################################################

async function main(){
let methodName = ">>> [main]: ";
  // ##################################
  // ############ MAIN ################
  // ##################################

  try{
      checkInputParameters();
      debug(methodName + "Account Number entered > " + accountNumber);
      debug(methodName + "Password entered > " + password);
      console.log("######## Contract Call started... ########");
      var instance = createInstance(url);
      debug(methodName + "Instance successfully retrieved!");
      var accountAddress = await getAccountAddress(accountNumber,instance);
      debug(methodName + "Account Address successfully retrieved!");
      if(!checkIfPublicKeyExists(accountAddress)){
        debug(methodName + "Public Key is not present in the Shared-File!");
        var publicKey = await addPublicKey(accountAddress,password);
        debug(methodName + "Public Key " + publicKey + " successfully added to file!");
      }else{
        debug(methodName + "Public Key is already present in the Shared-File!");
      }
      console.log("######## Call finished! ########");
  }catch(e) {
    console.log(e);
    throw e;
  }
}

// ###########################################################
// ################### HELPER METHODS ########################
// ###########################################################

function checkInputParameters(){
let methodName = ">>> [checkInputParameters]: ";

    if(process.argv[2] == null || process.argv[3] == null){
      console.log(">> Please provide parameters when calling the Script! par1 = <Number of the account> par2 = <Your Password>")
      process.exit(1);
    }else{
      accountNumber = process.argv[2];
      password = process.argv[3];
      debug(methodName + "Parameter-Check successful!");
    }
}

function checkIfPublicKeyExists(address){
let methodName = ">>> [checkIfPublicKeyExists]: ";

  var exists = false;
  var dir = fs.readdirSync(localNodeFolder);
  dir.forEach(function(file) {
    if(publicKeyFileName == file){
      exists = true;
    }
  })

  if(!exists){
    // initialise the object with the array in it.
    // used for the first time creation of the JSON file
    publicKeysObject =  { publicKeys: [] };
    fs.writeFileSync(localNodeFolder + publicKeyFileName, JSON.stringify(publicKeysObject), function(err) {
      if(err) {
        return console.log(err);
      }
    });
  }else{
    // JSON File already exists - read it and push the new key-pair
    var data = fs.readFileSync(localNodeFolder + publicKeyFileName, function (err, data) {
      return data;
    });
    publicKeysObject = JSON.parse(data);

    for(key in publicKeysObject.publicKeys){
      if(publicKeysObject.publicKeys[key].accountAddress == address){
        return true;
      }
    }
  }
  return false;
}

async function addPublicKey(address,password){
let methodName = ">>> [addPublicKey]: ";

  try{

    var privateKey = await importPrivateKey(address,password);
    var ecdh = crypto.createECDH(keyType);
    ecdh.setPrivateKey(privateKey);
    var publicKey = ecdh.getPublicKey();

    publicKeysObject.publicKeys.push({accountAddress: address, publicKey: publicKey.toString('hex')});
    fs.writeFileSync(localNodeFolder + publicKeyFileName, JSON.stringify(publicKeysObject), function(err) {
      if(err) {
        return console.log(err);
      }
    });

    return publicKey;

  }catch(e){
    throw e;
  }
}


function createInstance(url){
let methodName = ">>> [createInstance]: ";

  web3 = new Web3(new Web3.providers.HttpProvider(url));
  debug(methodName + "Instance created!");
  return web3;
}

async function getAccountAddress(accountNumber,instance){
let methodName = ">>> [getAccountAddress]: ";
  try{

    var accounts = await instance.eth.getAccounts();
    debug(methodName + "Address found > " + accounts[accountNumber]);
    return accounts[accountNumber];

  }catch(e){
    console.log(e);
  }
}

async function importPrivateKey(address,password) {
let methodName = ">>> [importPrivateKey]: ";
  try{

      var keyObject = await keyth.importFromFile(address, keystorePath).then(keyObject => {
        return keyObject;
      }).catch(err => {
        console.log(err);
      });

      var privateKey = await keyth.recover(password, keyObject).then(privateKey => {
        return privateKey;
      }).catch(err => {
        console.log(err);
      });

      return privateKey;

    }catch(e) {
      console.log(e);
      throw e;      // let caller know the promise was rejected with this reason
    }
}

function debug(message){
  if(debugMode==true){
    console.log(message);
  }
}
