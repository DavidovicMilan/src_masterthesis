const Web3 = require('web3');
const fs = require('fs');
const solc = require('solc');
const path = require('path');

const url = "http://localhost:8545";
const wsUrl = "ws://localhost:8546";

const password = "password";
const contractAddressFileName = "dataContractAddress.json";
const contractName = 'DataInterpreter.sol';
const localNodeFolder = "/Users/milandavidovic/masterthesis/localNode/";
const publicKeyFileName = 'publicKeys.json';


// async reading of directory
const readDir = (path, opts = 'utf8') =>
  new Promise((resolve, reject) => {
    fs.readdir(path, opts, (err, data) => {
      if (err){
        reject(err)
      }else{
        resolve(data)
      }  
    })
  });

const readFile = (path, opts = 'utf8') =>
  new Promise((resolve, reject) => {
    fs.readFile(path, opts, (err, data) => {
      if (err){
        reject(err)
      }else{
        resolve(data)
      }  
    })
  });

  const writeFile = (path, data) =>
  new Promise((resolve, reject) => {
    fs.writeFile(path, data, (err, data) => {
      if (err){
        reject(err)
      }else{
        resolve(data)
      }  
    })
  });

  class ChainClient {

    constructor(){
        this.webInstance = null;
        this.activeContract = null;
        this.publicKeys = null;
    }

    get getContract(){
        return this.activeContract;
    }

    get getPublicKeys(){
        return this.publicKeys;
    }

    async initializeClient(){

      this.instance = await createInstance(url);
      this.webInstance = new Web3(new Web3.providers.WebsocketProvider((wsUrl)));
      this.minerAddress = await getAccountAddress(0, this.instance);
      this.activeContract = await getActiveContract(this.webInstance, this.minerAddress);
      this.publicKeys = await getAllPublicKeys();

    }

    async getUnlockedAccountAddress(_userNumber){
      return await getAccountAddress(_userNumber, this.instance);
    }

}

module.exports = ChainClient;

async function createInstance(url){
    let methodName = ">>> [createInstance]: ";

    try{

        web3 = new Web3(new Web3.providers.HttpProvider(url));
        return web3;

    }catch(e){
        console.error(e);
    }

}

async function getActiveContract(_webInstance, _accountAddress){
    let methodName = ">>> [getActiveContract]: ";

    try{

        var contract = await importContract(_webInstance, contractName);
        var abi = await getABIofContract(contractName);

        //read from a file if the address is present and the contract exists, if not create and deploy contract
        var activeContractAddress = await readFile(localNodeFolder + contractAddressFileName, 'utf8').catch( async function(){
            var contractAddress = await deployDataContract(contract, _accountAddress);
            await writeFile(localNodeFolder + contractAddressFileName, contractAddress);
            return contractAddress;
        });

        activeContract = new _webInstance.eth.Contract(abi, activeContractAddress);   
        
        return activeContract;

    }catch(e){
        console.error(e);
    }

}

async function deployDataContract(contract, senderAddress){
  let methodName = ">>> [deployDataContract]: ";
  
    try{


          contract.deploy().estimateGas(function(err, gas){
            console.log(methodName, "Gas Cost for deploying a the Contract: ", gas);
          });
        
          var address = contract.deploy()
          .send({
            from: senderAddress[0]
          }, function(error, transactionHash){
        
          })
          .on('error', function(error){
            console.error(methodName + "An error has occured during the deployment! " + error);
          })
          .on('transactionHash', async function(transactionHash){
            console.log(methodName + "Transaction Hash: " + transactionHash);
          })
          .then(newContractInstance => {
            // instance with the new contract address
            return newContractInstance.options.address;
          }).catch(err => {
            console.error(err);
          });
        
          return address;
      
    }catch(e){
      throw e;
    }
  
  }

async function importContract(web3, contractName){
    const methodName = ">>> [importContract]: ";
    
      try{
    
        const contractPath = path.resolve(__dirname, '', contractName);
        const source = await readFile(contractPath, 'UTF-8');
        let compiledContract = solc.compile(source, 1);
        let abi = JSON.parse(compiledContract.contracts[':DataInterpreter'].interface);
        let byteCode = "0x" + compiledContract.contracts[':DataInterpreter'].bytecode;
        let contract = new web3.eth.Contract(abi,{
          data: byteCode
        });
        return contract;
    
      }catch(e){
        throw e;
      }
    
}

async function getABIofContract(contractName){
  let methodName = ">>> [getABIofContract]: ";
  
    try{
  
      const contractPath = path.resolve(__dirname, '', contractName);
      const source = await readFile(contractPath);
      let compiledContract = solc.compile(source, 1);
      let abi = JSON.parse(compiledContract.contracts[':DataInterpreter'].interface);
      return abi;
  
    }catch(e){
      throw e;
    }
  
  }

async function getAccountAddress(accountNumber,instance){
    const methodName = ">>> [getAccountAddress]: ";
      try{
    
        var accountAddress = [];
        var accounts = await instance.eth.getAccounts();
        accountAddress.push(accounts[accountNumber]);

        await unlockAccount(accountAddress, password, instance);
      
        return accountAddress;
    
      }catch(e){
        console.error(e);
      }
}

async function unlockAccount(address,password,instance){
    const methodName = ">>> [unlockAccount]: ";
      try {
    
        address.forEach( async function(key){
          await instance.eth.personal.unlockAccount(key, password, 0);
        })
          
      }catch(e) {
        console.error(e);
      }
}

async function getAllPublicKeys(){
    let methodName = ">>> [getAllPublicKeys]: ";
    
      try{
    
        var exists = false;
        var dir = await readDir(localNodeFolder);
        dir.forEach(function(file) {
          if(publicKeyFileName == file){
            exists = true;
          }
        })
    
        if(!exists){
          debug(methodName + "Shared Public-Key-file doesn't exist. Please export a Public-Key to create the file!");
          process.exit();
        }else{
          // JSON File already exists - read it and push the new key-pair
          var data = await readFile(localNodeFolder + publicKeyFileName);
          publicKeysObject = JSON.parse(data);
        }
    
        var publicKeys = publicKeysObject.publicKeys.map(keyObject => keyObject.publicKey);
    
        return publicKeys;
    
      }catch(e){
        console.error(e);
      }
    
}