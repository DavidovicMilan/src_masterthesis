const crypto = require('crypto');
const ecies = require('standard-ecies');
const keyth = require('keythereum-node');
const player = require('play-sound')();

const password = "password";
const keyType = 'secp256k1';
const algorithm = 'aes-256-cbc';
const inputEncoding = 'utf8';
const outputEncoding = 'hex';
const keystorePath = "/Users/milandavidovic/masterthesis/localNode/private";

const sphereTypes = {
    public: "Public",
    global: "Global",
    static: "Static",
    weakDynamic: "Weak-Dynamic",
    strongDynamic: "Strong-Dynamic"
} 

const userMapping = {
    "GP" : 0,
    "DI" : 1,
    "R" : 2,
    "I" : 3
  }

class WrapperTask {

    constructor(_description, _assignee, _name, _id, _encryptedAssigneeKeys, _accountAddress, _publicKeys, _availableKeyForUser, _offChainUsage){
      this.description = _description;
      this.assignee = _assignee;
      this.name = _name;
      this.id = _id;
      this.accountAddress = _accountAddress;
      this.encryptedAssigneeKeys = _encryptedAssigneeKeys;
      this.publicKeys = _publicKeys;
      this.sharedKeyUsed = false;
      this.isGlobalEncryptionScheme = false;
      this.symmetricKeyExists = false;
      this.isStrongDynamic = false;
      this.encryptionNeeded = true;
      this.methodsUsed = [];
      this.encryptedData;
      this.availableKeyForUser = _availableKeyForUser;
      this.offChainUsage = _offChainUsage;
    }

    get getAssignee(){
      return this.assignee;
    }

    get getInitiatingMember(){
      return this.description.initiatingMember;
    }

    get getIncomingData(){
      return this.description.incomingData;
    }

    get getOutgoingData(){
      return this.description.outgoingData;
    }

    get getDescription(){
      return this.description;
    }

    get getSymmetricKeyExists(){
      return this.symmetricKeyExists;
    }

    get getName(){
      return this.name;
    }

    get getId(){
      return this.id;
    }

    get getGlobalEncryptionScheme(){
      return this.isGlobalEncryptionScheme;
    }

    get getIsStrongDynamic(){
      return this.isStrongDynamic
    }

    get getSharedKeyUsage(){
      return this.sharedKeyUsed;
    }

    get getEncryptedData(){
      return this.encryptedData;
    }

    setMethodsUsed(_methodName){
      this.methodsUsed = _methodName;
    }

    setGlobalEncryptionScheme(_isGlobalEncryptionScheme){
      this.isGlobalEncryptionScheme = _isGlobalEncryptionScheme;
    }

    async encryptTaskData(_dataInput, _dataObjectName, _sharedKeys){
      let methodName = "encryptTaskData";

      this.setMethodsUsed(methodName);
      _dataObjectName = _dataObjectName.replace(/\"/g, "");
      _dataInput = _dataInput.replace(/\"/g, "");

      var currentSphere = this.description.spheres.find( s => {
        if(s.dataObject == _dataObjectName){
          return s;
        }
      })

      var sharedSymmetricKey;

      if(currentSphere == undefined){
        return "Nothing to encrypt";
      }

      this.encryptionNeeded = true;
      var symmetricKey = undefined;

      switch(currentSphere.sphereType){
          case sphereTypes.public:

            this.encryptionNeeded = false;

            break;
          case sphereTypes.global:

             if(this.availableKeyForUser[this.assignee] != undefined){

              var key = Object.keys(this.availableKeyForUser[this.assignee])[0];

              if(this.availableKeyForUser[this.assignee][key] != undefined){

                var currentAssigneeKey = this.availableKeyForUser[this.assignee][key];
                console.log(">>>>>>KEY: ", currentAssigneeKey);
                var keyBuffer = new Buffer.from(currentAssigneeKey.key,'hex');
                symmetricKey = await decryptWithPrivateKey(this.accountAddress[0], keyBuffer);
                this.symmetricKeyExists = true;
                this.isGlobalEncryptionScheme = true;
              }
            }
            
            break;
          case sphereTypes.static:

            if(this.availableKeyForUser[this.assignee] != undefined){
              if(this.availableKeyForUser[this.assignee][_dataObjectName] != undefined){
                var currentAssigneeKey = this.availableKeyForUser[this.assignee][_dataObjectName];

                var keyBuffer = new Buffer.from(currentAssigneeKey.key,'hex');
                symmetricKey = await decryptWithPrivateKey(this.accountAddress[0], keyBuffer);
                this.symmetricKeyExists = true;
              }
            } 
            
            break;
          case sphereTypes.weakDynamic:

            // default configuration when encrypting and decrypting
            
            break;
          case sphereTypes.strongDynamic:

            this.isStrongDynamic = true;
            
            break;
      }

      if(this.description.optimize != undefined && this.encryptionNeeded == true && this.symmetricKeyExists == false){
        if(this.description.optimize.shareKey != undefined){

          var foundShareKeyOptimization = await this.description.optimize.shareKey.find( async function(e){
            for(var d of e.writtenData){
              var dataShort = await findOccurenceInString(_dataObjectName, "[", "]");
              if(d == dataShort){
                return e;
              }
            }
          });

          if(foundShareKeyOptimization != undefined){

            sharedSymmetricKey = _sharedKeys.find( e => e.shareKeyId == foundShareKeyOptimization.shareKeyId);

            if(sharedSymmetricKey != undefined){                      
              this.sharedKeyUsed = true;
            }  

          }

        }
      }

      var encryptedKeysForDeployment = [];

      var encryptedPayload = {
        data : _dataInput,
        dataObject: _dataObjectName,
        keys : encryptedKeysForDeployment
      }

      if(this.encryptionNeeded){

        // a sharedKey already exists
        if(this.sharedKeyUsed){
          console.log(methodName, "OPTIMIZATION: Shared Key used!");
          var encryptedTuple = await encryptWithSymmetricKey(_dataInput, sharedSymmetricKey.key);
        }else{
          var encryptedTuple = await encryptWithSymmetricKey(_dataInput, symmetricKey);
        }

        if(this.offChainUsage){
          this.encryptedData = {data: encryptedTuple.encryptedData, dataObject: _dataObjectName};
          encryptedTuple.encryptedData = "";
        }

        console.log("Encrypted data: " , encryptedTuple.encryptedData);
        
        // Für den Global und Static-Fall
        // Falls ein symmetrischer Schlüssel für das Datenobjekt bereits existiert (this.symmetricKeyExists == true), 
        // wird dieser von den anderen Teilnehmern wieder verwendet.
        if(this.symmetricKeyExists == false){

            for(const i in currentSphere.members){
              var member = currentSphere.members[i];

              var encryptedMemberKey = {
                  member: member.name,
                  dataObject: _dataObjectName,
                  sphereType: currentSphere.sphereType,
                  key: ""
              } 

              var publicKey = this.publicKeys[userMapping[member.name]];
              encryptedMemberKey.key = await encryptWithPublicKey(publicKey, encryptedTuple.symmetricKey);

              encryptedKeysForDeployment.push(encryptedMemberKey);

            }
        }
        
        var encryptedPayload = {
            data : encryptedTuple.encryptedData,
            dataObject: _dataObjectName,
            keys : encryptedKeysForDeployment,
            sharedSymmetricKey : null
        }

        // if no sharedKey was used, return the used symmetric Key and safe it at the user himself.
        if(!this.sharedKeyUsed){
          encryptedPayload.sharedSymmetricKey = encryptedTuple.symmetricKey;
        }

      }

      return encryptedPayload;

    }

    async decryptTaskData(_encryptedData){
      let methodName = ">>> [decryptTaskData]: ";

      try{

        this.setMethodsUsed(methodName);

        var currentSphere = this.description.spheres.find( s => {
          if(s.dataObject == _encryptedData.dataObject){
            return s;
          }
        })

        // if no keys for decryption available -> data was never encrypted
        var decryptedData = _encryptedData;

        for(const i in this.encryptedAssigneeKeys){
          var memberKey = this.encryptedAssigneeKeys[i];

          if(memberKey.member == this.assignee && (memberKey.dataObject == _encryptedData.dataObject || currentSphere.sphereType == sphereTypes.global)){

            var encryptedKey = new Buffer.from(memberKey.key,'hex');
            var decryptedSymmetricKey = await decryptWithPrivateKey(this.accountAddress[0], encryptedKey);
            console.log("Encrypted data: ", _encryptedData.data);
            var decryptedData = await decryptWithSymmetricKey(_encryptedData.data, decryptedSymmetricKey);

          }

        }

        console.log(methodName,"Decryption successful! Data decrypted: ", decryptedData);

        if(decryptedData.data != undefined){
          return decryptedData.data;
        }else{
          return decryptedData.replace(/\"/g, "");
        }


      }catch(e){
        console.error(e);
        //player.play('./error.mp3', (err) => {
          //if (err) console.log(`Could not play sound: ${err}`);
        //});
        //process.exit();
      }

    }

    async createEncryptedKeysForExchange(_encryptedKey){
      let methodName = ">>> [decryptTaskData]: ";

      try{

        this.setMethodsUsed(methodName);

        var bufferedKey = new Buffer.from(_encryptedKey,'hex');
        var decryptedSymmetricKey = await decryptWithPrivateKey(this.accountAddress[0], bufferedKey);

        var createdKeysForExchange = [];

        for(var users of Object.keys(userMapping)){
          if(users != this.assignee){

            var publicKey = this.publicKeys[userMapping[users]];
            var encryptedKeyForExchange = await encryptWithPublicKey(publicKey, decryptedSymmetricKey);
            createdKeysForExchange.push({user: users, key: encryptedKeyForExchange.toString('hex')});

          }

        } 
        
        return createdKeysForExchange;

      }catch(e){
        console.error(e);
        //player.play('./error.mp3', (err) => {
          //if (err) console.log(`Could not play sound: ${err}`);
        //});
        //process.exit();
      }

    }

}

module.exports = WrapperTask;

async function importPrivateKey(address) {
    let methodName = ">>> [importPrivateKey]: ";
      try{
  
          var keyObject = await keyth.importFromFile(address, keystorePath);
          return await keyth.recover(password, keyObject);
    
        }catch(e) {
          console.error(e);
        }
    } 
  
  async function encryptWithPublicKey(publicKey, dataObject){
      const methodName = ">>> [encryptWithPublicKey]: ";
        try{
      
          var buffer = new Buffer.from(dataObject);
          var publicKey = new Buffer.from(publicKey, 'hex');
          var encryptedText = await ecies.encrypt(publicKey, buffer);
          return encryptedText;
      
        }catch(e){
          console.error(e);
        }
      
  }
  
  async function encryptWithSymmetricKey(dataObject, symmetricKey){
      const methodName = ">>> [encryptWithSymmetricKey]:";
      
        try{
      
          var iv = crypto.randomBytes(16);
          
          if(symmetricKey == undefined){
            //console.log(methodName, "Creating new Symmetric Key!");
            symmetricKey = crypto.randomBytes(32);
          }else{
            //console.log(methodName, "Symmetric Key already exists for the current DataObject");
          }
  
          var cipher = crypto.Cipheriv(algorithm, symmetricKey, iv);
      
          var encryptedData = cipher.update(dataObject, inputEncoding, outputEncoding);
          encryptedData += cipher.final(outputEncoding);
          // append the iv to the cipher, the iv is needed for the decryption
          encryptedData = encryptedData.concat(iv.toString('hex'));
      
          var result = { encryptedData: encryptedData, symmetricKey: symmetricKey };
      
          return result;
      
        }catch(e){
          console.error(e);
        }
      
  }
  
  async function decryptWithPrivateKey(address, encryptedKey){
    let methodName = ">>> [decryptWithPrivateKey]: ";
    
        try{
  
          var ecdh = crypto.createECDH(keyType);
          ecdh.setPrivateKey(await importPrivateKey(address));
          ecdh.getPublicKey();
  
          return ecies.decrypt(ecdh, new Buffer.from(encryptedKey));
    
      }catch(e){
        console.error(e);
      }
    }
    
    async function decryptWithSymmetricKey(dataObject, symmetricKey){
    let methodName = ">>> [decryptWithSymmetricKey]: ";
    
      try{
    
        // get the last 32 characters which are the iv in hex format
        var ivHex = dataObject.slice(-32);
        // this is the actual symmetrically encrypted data
        var encryptedData = dataObject.slice(0,-32);
        // get iv in Buffer
        var iv = new Buffer.from(ivHex, 'hex');
        var decipher = crypto.Decipheriv(algorithm, symmetricKey, iv);
        var message = decipher.update(encryptedData, outputEncoding, inputEncoding);
        message += decipher.final(inputEncoding);
    
        return message;
    
      }catch(e){
        console.error(e);
      }
    
    }

    async function findOccurenceInString(_input, _symbolFrom, _symbolTo) {
      let methodName = ">>> [findOccurenceInString]: ";
    
      try {
    
        var startIndex = _input.indexOf(_symbolFrom);
        var endIndex = _input.indexOf(_symbolTo);
    
        return _input.slice(startIndex + 1, endIndex);
    
      } catch (e) {
        console.error(methodName, e);
      }
    
    }