const { Client, logger } = require("camunda-external-task-client-js");
const { Variables } = require("camunda-external-task-client-js");
const nodeFetch = require('node-fetch');
const Web3 = require('web3');
const crypto = require('crypto');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const parser = require('xml2json');
const player = require('play-sound')();

const json2csv = require('json2csv').parse;

const ChainClient = require('./ChainClient.js');
const WrapperTask = require('./WrapperTask.js');
const fs = require("fs");

const c_definitions = 'bpmn:definitions';
const c_process = 'bpmn:process';
const c_serviceTasks = 'bpmn:serviceTask';
const c_documentation = 'bpmn:documentation';
const c_data = 'bpmn:dataObjectReference';
const c_extension = 'bpmn:extensionElements';
const c_properties = 'camunda:properties';
const c_nodeId = "$t";

const port = 3000;

const useDecisionProbability = false;

const arithmetic = "0";
const comparsion = "1";
const logic = "2";

var fileCsv = "large_random5_Global__Log_OnChainEncrypted";
var fileCosts = "large_random5_Global_Log_OnChainEncrypted_Costs";
const fileData = "./dataInput.txt";
const jsonDecisionsFile = "decisions.json"; 

var totalGas = 0;

var userMapping = {
  "GP": 0,
  "DI": 1,
  "R": 2,
  "I": 3
}

var operators = ["+", "-", "*", "/", "<", ">", "=", "!", "&", "|"];

var operatorsLegend = {
  "+": arithmetic,
  "-": arithmetic,
  "*": arithmetic,
  "/": arithmetic,
  "<": comparsion,
  ">": comparsion,
  "=": comparsion,
  "!": comparsion,
  "&": logic,
  "|": logic
}

var currentContractLogState = [];

var publicDataWritten = [];

var mappingDataObject = [];
var mappingUser = [];
var availableKeyForUser = {};

var localKeysBeforeExchange = {};

var activeContract;
var publicKeys;

var instanceID;
var activeWrapperTask;

var totalGasCosts = 0;
var gasCostsWithoutStartFee = 0;

var sharedKeys = [];

var autoRunStatus;

var bpKey;
var IterationCounter = 0;

var mappingCounterDataObject = 0;
var mappingCounterUser = 0;

var processInstanceID = "";

var toIteration;

var offChainStorage = [];

var useOffChain = false;
var useContractStorage = false;

var estimatedDataGas = 0;
var estimatedKeyGas = 0;

var consoleIterationInfo = "";

const readFile = (path, opts = 'utf8') =>
  new Promise((resolve, reject) => {
    fs.readFile(path, opts, (err, data) => {
      if (err){
        reject(err)
      }else{
        resolve(data)
      }  
    })
  });

  const createDataFileOfSize = (size) => {
    return new Promise((resolve, reject) => {
      try {
        //First create an empty file.
        fs.writeFile(fileData, Buffer.alloc(0), async function(error){
          if (error) {
            reject(error);
          } else {
            let sizeRemaining = size;
            do {
              const dataBuffer = Buffer.from(await createRandomString(1), 'utf8');
              try {
                fs.appendFileSync(fileData, dataBuffer);
                sizeRemaining -= dataBuffer.length;
              } catch (error) {
                reject(error);
              }
            } while (sizeRemaining > 0);
            resolve(true);
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  };

workerMain();

async function checkInputParameters() {
  let methodName = ">>> [checkInputParameters]: ";

  // par1: name of the xml file to import
  if (process.argv[2] == null || process.argv[3] == null) {
    console.log(">> Please provide parameters when calling the Script! par1 = <AutoRun <true/false> par2 = <Key of BusinessProcess>");
    process.exit(1);
  } else {
    autoRunStatus = process.argv[2];
    bpKey = process.argv[3];
    if(process.argv[4] != undefined){
      IterationCounter = process.argv[4];
    }
    if(process.argv[5] != undefined){
      toIteration = process.argv[5];
    }
    if(process.argv[6] != undefined){
      useOffChain = (process.argv[6] == 'true');
    }
    if(process.argv[7] != undefined){
      useContractStorage = (process.argv[7] == 'true');
    }
  }
}

async function workerMain() {

  let ChainClientInstance = new ChainClient();
  await ChainClientInstance.initializeClient();

  activeContract = ChainClientInstance.getContract;
  publicKeys = ChainClientInstance.getPublicKeys;

  createDataFileOfSize(1024);

  await checkInputParameters()

  instanceID = parseInt("0x" + crypto.randomBytes(6).toString('hex'));


  var jsonFile = await readFile(jsonDecisionsFile);
  var jsonDecisions = JSON.parse(jsonFile);

  var randomMode = false;


  // check for idle user tasks which have no incoming or outgoing Data and complete them
  // if parameter "autoRunStatus" is true then automatic business process traversing in engine is activated
  setTimeout(checkForActiveUserTasks, 2000);

  async function checkForActiveUserTasks() {

    if(toIteration == undefined){
      toIteration = jsonDecisions.decisions.length - 1;
    }

    var url = "http://localhost:8080/engine-rest/process-instance";

    var response = await nodeFetch(url);
    var jsonResponse = await response.json();

    var processInstance = jsonResponse.find(e => e.id == processInstanceID);
    
    if(processInstance == undefined){

        consoleIterationInfo = IterationCounter;

        if(totalGas != 0){
          await writeCostsToSheet(totalGas, estimatedDataGas, estimatedKeyGas);
        }

        if(IterationCounter == toIteration){
          process.exit();
        }

        if(IterationCounter == jsonDecisions.decisions.length){
          return;
        }

        // reset variables, start new BusinessProcess
        totalGas = 0;
        currentContractLogState = [];
        publicDataWritten = [];
        mappingDataObject = [];
        mappingUser = [];
        availableKeyForUser = {};
        localKeysBeforeExchange = {};
        totalGasCosts = 0;
        gasCostsWithoutStartFee = 0;
        sharedKeys = [];
        mappingCounterDataObject = 0;
        mappingCounterUser = 0;
        offChainStorage = [];
        estimatedDataGas = 0;
        estimatedKeyGas = 0;

        var url = "http://localhost:8080/engine-rest/process-definition/key/" + bpKey + "/start";

        var currentDecision;

        if(randomMode == false){
          currentDecision = jsonDecisions.decisions[IterationCounter];
        }else{

        }
        
        var jsonData = {
          "variables": {          
          }
        }

        for(decision of currentDecision){
          jsonData.variables[decision.name] = {"value": decision.value};
        }

        var result = await nodeFetch(url, {
          headers: {
            'Content-Type': 'application/json'
          },
          method: 'POST',
          body: JSON.stringify(jsonData)
        }).then(function(res){
          return res.json();
        });

        processInstanceID = result.id;

        IterationCounter++;

    }

    url = "http://localhost:8080/engine-rest/task?active=true";

    response = await nodeFetch(url);
    jsonResponse = await response.json();

    voteDone = false;

    var activeTask = jsonResponse.find(function(e){
      if(e.processInstanceId == processInstanceID){
        return e;
      }
    });

    if (activeTask != undefined) {

      var description = JSON.parse(activeTask.description);

      // Complete Task if it has no incoming or outgoing Data
      if (description.incomingData.length == 0 && description.outgoingData.length == 0) {

        var jsonData = {
          "variables": {}
        };

        console.log("About to complete " + activeTask.name + " ...");

        await completeTask(activeTask.id, jsonData, activeTask.name, description, 0);

      } else {

        // Do the Voting Task evaluation if the current task is a votingTask
        if (description.decisionExpressionPostfix != undefined) {

          voteDone = true;

          var chainData = await readFromChain(activeTask, ChainClientInstance);

          console.log("Voting Task Procedure started...");

          var result = await evaluateDecision(description, chainData);

          console.log("Voting Task has evaluated the DecisionPostfix: '" + result + "'");

          // add the "human error" to the vote
          if(description.falseRate != undefined){

          console.log("Try adding human error...");

            var falseRate = Number.parseFloat(description.falseRate).toFixed(2);
            console.log(falseRate);
            var randomNumber = Math.random().toFixed(2);
            console.log(randomNumber);

            if(randomNumber <= falseRate){
              result = !result;
            }

          }

          console.log("Result after adding human error: '" + result + "'");


          result = Web3.utils.utf8ToHex(result.toString());

          //console.log("Writing the vote to the Voting Contract Storage...");

          var estimatedGas = await activeContract.methods.callAddVote(result).estimateGas();

          totalGasCosts = totalGasCosts + estimatedGas;
          gasCostsWithoutStartFee = gasCostsWithoutStartFee + (estimatedGas - 25000);

          //console.log("TOTAL GAS USED: " + totalGasCosts);
          //console.log("TOTAL GAS without start fee: " + gasCostsWithoutStartFee);

          var accountAddress = await ChainClientInstance.getUnlockedAccountAddress(userMapping[activeTask.assignee]);

          await activeContract.methods.callAddVote(result).send({
            from: accountAddress[0],
            gas: estimatedGas
          });

          //console.log("Vote has been written to the Blockchain!");

          var jsonData = {
            "variables": {}
          }

          activeTaskId = activeTask.id;

          jsonData.variables[activeTaskId] = {};
          jsonData.variables[activeTaskId].value = "successfully voted";

          await completeTask(activeTask.id, jsonData, activeTask.name, description, estimatedGas);

        }

        // autoRun is true, which means the business process is executed automatically without user input
        if (autoRunStatus == "true" && !voteDone) {

          // call the REST endpoint "readFromChain" to initialize the wrapperTask instance and read from the chain

          var taskData = {
            taskInformation: activeTask
          }

          var url = "http://localhost:3000/readFromChain";

          await nodeFetch(url, {
            headers: {
              'Content-Type': 'application/json'
            },
            method: 'POST',
            body: JSON.stringify(taskData)
          });

          var dataWritten = {};
          var outgoingData = description.outgoingData;
          var dataWriteAvailable = false;

          for (var out of outgoingData) {

            dataWriteAvailable = true

            var dataOut = await findOccurenceInString(out.name, "[", "]");
            var variables = description[dataOut];

            dataWritten[dataOut] = [];

            if(!Array.isArray(variables)){
              variables = [variables];
            }

            for (var i in variables) {

              var variableWritten;
              var inputVariable = variables[i];           

              if (inputVariable.value == "Double") {
                variableWritten = await createRandomNumber(10);
              }

              if (inputVariable.value == "String") {
                variableWritten = await readFile(fileData);
                //variableWritten = await createRandomString(10);
              }

              if (inputVariable.value == "Boolean") {
                variableWritten = await createRandomBoolean();
              }

              dataWritten[dataOut].push(variableWritten);

            }

          }

          if (dataWriteAvailable) {

            // call the REST endpoint "writeToChain"

            var url = "http://localhost:3000/writeToChain";

            await nodeFetch(url, {
              headers: {
                'Content-Type': 'application/json'
              },
              method: 'POST',
              body: JSON.stringify(dataWritten)
            });

          } else {

            // complete the Task in the camunda engine

            var jsonData = {
              "variables": {}
            };

            console.log("About to complete " + activeTask.name + " ...");

            await completeTask(activeTask.id, jsonData, activeTask.name, description, 0);
          }

        }

      }

    }

    setTimeout(checkForActiveUserTasks, 2000);

  }

  // Listener for written Data to Chain
  activeContract.events.WriteToChain({ fromBlock: 'latest' })
    .on('data', function (log) {

      console.log("Listener triggered!");

      var payload = JSON.parse(log.returnValues.payload);

      updateAvailableKeysForCurrentUser(payload);

    })
    .on('error', (log) => {
      console.log(`error:  ${log}`);
    });

  activeContract.events.WriteToChain({
      filter: { instanceId: instanceID },
      fromBlock: 0,
      toBlock: 'latest'
    }).on('data', function (events) {

        console.log("Logs updated!");
        currentContractLogState.push(events);

    })
    .on('error', (log) => {
      console.log(`error:  ${log}`);
  });

  console.log("... Instance ID created:", instanceID);

  // configuration for the Client:
  //  - 'baseUrl': url to the Workflow Engine
  //  - 'logger': utility to automatically log important events
  let config = { baseUrl: "http://localhost:8080/engine-rest", use: logger, asyncResponseTimeout: 30000 };

  // create a Client instance with custom configuration
  let client = new Client(config);
  let app = express();

  app.use(cors());
  // Configuring body parser middleware
  app.use(bodyParser.urlencoded({limit: '50mb', extended: false}));
  app.use(bodyParser.json({limit: '50mb'}));
  app.use(express.static('forms'));

  app.listen(port, () => console.log('... Listening on port ' + port + ' for incoming REST-Calls from Camunda!'));

  console.log("useOffChain: ", useOffChain);
  console.log("useContractStorage: ", useContractStorage);

  if(useOffChain == true){
    console.log("OFF-CHAIN STORAGE ACTIVE!");
  }else{
    console.log("ON-CHAIN STORAGE ACTIVE!");
  }

  if(useContractStorage == true){
    console.log("CONTRACT STORAGE ACTIVE!");
  }else{
    console.log("CONTRACT STORAGE INACTIVE!");
  }

  // ##########################################
  // ############ writeToChain ################
  // ##########################################

  app.post('/writeToChain', async function (req, res) {
    let callName = consoleIterationInfo + " >>> [writeToChain]: ";

    var inputData = req.body;
    var publicMode = false;
    var estimatedGas = 0;

    var localKeysForCurrentUser = {};

    if (activeWrapperTask.getOutgoingData.length > 0) {

      var jsonData = {
        "variables": {}
      };

      var payload = {};

      for (var k = 0; k < activeWrapperTask.getOutgoingData.length; k++) {

        var dataObjectShort = await findOccurenceInString(activeWrapperTask.getOutgoingData[k].name, "[", "]");
        var chainDataForObject = inputData[dataObjectShort];

        console.log("Data entered: ", chainDataForObject);

        var encryptedData = await activeWrapperTask.encryptTaskData(JSON.stringify(chainDataForObject), activeWrapperTask.getOutgoingData[k].name, sharedKeys);

        var foundMappingDataObject = mappingDataObject.find(e => e.dataObject == encryptedData.dataObject);

        if (foundMappingDataObject == undefined) {
          foundMappingDataObject = { dataObject: encryptedData.dataObject, id: mappingCounterDataObject };
          mappingDataObject.push(foundMappingDataObject);
          mappingCounterDataObject++;
        }

        // if no shared Key has been found -> add the used key as a candidate for future key sharing
        if(activeWrapperTask.getDescription.optimize != undefined){
          if(activeWrapperTask.getDescription.optimize.shareKey != undefined){
  
            var foundShareKeyOptimization = activeWrapperTask.getDescription.optimize.shareKey.find( e => {
              for(var d of e.writtenData){
                if(d == dataObjectShort){
                  return e;
                }
              }
            });

            if(activeWrapperTask.getSharedKeyUsage == false){
              if(encryptedData.sharedSymmetricKey != null){
                //console.log(callName, "Adding new Shared Key!");
                sharedKeys.push({shareKeyId: foundShareKeyOptimization.shareKeyId, key: encryptedData.sharedSymmetricKey})
              }
            }

          }
        }

        if(!useOffChain){
          payload[foundMappingDataObject.id] = Date.now().toString() + "&" + encryptedData.data;
        }
        

        for (var i in encryptedData.keys) {

          var memberKey = encryptedData.keys[i];

          var foundUserMapping = mappingUser.find(e => e.user == memberKey.member);

          if (foundUserMapping == undefined) {
            var foundUserMapping = { user: memberKey.member, id: mappingCounterUser };
            mappingUser.push(foundUserMapping);
            mappingCounterUser++;
          }

          if (memberKey.sphereType == "Strong-Dynamic") {

            var sphere = activeWrapperTask.description.spheres.find(e => e.dataObject == encryptedData.dataObject);

            // if the current task is exchanging the key immediately
            if (sphere.exchangeKeys != undefined) {

              //console.log("EXCHANGE DIRECTLY!")

              var foundReceiver = sphere.exchangeKeys.find(e => e.receiver == memberKey.member);

              if (foundReceiver != undefined && activeWrapperTask.getSharedKeyUsage == false) {
                payload[foundMappingDataObject.id + "&" + foundUserMapping.id] = memberKey.key.toString('hex');
                //console.log(callName, "Strong-Dynamic key for " + memberKey.member + " is exchanged immediately.");
              }

            }

            if (localKeysBeforeExchange[activeWrapperTask.getAssignee] == undefined) {
              localKeysBeforeExchange[activeWrapperTask.getAssignee] = {};
            }
            //console.log("MEMBER",memberKey.member, foundUserMapping.id)

            // if the key generated is for the sender himself -> store it directly at the sender, no need to store it on the chain
            if (memberKey.member == activeWrapperTask.getAssignee) {
              localKeysForCurrentUser[foundMappingDataObject.id + "&" + foundUserMapping.id] = memberKey.key.toString('hex');
            } else {
              // else write it to the keys waiting to be exchanged by the current user or an alternative distributor if no sharedKey is used
              //if(activeWrapperTask.getSharedKeyUsage == false){
                localKeysBeforeExchange[activeWrapperTask.getAssignee][foundMappingDataObject.id + "&" + foundUserMapping.id] = memberKey.key.toString('hex');
              //}
            }
          } else {

            // if the key is not for a strong-dynamic sphere, also lookup if it is a key of the current assignee
            if (memberKey.member == activeWrapperTask.getAssignee) {
              localKeysForCurrentUser[foundMappingDataObject.id + "&" + foundUserMapping.id] = memberKey.key.toString('hex');
            } else {
              // if no sharedKey is used then add the new keys to the payload, else don't add because keys for the dataobject for the
              // participants already exist or are exchanged

              // before adding the key, check if a key for the current paerticipant already exists for global sphere, 
              // if yes don't add new keys to the payload, because the key is used globally
              if(memberKey.sphereType == "Global"){
                if(availableKeyForUser[memberKey.member] == undefined){
                  //console.log("No Global Key for ", memberKey.member," exists.");
                  payload[foundMappingDataObject.id + "&" + foundUserMapping.id] = memberKey.key.toString('hex');
                }
              }else{
                if(activeWrapperTask.getSharedKeyUsage == false){
                  payload[foundMappingDataObject.id + "&" + foundUserMapping.id] = memberKey.key.toString('hex');              
                }
              } 
            }
          }
        }

        if(encryptedData.keys.length > 0){

          // lookup if any public data has been written for this data before, if yes remove because 
          // data has been encrypted and is not public anymore
          found = publicDataWritten.find(e => e == dataObjectShort);

          if(found != undefined){
            var index = publicDataWritten.indexOf(found);
            publicDataWritten.splice(index,1);
          }

        }

        if(useOffChain){
          publicMode = true;
          console.log("Off-Chain Storage used.")
  
          OffChainPayload = payload;
          OffChainPayload[foundMappingDataObject.id] = Date.now().toString() + "&" + encryptedData.data;
  
          transactionHash = crypto.createHash('md5').update(OffChainPayload[foundMappingDataObject.id]).digest('hex');
  
          console.log("Hash of data: ",transactionHash);
  
          estimatedGas = await activeContract.methods.storeDataInContract(foundMappingDataObject.id, transactionHash).estimateGas();
          estimatedDataGas = estimatedDataGas + await activeContract.methods.storeDataInContract(foundMappingDataObject.id, transactionHash).estimateGas() - 25000;
          var accountAddress = await ChainClientInstance.getUnlockedAccountAddress(userMapping[activeWrapperTask.getAssignee]);

          await activeContract.methods.storeDataInContract(foundMappingDataObject.id, transactionHash).send({
            from: accountAddress[0],
            gas: estimatedGas
          });
  
          offChainStorage.push(OffChainPayload);
        }
        
        //if(useContractStorage || (encryptedData.keys.length == 0 && !activeWrapperTask.getGlobalEncryptionScheme && !activeWrapperTask.getSymmetricKeyExists)){

        if(useContractStorage){
          publicMode = true;

          console.log("Contract Storage used.")

          //publicDataWritten.push(dataObjectShort);

          estimatedGas = await activeContract.methods.storeDataInContract(foundMappingDataObject.id, JSON.stringify(encryptedData.data)).estimateGas();
          estimatedDataGas = estimatedDataGas + await activeContract.methods.storeDataInContract(foundMappingDataObject.id, JSON.stringify(encryptedData.data)).estimateGas() - 25000;
          var accountAddress = await ChainClientInstance.getUnlockedAccountAddress(userMapping[activeWrapperTask.getAssignee]);

          await activeContract.methods.storeDataInContract(foundMappingDataObject.id, JSON.stringify(encryptedData.data)).send({
            from: accountAddress[0],
            gas: estimatedGas
          });

          //estimatedGas = await activeContract.methods.callWriteToChainEvent(instanceID, JSON.stringify(encryptedData)).estimateGas();
          //estimatedDataGas = estimatedDataGas + await activeContract.methods.callWriteToChainEvent(instanceID, JSON.stringify(encryptedData.data)).estimateGas() - 25000;
          estimatedKeyGas = estimatedKeyGas + 0;

          //console.log("Total Cost: ", estimatedGas);
          //console.log("Only Data Costs: ", estimatedDataGas);
          //console.log("Only Keys Costs: ", estimatedKeyGas);

          //await activeContract.methods.callWriteToChainEvent(instanceID, JSON.stringify(encryptedData.data)).send({
            //from: accountAddress[0],
            //gas: estimatedGas,
          //});

          //console.log(callName, "Public Write in '" + activeWrapperTask.getName + "' for Dataobject '" + dataObjectShort + "'");

        }
      }

      if(!publicMode){
        
        updateAvailableKeysForCurrentUser(localKeysForCurrentUser);

        //console.log("before estimation..");
        estimatedGas = await activeContract.methods.callWriteToChainEvent(instanceID, JSON.stringify(payload)).estimateGas();
        //console.log("after estimation!", estimatedGas);

        //console.log("Encrypted data: " , payload);

        var keys = Object.keys(payload);

        keys.forEach(async function(key,index){
          if(key.length == 1){
            estimatedDataGas = await activeContract.methods.callWriteToChainEvent(instanceID, JSON.stringify(payload[key])).estimateGas() + (estimatedDataGas - 25000);
          }else{
            estimatedKeyGas = await activeContract.methods.callWriteToChainEvent(instanceID, JSON.stringify(payload[key])).estimateGas() + (estimatedKeyGas - 25000);
          }
        });

        //console.log("Only Data Costs: ", estimatedDataGas);
        //console.log("Only Keys Costs: ", estimatedKeyGas);

        //totalGasCosts = totalGasCosts + estimatedGas;
        //gasCostsWithoutStartFee = gasCostsWithoutStartFee + (estimatedGas - 25000);

        var accountAddress = await ChainClientInstance.getUnlockedAccountAddress(userMapping[activeWrapperTask.getAssignee]);

        console.log("Creating transaction...");

        await activeContract.methods.callWriteToChainEvent(instanceID, JSON.stringify(payload)).send({
          from: accountAddress[0],
          gas: estimatedGas,
        });
        console.log("Transaction successful!");

      
    }

    } else {
      console.log(callName, "No outgoing Dataobject for " + activeWrapperTask.getName);
    }

    await completeTask(activeWrapperTask.getId, jsonData, activeWrapperTask.getName, activeWrapperTask.getDescription, estimatedGas);

    res.status(200).redirect('back');

  });

  // ##########################################
  // ############ readFromChain ###############
  // ##########################################

  app.post('/readFromChain', async function (req, res) {
    let callName = consoleIterationInfo + " >>> [readFromChain]: ";

    //console.log("READ!!!!!");

    var receivedData = req.body;
    var inputData = receivedData.taskInformation;

    var chainData = await readFromChain(inputData, ChainClientInstance);

    res.send(chainData);

  });

  // ##########################################
  // ############ completeTask ################
  // ##########################################

  app.post('/completeTask', async function (req, res) {
    let callName = consoleIterationInfo + " >>> [completeTask]: ";

    var inputData = req.body;
    console.log(callName, inputData);

    var jsonData = {
      "variables": {
        "status": {
          "value": "completed"
        }
      }
    }

    console.log("COMPLETE TASK REST CALL!");

    await completeTask(activeWrapperTask.getId, jsonData, activeWrapperTask.getName, activeWrapperTask.getDescription, 0);

    res.status(200).redirect('back');

  });

  client.subscribe("exchangeKeys", async function ({ task, taskService }) {
    let methodName = consoleIterationInfo + " >>> [encryptData Service-Call]: ";

    try {

      var variables;

      var url = "http://localhost:8080/engine-rest/process-definition/" + task.processDefinitionId + "/xml";

      var response = await nodeFetch(url);
      var data = await response.json();
      var parsedXML = await parseXML2JSON(data.bpmn20Xml);

      var serviceTasks = parsedXML[c_definitions][c_process][c_serviceTasks];

      if (!Array.isArray(serviceTasks)) {
        serviceTasks = [serviceTasks];
      }

      url = "http://localhost:8080/engine-rest/process-instance/" + task.processInstanceId + "/variables";

      response = await nodeFetch(url);
      variables = await response.json();

      var foundServiceTask = serviceTasks.find(e => e.id == task.activityId);

      console.log("");
      console.log("#############################################################");
      console.log("<<<<<<< START EXCHANGE TASK: ", foundServiceTask.name, " >>>>>>>");
      console.log("#############################################################");

      var foundServiceTask = serviceTasks.find(e => e.id == task.activityId);

      //console.log("1");

      var description = JSON.parse(foundServiceTask[c_documentation][c_nodeId]);

      //console.log("2");

      var exchangeProcedures = description.exchange;

      //console.log("3");

      for (var exchange of exchangeProcedures) {

        var assignee = exchange.participant;
        var decisions = exchange.decisions;
        var receiver = exchange.receiver;

        //check if writer can still read the object (the object is the same)
        //TODO:
        // ...

        //console.log("4");

        var broadcastedDecisions = [];

        for (var i in variables) {

          if (decisions.find(e => e.name == i) != undefined) {

            var variable = variables[i];

            for (var j in variable) {
              var value = variable[j];

              if (value == "yes" || value == "no") {
                broadcastedDecisions.push({ name: i, value: value });
              }
            }
          }
        }

        //console.log("5");

        var countOfDecisions = broadcastedDecisions.length;

        //console.log("6");

        if(exchange.alternativeDistributor != undefined){

          console.log("Alternative Distributor Checking!");

          var alternativeDistributorDecisions = exchange.alternativeDistributor.decision; 
          var alternativeDecisionsCount = alternativeDistributorDecisions.length;

          for (var decision of alternativeDistributorDecisions) {

            if(variables[decision.name] != undefined){
              var decisionResult = variables[decision.name].value;
 
              if (decisionResult == decision.value) {
                alternativeDecisionsCount--;
              }
            }
          }

          console.log("Alternative Count Result: ", alternativeDecisionsCount);

          if(alternativeDecisionsCount == 0 ){

            console.log(methodName, "Alternative Distributor " + exchange.alternativeDistributor.distributor + " chosen!");
            assignee = exchange.alternativeDistributor.distributor;

          }
  
        }

        //console.log("7");

        for (var decision of decisions) {

          if(variables[decision.name] != undefined){
            var decisionResult = variables[decision.name].value;

            //console.log("CURRENT DECISION:", decision);
            //console.log("CHAIN DECISION RESULT:", decisionResult);
            //console.log("Decision Result:", decision.value);
            if (decisionResult == decision.value) {
              countOfDecisions--;
            }
          }
        }

        //console.log("8");

        //console.log(countOfDecisions);

        if (countOfDecisions == 0) {

          //console.log("9");

          var accountAddress = await ChainClientInstance.getUnlockedAccountAddress(userMapping[assignee]);

          var foundMappingDataObject = mappingDataObject.find(e => e.dataObject == receiver.dataObject);

          //console.log(">>>>>>>>>>>>>>>MAPPING OBJECT: " , foundMappingDataObject);

          if (foundMappingDataObject == undefined) {
            foundMappingDataObject = { dataObject: receiver.dataObject, id: mappingCounterDataObject };
            mappingDataObject.push(foundMappingDataObject);
            mappingCounterDataObject++;
          }

          var foundUserMapping = mappingUser.find(e => e.user == receiver.assignee);

          //console.log(">>>>>>>>>>>>>>>MAPPING USER: " , foundUserMapping);

          if (foundUserMapping == undefined) {
            var foundUserMapping = { user: receiver.assignee, id: mappingCounterUser };
            mappingUser.push(foundUserMapping);
            mappingCounterUser++;
          }

          //console.log(foundUserMapping);

          //console.log(">>>>>>>>>>>>>>>LOCAL KEYS BEFORE EXCHANGE:", localKeysBeforeExchange);
          //console.log(localKeysBeforeExchange[assignee]);
          //console.log(localKeysBeforeExchange[assignee][foundMappingDataObject.id + "&" + foundUserMapping.id]);

          payload = {};
          payload[foundMappingDataObject.id + "&" + foundUserMapping.id] = localKeysBeforeExchange[assignee][foundMappingDataObject.id + "&" + foundUserMapping.id];

          console.log("Exchange Task exchanging Key for participant ", foundUserMapping.user + ":", localKeysBeforeExchange[assignee][foundMappingDataObject.id + "&" + foundUserMapping.id]);

          var callEvent = await activeContract.methods.callWriteToChainEvent(instanceID, JSON.stringify(payload));
          var estimatedGas = await callEvent.estimateGas();

          //console.log("ESTIMATED GAS: ", estimatedGas);

          totalGasCosts = totalGasCosts + estimatedGas;
          estimatedKeyGas = estimatedKeyGas + (estimatedGas - 25000);
          gasCostsWithoutStartFee = gasCostsWithoutStartFee + (estimatedGas - 25000);

          //console.log(methodName, "TOTAL GAS USED: " + totalGasCosts);
          //console.log(methodName, "TOTAL GAS without start fee: " + gasCostsWithoutStartFee);

          await activeContract.methods.callWriteToChainEvent(instanceID, JSON.stringify(payload)).send({
            from: accountAddress[0],
            gas: estimatedGas
          });

        }

      }

      updateCSV(estimatedGas, foundServiceTask.name, description);
      taskService.complete(task);
      console.log(methodName, "Task completed!");

    } catch (e) {
      console.error(e);
    }

  });

  client.subscribe("voting", async function ({ task, taskService }) {
    let methodName = ">>> [voting Service-Call]: ";

    var variables = new Variables();

    //console.log(methodName, "Starting the Collect-Votes Procedure...");

    var url = "http://localhost:8080/engine-rest/process-definition/" + task.processDefinitionId + "/xml";

    var response = await nodeFetch(url);
    var data = await response.json();
    var parsedXML = await parseXML2JSON(data.bpmn20Xml);

    var serviceTasks = parsedXML[c_definitions][c_process][c_serviceTasks];

    if (!Array.isArray(serviceTasks)) {
      serviceTasks = [serviceTasks];
    }

    var foundServiceTask = serviceTasks.find(e => e.id == task.activityId);

    var description = JSON.parse(foundServiceTask[c_documentation][c_nodeId]);

    var deciderNotPassed = false;
    var gateway = description.gateway;

    if(description.gatewayDecider != undefined){

      // normal voting mode
      var gatewayDecider = description.gatewayDecider;
      var gatewayLoop = description.gatewayLoop;
      var maxLoops = description.loops;
      var agreementCount = description.sameDecision;
      deciderNotPassed = true;


      console.log("Decider: ", gatewayDecider);
      console.log("Loop: ", gatewayLoop);
      console.log("Gateway: ", gateway);

    } else {

      // decider mode
      var maxLoops = 1;
      var agreementCount = 1;

      console.log("Gateway: ", gateway);

    }

    // get the results from the contract storage

    var accountAddress = await ChainClientInstance.getUnlockedAccountAddress(0);
    var estimatedGas = await activeContract.methods.evaluateVotes(agreementCount, maxLoops).estimateGas();

    console.log("Estimated Gas for evaluateVotes-Call: ", estimatedGas);
    totalGasCosts = totalGasCosts + estimatedGas;

    // evaluate the Votes on the Chain
    await activeContract.methods.evaluateVotes(agreementCount, maxLoops).send({
      from: accountAddress[0],
      gas: estimatedGas
    });

    // get the Evaluation result
    var result = await activeContract.methods.callGetEvaluatedVotes().call();

    //var evaluationResult = result.map(e => Web3.utils.hexToUtf8(e));

    console.log("Evaluation Result: ", result);
    console.log(maxLoops);
    console.log(agreementCount);

    switch (Number.parseInt(result)) {
      case 0:

        if(deciderNotPassed){
          // agreed and true
          variables.set(gatewayDecider, "no");
          variables.set(gatewayLoop, "no");

        }

        variables.set(gateway, "yes");

        break;
      case 1:

        if(deciderNotPassed){
          // agreed and false
          variables.set(gatewayDecider, "no");
          variables.set(gatewayLoop, "no");
          
        }

        variables.set(gateway, "no");
        
        break;
      case 2:
      
        // no agreement and loop
        variables.set(gatewayLoop, "yes");

        break;
      case 3:

        // no agreement and decider     
        variables.set(gatewayLoop, "no");
        variables.set(gatewayDecider, "yes");

        break;
    }

    updateCSV(estimatedGas, foundServiceTask.name, description);

    taskService.complete(task, variables);
    console.log(methodName, "Task completed!");

  });

}

function updateAvailableKeysForCurrentUser(payload) {
  let methodName = consoleIterationInfo + " >>> [updateAvailableKeysForCurrentUser]: ";

  try {

    for (var key in payload) {
      if (key.length > 1) {

        var dataObjectMapping = key.substring(0, key.search("&"));
        var memberMapping = key.substring(key.search("&") + 1, key.length);

        var foundUser = mappingUser.find(e => e.id == memberMapping);
        var foundDataObject = mappingDataObject.find(e => e.id == dataObjectMapping);

        if (availableKeyForUser[foundUser.user] == undefined) {
          availableKeyForUser[foundUser.user] = {};
        }

        availableKeyForUser[foundUser.user][foundDataObject.dataObject] = { key: payload[key] };

      }
    }

  } catch (e) {
    console.error(methodName, e);
  }

}

async function completeTask(_taskId, _data, _name, _description, _estimateGas, _estimatedDataGas, _estimatedKeyGas) {
  let methodName = consoleIterationInfo + " >>> [completeTask]: ";

  try {

    var url = "http://localhost:8080/engine-rest/task/" + _taskId + "/complete";
    var response = await nodeFetch(url, {
      headers: {
        'Content-Type': 'application/json'
      },
      method: 'POST',
      body: JSON.stringify(_data)
    });

    updateCSV(_estimateGas, _name, _description);

    console.log(methodName, "Task completed!");

  } catch (e) {
    console.error(e);
  }

}

async function readFromChain(inputData, ChainClientInstance) {
  let callName = consoleIterationInfo + " >>> [readFromChain]: ";

  try {

    console.log("");
    console.log("#############################################################");
    console.log("<<<<<<< USER TASK: ", inputData.name, " >>>>>>>");
    console.log("#############################################################");

    var description = JSON.parse(inputData.description);
    var assigneeKeys = [];
    var chainData = [];

    var keysForCurrentMember = availableKeyForUser[inputData.assignee];

    for (var dataKey in keysForCurrentMember) {
      assigneeKeys.push({ member: inputData.assignee, dataObject: dataKey, key: keysForCurrentMember[dataKey].key });
    }

    var accountAddress = await ChainClientInstance.getUnlockedAccountAddress(userMapping[inputData.assignee]);

    activeWrapperTask = new WrapperTask(description, inputData.assignee, inputData.name, inputData.id, assigneeKeys, accountAddress, publicKeys, availableKeyForUser, useOffChain);

    if (activeWrapperTask.getIncomingData.length > 0) {

      if(localKeysBeforeExchange == undefined){
        localKeysBeforeExchange = {};
      }

      //console.log(keysForCurrentMember);

      // reading data, store the keys at the user, for future readings
      var foundUserMapping = mappingUser.find(e => e.user == inputData.assignee);

      for(var data in keysForCurrentMember){

        var keyObject = keysForCurrentMember[data];
        var foundMappingDataObject = mappingDataObject.find(e => e.dataObject == data);

        if(localKeysBeforeExchange[inputData.assignee] == undefined){
          localKeysBeforeExchange[inputData.assignee] = {};
        }

        localKeysBeforeExchange[inputData.assignee][foundMappingDataObject.id + "&" + foundUserMapping.id] = keyObject.key;
        var createdKeysForExchange = await activeWrapperTask.createEncryptedKeysForExchange(keyObject.key);

        if(activeWrapperTask.isStrongDynamic){

          for(var createdKey of createdKeysForExchange){

            var foundUserMapping = mappingUser.find(e => e.user == createdKey.user);
            localKeysBeforeExchange[inputData.assignee][foundMappingDataObject.id + "&" + foundUserMapping.id] = createdKey.key;

          }

        }

      }

      console.log("Retrieved key/s for participant ", inputData.assignee , keysForCurrentMember);
      //console.log(callName, activeWrapperTask.getIncomingData);

      for (var i = 0; i < activeWrapperTask.getIncomingData.length; i++) {

        var dataObjectShort = await findOccurenceInString(activeWrapperTask.getIncomingData[i].name, "[", "]");

        var found = publicDataWritten.find(e => e == dataObjectShort);
        
        if(found != undefined){
        // reading public data from contract storage

          var foundMappingDataObject = mappingDataObject.find(e => e.dataObject == activeWrapperTask.getIncomingData[i].name);
          //console.log(foundMappingDataObject);

          var publicData = await activeContract.methods.callGetStoredDataInContract(foundMappingDataObject.id).call();

          //console.log(JSON.parse(publicData));

          chainData.push({ dataObjectName: activeWrapperTask.getIncomingData[i].name, data: JSON.parse(publicData) });

        
        }else{
        // reading encrypted data from contract log

          /* var log = await activeContract.getPastEvents('WriteToChain', {
            filter: { instanceId: instanceID },
            fromBlock: 0,
            toBlock: 'latest'
          }, (err, log) => {
            console.log("ERROR: ", err);
            console.log("LOG: ", log);
            if(err != null){
              console.error(err);
            }
            return log;
          }); */

          dataStorage = [];

          if(useOffChain){
            dataStorage = offChainStorage;
          }else{
            dataStorage = currentContractLogState;
          }

          var logForCurrentData = [];

          for (var j = 0; j < dataStorage.length; j++) {

            var mappingObject = mappingDataObject.find(e => e.dataObject == activeWrapperTask.getIncomingData[i].name);
            var payload;

            if(useOffChain){
              payload = dataStorage[j];
            }else{
              payload = JSON.parse(dataStorage[j].returnValues.payload);
            }
            

            //console.log("MappingObject: ", mappingObject);
            //console.log("Payload: ", payload);

            if (mappingObject != undefined) {
              if (payload[mappingObject.id] != undefined) {

                //console.log(mappingObject.id);
                //console.log(payload);

                var data = payload[mappingObject.id];
                //console.log("data: ", data);
                var timestampOfChainData = data.substring(0, data.search("&"));
                //console.log("timestampOfChainData: ", timestampOfChainData);
                var dataWithoutTimeStamp = data.substring(data.search("&") + 1, data.length);
                //console.log("dataWithoutTimeStamp: ", dataWithoutTimeStamp);
                logForCurrentData.push({ dataObjectName: activeWrapperTask.getIncomingData[i].name, timestamp: timestampOfChainData, data: dataWithoutTimeStamp });

              }
            }
          }

          var decryptedData;

          if (logForCurrentData[0] != undefined) {

            var currentLogData = logForCurrentData[0];

            if (logForCurrentData.length > 1) {

              var currentTime = Date.now();
              var threshhold = currentTime;

              for (x in logForCurrentData) {
                var logData = logForCurrentData[x];

                var subtractedTime = currentTime - parseInt(logData.timestamp);

                if (threshhold > subtractedTime) {
                  threshhold = subtractedTime
                  currentLogData = logData;

                }
              }
            }

            var cipherData;

            // if data was not encrypted --> plain JSON object stringified, therefore first character '[' and last character ']'
            if(currentLogData.data.charAt(0) == "[" && currentLogData.data.charAt(currentLogData.data.length -1 ) == "]"){
              cipherData = currentLogData.data
            }else{
              cipherData = new Buffer.from(currentLogData.data, 'hex');
              cipherData = cipherData.toString('hex');
            }

            var cipherObject = {
              data: cipherData,
              dataObject: currentLogData.dataObjectName
            }

            decryptedData = await activeWrapperTask.decryptTaskData(cipherObject);

            chainData.push({ dataObjectName: currentLogData.dataObjectName, data: decryptedData });

          } else {

            decryptedData = "-- DataObject is empty --";
            chainData.push({ dataObjectName: activeWrapperTask.getIncomingData[i].name, data: decryptedData });

          }

        }

      }

    } else {
      console.log(callName, "No incoming Dataobject for " + activeWrapperTask.getName);
    }

    return chainData;

  } catch (e) {
    console.error(callName, e);
  }

}

function updateCSV(_costs,_name, _description){
  let methodName = consoleIterationInfo + " >>> [updateCSV]: ";

  var newLine = "\r\n";
  var fields = ['Sphere','Task','Cost'];

  try{

    if(_costs > 0){

      console.log(methodName, "TOTAL GAS USED: " + totalGas);
      console.log(methodName, "TOTAL GAS without start fee: " + gasCostsWithoutStartFee);

      if(useDecisionProbability){

        decisions = _description.decision;

        var probability = 1;

        for(var x of decisions){

          if(probability == 0){
            probability = 0.5;
          }else{
            probability = probability * 0.5;
          }

        }

        console.log("before: ", totalGas);
        totalGas = totalGas + Number.parseInt(_costs * probability);
        console.log("after: ", totalGas , probability);
        
      }else{
        console.log("before: ", totalGas);
        totalGas = totalGas + _costs;
        console.log("after: ", totalGas);
      }

    }

      fs.access(fileCsv, fs.constants.F_OK, (err) => {
  
        // File exists
        if(!err){
  
          var csvData = [{
            'Sphere':'Public',
            'Task': _name,
            'Cost': totalGas
          }];
  
          var csv = json2csv(csvData, {header: false}) + newLine;
  
          fs.appendFile(fileCsv, csv, (err) => {
            if(err) throw err;
            console.log(methodName, "Data was successfully appended to CSV File!");
          });
  
        }else{
  
          fields = (fields + newLine);
  
          fs.writeFile(fileCsv, fields, (err) => {
            if(err) throw err;
            console.log(methodName, "Created CSV File!")
          })
  
        }
  
      });

  }catch(e){
    console.error(e);
  }

}

async function writeCostsToSheet(totalCosts,dataCosts,keyCosts){
  let methodName = ">>> [writeCostsToSheet]: ";

  try {

    var newLine = "\r\n";
    var fields = ['Iteration','TotalCost','DataCost','KeyCosts'];

    fs.access(fileCosts, fs.constants.F_OK, (err) => {
  
      // File exists
      if(!err){
  
        var csvData = [{
          'Iteration': IterationCounter,
          'TotalCost': totalCosts,
          'DataCost': dataCosts,
          'KeyCosts': keyCosts
        }];
  
        var csv = json2csv(csvData, {header: false}) + newLine;
  
        fs.appendFile(fileCosts, csv, (err) => {
          if(err) throw err;
          console.log(methodName, "Iteration " + IterationCounter + " done, Costs written to CSV-Sheet");
        });
  
      }else{
  
        fields = (fields + newLine);
  
        fs.writeFile(fileCosts, fields, (err) => {
          if(err) throw err;
          console.log(methodName, "Created CSV File!")
        })

        var csvData = [{
          'Iteration': IterationCounter,
          'TotalCost': totalCosts,
          'DataCost': dataCosts,
          'KeyCosts': keyCosts
        }];
  
        var csv = json2csv(csvData, {header: false}) + newLine;
  
        fs.appendFile(fileCosts, csv, (err) => {
          if(err) throw err;
          console.log(methodName, "Iteration " + IterationCounter + " done, Costs written to CSV-Sheet");
        });
  
      }
  
    });

  }catch(e){
    console.error(methodName, e);
  }
}

async function evaluateDecision(description, chainData) {
  let methodName = ">>> [evaluateDecision]: ";

  try {

    var evaluationString = description.decisionExpressionPostfix;

    var evaluationLegend = description.decisionLegend;

    var stackArithmetic = [];
    var stackLogic = [];

    var operatorType;
    var firstStackValue;
    var secondStackValue;

    for (var character of evaluationString) {

      // if the current character is an operator
      if (operators.find(e => e == character) != undefined) {

        //what type of operator is the current character?
        operatorType = operatorsLegend[character];

        switch (operatorType) {
          //if the operator is arithemtic -> operate on first stack
          case arithmetic:

            secondStackValue = (+stackArithmetic.pop());
            firstStackValue = (+stackArithmetic.pop());

            if (character == "+") {

              stackArithmetic.push((firstStackValue + secondStackValue));

            }

            if (character == "-") {

              stackArithmetic.push((firstStackValue - secondStackValue));

            }

            if (character == "*") {

              stackArithmetic.push((firstStackValue * secondStackValue));

            }

            if (character == "/") {

              stackArithmetic.push((firstStackValue / secondStackValue));

            }

            break;
          //if the operator is logic -> operate on second stack
          case logic:

            secondStackValue = stackLogic.pop();
            firstStackValue = stackLogic.pop();

            if (character == "&") {

              stackLogic.push((firstStackValue && secondStackValue));

            }

            if (character == "|") {

              stackLogic.push((firstStackValue || secondStackValue));

            }


            break;
          //if the operator is comparsion -> evaluate and write to second stack
          case comparsion:

            secondStackValue = (+stackArithmetic.pop());
            firstStackValue = (+stackArithmetic.pop());

            if (character == ">") {

              stackLogic.push(firstStackValue > secondStackValue);

            }

            if (character == "<") {

              stackLogic.push(firstStackValue < secondStackValue);

            }

            if (character == "=") {

              stackLogic.push(firstStackValue == secondStackValue);

            }

            if (character == "!") {

              stackLogic.push(firstStackValue != secondStackValue);

            }

            break;
        }

      }

      // if the current character is a variable or constant
      if (operators.find(e => e == character) == undefined) {

        //lookup the variable or constant in the legend
        var variable = evaluationLegend[character];

        // if it is a variable from a dataObject
        if (variable.includes(".")) {

          var dataObjectLegend = variable.substring(0, 2);
          var dataObjectVariableLegend = variable.substring(3);

          if (description[dataObjectLegend] != undefined) {

            // get the chainData for the Data object

            for (var i = 0; i < description[dataObjectLegend].length; i++) {

              if (description[dataObjectLegend][i].name == dataObjectVariableLegend) {

                for (var chainEntry of chainData) {

                  dataEntry = await findOccurenceInString(chainEntry.dataObjectName, "[", "]");

                  if (dataEntry == dataObjectLegend) {

                    var enteredData = chainEntry.data.split(",");
                    enteredData[0] = enteredData[0].substring(1, enteredData[0].length);
                    enteredData[enteredData.length - 1] = enteredData[enteredData.length - 1].substring(0, enteredData[enteredData.length - 1].length - 1);

                    stackArithmetic.push(enteredData[i]);

                  }
                }

              }

            }

          }

          // its a constant: add it directly to the stack
        } else {

          stackArithmetic.push(variable);

        }

      }

    }

    var result = stackLogic.pop();

    return result;

  } catch (e) {
    console.error(methodName, e);
  }

}

async function findOccurenceInString(_input, _symbolFrom, _symbolTo) {
  let methodName = ">>> [findOccurenceInString]: ";

  try {

    var startIndex = _input.indexOf(_symbolFrom);
    var endIndex = _input.indexOf(_symbolTo);

    return _input.slice(startIndex + 1, endIndex);

  } catch (e) {
    console.error(methodName, e);
  }

}

async function createRandomString(length) {
  let methodName = ">>> [createRandomString]: ";

  try {

    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    var charactersLength = characters.length

    for (var i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }

    return result;

  } catch (e) {
    console.error(methodName, e);
  }
}

async function createRandomNumber(range) {
  let methodName = ">>> [createRandomNumber]: ";

  try {

    var number = Math.random() * range + "";
    var fixedNumber = Number.parseFloat(number).toFixed(2);

    return fixedNumber;

  } catch (e) {
    console.error(methodName, e);
  }
}

async function createRandomBoolean() {
  let methodName = ">>> [createRandomBoolean]: ";

  try {

    if (Math.random() < 0.5) {
      return "false";
    } else {
      return "true";
    }

  } catch (e) {
    console.error(methodName, e);
  }
}

async function parseXML2JSON(xmlFile) {
  let methodName = ">>> [importXMLAndParse]: ";

  try {

    var options = {
      object: true,
      reversible: true,
      coerce: false,
      sanitize: true,
      trim: true,
      arrayNotation: false,
      alternateTextNode: false
    }
    var jsonFile = parser.toJson(xmlFile, options);

    return jsonFile;

  } catch (e) {
    console.error(methodName, e);
  }

}