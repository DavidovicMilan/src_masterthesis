#!/bin/bash
geth attach --preload "CheckForWork.js"
