'use strict';

const debugMode = true;

const fs = require('fs');
const parser = require('xml2json');
const crypto = require('crypto');
const { json } = require('body-parser');
const { create } = require('domain');

const jsonDecisionsFile = "decisions.json";
const xmlPath = "/Users/milandavidovic/masterthesis/exportedBPMNs/";

const c_camundaDef = 'xmlns:camunda';
const c_start = 'bpmn:startEvent';
const c_end = 'bpmn:endEvent';
const c_definitions = 'bpmn:definitions';
const c_process = 'bpmn:process';
const c_data = 'bpmn:dataObject';
const c_dataRef = 'bpmn:dataObjectReference';
const c_tasks = 'bpmn:task';
const c_userTasks = 'bpmn:userTask';
const c_serviceTasks = 'bpmn:serviceTask';
const c_inData = 'bpmn:dataInputAssociation';
const c_outData = 'bpmn:dataOutputAssociation';
const c_source = 'bpmn:sourceRef';
const c_target = 'bpmn:targetRef';
const c_exclusive = 'bpmn:exclusiveGateway';
const c_parallel = 'bpmn:parallelGateway';
const c_in = 'bpmn:incoming';
const c_out = 'bpmn:outgoing';
const c_sequenceFlow = 'bpmn:sequenceFlow';
const c_diagram = "bpmndi:BPMNDiagram";
const c_diagramPlane = "bpmndi:BPMNPlane";
const c_shape = "bpmndi:BPMNShape";
const c_edge = "bpmndi:BPMNEdge";
const c_label = "bpmndi:BPMNLabel";
const c_bounds = "dc:Bounds";
const c_waypoint = "di:waypoint";
const c_property = "bpmn:property";
const c_nodeId = "$t";
const c_documentation = "bpmn:documentation";
const c_assignee = "camunda:assignee";
const c_type = "camunda:type";
const c_association = "bpmn:association";
const c_annotation = "bpmn:textAnnotation";
const c_text = "bpmn:text";
const c_form = "camunda:formKey";
const c_extension = 'bpmn:extensionElements';
const c_camundaProperties = 'camunda:properties';
const c_camundaProperty = 'camunda:property';
const c_conditionExpression = 'bpmn:conditionExpression';

const c_public = "Public";
const c_global = "Global";
const c_static = "Static";
const c_weakDynamic = "Weak-Dynamic";
const c_strongDynamic = "Strong-Dynamic";

const c_KeyExchange = "S";
var c_KeyExchangeCounter = 1;

const c_before = 0;
const c_after = 1;

const c_pathDecisionTraversing = 0;
const c_generatePaths = 1;
const c_forward = 2;
const c_backward = 3;
const c_branchAnalyze = 4;
const c_shareKeys = 5;

const shiftOffset = 130;

const avgCostTransactionCost = 21000;
const avgCostDataStorage = 5000;
const avgCostPerKeyStorageAndExchange = 27000;

var rawXmlFile;

var globalAnnotations;
var globalSphereParticipants = [];
var publicSphereParticipants = [];

var startTask;
var shareKeyID;

const c_taskType = "Task";
const c_eventType = "Event";
const c_gatewayType = "Gateway";

var possiblePathsForEachTaskWeakDynamic = [];
var possiblePathsForEachTaskStrongDynamic = [];

var allParticipants = [];

var allPossibleSpheres = [];

var allAugmentedPaths = [];

var currentReceivers = [];

// async reading of file
const readFile = (path, opts = 'utf8') =>
  new Promise((resolve, reject) => {
    fs.readFile(path, opts, (err, data) => {
      if (err){
        reject(err)
      }else{
        resolve(data)
      }  
    })
  });

// async reading of directory
const readDir = (path, opts = 'utf8') =>
new Promise((resolve, reject) => {
  fs.readdir(path, opts, (err, data) => {
    if (err){
      reject(err)
    }else{
      resolve(data)
    }  
  })
});

  // async writing to file
const writeFile = (path, data) =>
new Promise((resolve, reject) => {
  fs.writeFile(path, data, (err, data) => {
    if (err){
      reject(err)
    }else{
      resolve(data)
    }  
  })
});

// ###########################################################
// RUNNING MAIN() WHEN CALLING THE SCRIPT
// ###########################################################
main();
// ###########################################################
// ###########################################################

async function main(){
let methodName = ">>> [main]: ";
  // ##################################
  // ############ MAIN ################
  // ##################################
  try{
      checkInputParameters();
      console.log("################################################################################################################################################");
      console.log("######## Optimizing " + process.argv[2].toString() + " started... ########");
      var jsonObject =  await importXMLAndParse(rawXmlFile);

      console.time("execution");
      var newBusinessProcess = analyzeBusinessProcess(jsonObject);
      console.timeEnd("execution");

      //console.log("HERE:", newBusinessProcess);
      await exportJSONObject(newBusinessProcess);

      console.log("######## Optimizing finished! ########");
  }catch(e) {
    console.error(methodName, e);
    throw e;
  }
}

// ###########################################################
// ################### HELPER METHODS ########################
// ###########################################################

function checkInputParameters(){
let methodName = ">>> [checkInputParameters]: ";

// par1: name of the xml file to import
    if(process.argv[2] == null){
      console.log(">> Please provide parameters when calling the Script! par1 = <Name of the XML-File with .xml>");
      process.exit(1);
    }else{
      rawXmlFile = process.argv[2];
    }
}


async function importXMLAndParse(xmlFileName){
let methodName = ">>> [importXMLAndParse]: ";

  try{

    var data = await readFile(xmlPath + xmlFileName, 'utf8');

    var options = {
      object: true,
      reversible: true,
      coerce: false,
      sanitize: true,
      trim: true,
      arrayNotation: false,
      alternateTextNode: false
    }

    var jsonFile = parser.toJson(data, options);

    return jsonFile;

  }catch(e){
    console.error(methodName, e);
  }

}

async function exportJSONObject(jsonFile){
let methodName = ">>> [exportJSONObject]: ";

  try{
    
    var xmlFile = parser.toXml(jsonFile);
    await writeFile(xmlPath + "updatedBP.bpmn", xmlFile);

  }catch(e){
    console.error(methodName, e);
  }

}

function arrayEquals(array1, array2){
  let methodName = ">>> [arrayEquals]: "; 
  
    try{
  
      var result = (array1.length == array2.length) && array1.every((element, index) => {
          return element === array2[index]; 
      });
      return result;
  
    }catch(e){
      console.error(methodName, e);
    }
  
  }
  
  function containsArray(mainArray, arrayToTest){
      let methodName = ">>> [containsArray]: "; 
      
      try{
  
        var result = true;
  
        if(arrayToTest.length > 0){
            result = arrayToTest.every((element) => {
                return mainArray.includes(element);
            });
        }
  
        return result;  
        
      }catch(e){
        console.error(methodName, e);
      }   
  }

  function containsArrayKeyCheck(mainArray, arrayToTest){
    let methodName = ">>> [containsArrayKeyCheck]: "; 

    try{

      var result = true;

      if(arrayToTest.length > 0){
        result = arrayToTest.every((element) => {
          return includesKeyValueEntry(mainArray, element);
        });
      }

      return result;

    }catch(e){
      console.error(methodName, e);
    }
  }

  function includesKeyValueEntry(array,candidate){
    let methodName = ">>> [includesKeyValueEntry]: "; 

    try{

      var found = false;

      var foundElement = array.find( element => {
        for(var key in element){
          if(element[key] == candidate[key]){
            found = true;
          }
        }

        if(found){
          return element;
        }
      });

      if(foundElement != undefined){
        return true;
      }else{
        return false;
      }

    }catch(e){
      console.error(methodName, e);
    }

  }
  
  function occursInArray(mainArray, arrayToTest){
    let methodName = ">>> [occursInArray]: "; 
    
    try{
  
      var foundDistributor = undefined;
  
      for(var i=0; i<mainArray.length; i++){
        for( var j=0; j<arrayToTest.length; j++){
          if(foundDistributor == undefined){
            if(mainArray[i].name === arrayToTest[j].name){
              foundDistributor = mainArray[i].name;
            }
          }
        }
      }
  
      return foundDistributor;
      
    }catch(e){
      console.error(methodName, e);
    }
  
  }
  
  function isInArray(_array,_data){
  let methodName = ">>> [isInArray]: "; 
  
    try{
  
      if(_array.length == 0){
        return false;
      }
  
      var foundItem = _array.find(e => {
        if(e.name == undefined || _data.name == undefined){
          if(e == _data){
            return e;
          }
        }else{
          if(e.name == _data.name){
            return e;
          }
        }
      });
    
      if(foundItem == undefined){
        return false;
      }else{
        return true;
      }
  
    }catch(e){
      console.error(methodName, e);
    }
    
  }

  function decisionArrayExists(_mainArray, _decisionsToAdd){
    let methodName = ">>> [compareDecisionArrays]: ";

    try{

      var result = false;

      // für jedes Array im de-Duplicated Array
      _mainArray.forEach( decisions => {

        for(var keyValueMain of decisions){
          for(var keyValueToAdd of _decisionsToAdd){
            if(keyValueMain.name == keyValueToAdd.name && keyValueMain.value == keyValueToAdd.value){
              result = true;
            }
          }
        }
        
      });

      return result;

    }catch(e){
      console.error(e);
    }

  }

  function mergeDecisions(_array1, _array2){
    let methodName = ">>> [mergeDecisions]: ";

    try{

      var isArr2Deep = false;
      var isArr1Deep = false;

      if(_array1.length == 0 && _array2.length == 0){
        return [];
      }

      var mergedArray;
      var copyMergedArray;
      var deDuplicatedArray = [];
      var deepArray1 = [_array1.slice()]
      var deepArray2 = [_array2.slice()];

      if(_array1[0] != undefined){
        if(Array.isArray(_array1[0])){
          isArr1Deep = true;
        }
      }

      if(_array2[0] != undefined){
        if(Array.isArray(_array2[0])){
          isArr2Deep = true;
        }
      }

      if(isArr1Deep && isArr2Deep){
        mergedArray = _array1.concat(_array2);
      }

      if(isArr1Deep && !isArr2Deep){
        mergedArray = _array1.slice();
        mergedArray.push(_array2);
      }

      if(!isArr1Deep && isArr2Deep){
        mergedArray = _array2.slice();
        mergedArray.push(_array1);
      }

      if(!isArr1Deep && !isArr2Deep){
        mergedArray = deepArray1.concat(deepArray2);
      }

      copyMergedArray = mergedArray.slice();

      copyMergedArray.forEach((element, index) => {
        if(element.length == 0){
          mergedArray.splice(index,1);
        }
      })

      mergedArray.forEach((subArray, index) => {
        var result = decisionArrayExists(deDuplicatedArray, subArray);
        if(!result){
          deDuplicatedArray.push(subArray);
        }
      });

      return deDuplicatedArray;

    }catch(e){
      console.error(e);
    }
  }

  function removeElement(_array, _element){
    let methodName = ">>> [remove]: ";

    try{

      _array.splice(_array.indexOf(_element), 1);

    }catch(e){
      console.error(methodName, e);
    }

  }

  function hasReceivedKey(_task, _decisions, _receivingTaskDecisions,_participant, _dataObject, _bp){
    let methodName = ">>> [hasReceivedKey]: ";

    try{

      var startTask = _bp[c_definitions][c_process][c_start];
      var result = createBPObjectsArray(_task, _bp);
      var bpChosenObject = result.startObject;
      var bpStartEvent = { type: c_start, decisions: [], bpObject: startTask, incomingDataObject: [], outgoingDataObject: [], initiatingDataObject: [] };
      var bpObjectsArrays = result.array;

      return keyReceiveCheckTraversing(bpStartEvent, bpChosenObject, _dataObject, _participant, _decisions, _receivingTaskDecisions, bpObjectsArrays, _bp);

    }catch(e){
      console.error(methodName, e);
    }

  }

  function generateAllPaths(_bp){
    let methodName = ">>> [generateAllPaths]: ";

    try{

      var startTask = _bp[c_definitions][c_process][c_start];
      var result = createBPObjectsArray(startTask, _bp);
      var bpStartEvent = { type: c_start, decisions: [], bpObject: startTask, incomingDataObject: [], outgoingDataObject: [], initiatingDataObject: [] };
      var bpObjectsArrays = result.array;
      var paths = [];

      var pathDecisions = pathDecisionTraversing(bpStartEvent, bpObjectsArrays, _bp);

      for(var decision of pathDecisions){
        paths.push({decision: decision, path: createPathsWithDecisions(bpStartEvent, decision, bpObjectsArrays, _bp)});
      }

      return paths;

    }catch(e){
      console.error(methodName, e);
    }
  }

  function augmentPath(_pathDecscription, _bp){
    let methodName = ">>> [augmentPath]: ";

    try{


      var participants = ["GP", "DI", "R", "I"];
      var augmentationsForPath = [];
      var spheresInCurrentPath = [];

      var decision = _pathDecscription.decision;
      var path = _pathDecscription.path;

      var sumCosts = 0;

      for(var currentObject of path){
        
        var documentation = JSON.parse(currentObject.bpObject[c_documentation][c_nodeId]);
        var foundSphere = documentation.spheres.find(e => e.sphereType == c_strongDynamic);

        if(foundSphere != undefined){
          spheresInCurrentPath.push(foundSphere);
        }

        sumCosts += calculateCostsForTask(currentObject.bpObject);
      }

      for(var sphere of spheresInCurrentPath){

        var dataObject = sphere.dataObject;

        for(var currentObject of path){

          for(var member of participants){
            //var result = hasReceivedKey(currentObject.bpObject, decision, member, dataObject, _bp);
            //console.log("Participant <" + member + "> hat den Schlüssel für das Datenobjekt <" + dataObject + "> bei der Position <" + currentObject.bpObject.name + "> ====>", result);
          }
        }

      }

    }catch(e){
      console.error(methodName, e);
    }

  }

  function setDecisionsInTasks(bp, startTask){
    let methodName = ">>> [setDecisionsInTasks]: ";

    try{

      var result = createBPObjectsArray(startTask, bp);
      var bpStartObject = result.startObject;
      var bpObjectsArray = result.array;

      forwardTraversing(bpStartObject, bpObjectsArray, bp);

    }catch(e){
      console.error(methodName,e);
    }

  }

  function findLateSendPosition(bp, dataObject, decision, startTask){
    let methodName = ">>> [findLateSendPosition]: ";

    try{

      var result = createBPObjectsArray(startTask, bp);
      var bpStartObject = result.startObject;
      var bpObjectsArrays = result.array;

      lateSendTraversing(bpStartObject, dataObject, decision, bpObjectsArrays, bp);

    }catch(e){
      console.error(methodName,e);
    }

  }

  function calculateCostsForTask(_task){
    let methodName = ">>> [calculateCostsForTask]: ";

    try{

      var sumCosts = 0;

      // wenn es ein exchange-task ist
      if(_task.taskObject.length == 0){
        sumCosts += (avgCostDataStorage + avgCostPerKeyStorageAndExchange);
        return sumCosts;
      }

      // wenn es ein collect vote task ist
      if(_task.taskObject.id.match("Service_")){
        return sumCosts;
      }

      // wenn es gateways oder events sind
      if(_task.taskObject[c_documentation] == undefined){
        return sumCosts;
      }

      var documentation = JSON.parse(_task.taskObject[c_documentation][c_nodeId]);
      if(documentation.type == c_userTasks){
      // else lookup how many keys are exchanged plus one transaction cost
        for(var sphere in documentation.spheres){
          sumCosts += avgCostDataStorage;
  
          switch (sphere.sphereType) {
            case c_global:
  
              sumCosts += (sphere.members * avgCostPerKeyStorageAndExchange);
              
              break;
            case c_static:
              
              sumCosts += (sphere.members * avgCostPerKeyStorageAndExchange);
  
              break;
          
            case c_weakDynamic:
  
              sumCosts += (sphere.members * avgCostPerKeyStorageAndExchange);
              
              break;
          }
        }
      }

      return sumCosts;

    }catch(e){
      console.error(methodName, e);
    }

  }


  // ###########################################################
  // ############### TRANSFORMATION METHODS ####################
  // ###########################################################


/**
 * 
 * @desc       create the Wrapper Tasks from all Tasks which operate with Data-Objects
 * 
 * @param bp   the imported business process as JSON
 */

function analyzeBusinessProcess(bp){
let methodName = ">>> [analyzeBusinessProcess]: ";

  try{

    var dataRef = bp[c_definitions][c_process][c_dataRef];
    var tasks = bp[c_definitions][c_process][c_tasks];
    var userTasks = bp[c_definitions][c_process][c_userTasks];
    var definition = bp[c_definitions];
    var annotations = bp[c_definitions][c_process][c_annotation];
    var associations = bp[c_definitions][c_process][c_association];

    var dataObjects = [];

    globalAnnotations = []; 

    if(definition[c_camundaDef] == undefined){
      definition[c_camundaDef] = 'http://camunda.org/schema/1.0/bpmn'
    }
  
    startTask = bp[c_definitions][c_process][c_start];

    if(!Array.isArray(dataRef)){
      dataRef = [dataRef];
    }
    if(!Array.isArray(annotations)){
      annotations = [annotations];
    }
    if(!Array.isArray(associations)){
      associations = [associations];
    }

    // #######################
    // ## shorten the names ##
    // #######################

    if(bp[c_definitions][c_process][c_userTasks] != undefined){
      for(var currentUserTask of bp[c_definitions][c_process][c_userTasks]){

        var name = currentUserTask.name;
        var nameOfParticipant = findOccurenceInString(name,"[","]");

        switch (nameOfParticipant) {
          case "General Practitioner":

            name = name.replace(nameOfParticipant, "GP");        
            break;
          
          case "Diagnosis Institute":

            name = name.replace(nameOfParticipant, "DI"); 
            break;
          
          case "Rehabilitation Specialist":

            name = name.replace(nameOfParticipant, "R");
            break;

          case "Insurance Company":
            name = name.replace(nameOfParticipant, "I");
            break;
      
        }

        currentUserTask.name = name;

      }
    }

    for(var currentTask of bp[c_definitions][c_process][c_tasks]){

      var name = currentTask.name;
      var nameOfParticipant = findOccurenceInString(name,"[","]");

      switch (nameOfParticipant) {
        case "General Practitioner":

          name = name.replace(nameOfParticipant, "GP");        
          break;
        
        case "Diagnosis Institute":

          name = name.replace(nameOfParticipant, "DI"); 
          break;
        
        case "Rehabilitation Specialist":

          name = name.replace(nameOfParticipant, "R");
          break;

        case "Insurance Company":
          name = name.replace(nameOfParticipant, "I");
          break;
    
      }

      currentTask.name = name;

    }

    // ######################
    // get global Annotations
    // ######################

    for(var annotation of annotations){

      var foundAssociation = associations.find(e => e.targetRef == annotation.id);

      // has no association => global Annotation
      if(foundAssociation == undefined){

        var dataObject = findOccurenceInString(annotation[c_text][c_nodeId],'[',']');
        var defaultSphere = findOccurenceInString(annotation[c_text][c_nodeId],'{','}');
        globalAnnotations.push({dataObject: dataObject, defaultSphere: defaultSphere});
      }
    }
    

    // ###################################
    // change userTask with no doc to task
    // ###################################

    if(userTasks != undefined){
      if(!Array.isArray(userTasks)){
        userTasks = [userTasks];
      }

      for(userTask of userTasks){

        if(userTask[c_documentation] == undefined){

          var index = userTasks.indexOf(userTask);
          userTasks.splice(index, 1);
          bp[c_definitions][c_process][c_tasks].push(userTask);    
        }
  
      }

    }

    // ###################
    // create usertasks...
    // ################## 

    for(var i in dataRef){

      dataObjects.push(dataRef[i]);

      tasks.forEach(task => {
        createWrapper(bp,task);
      });

    }

    // ###########################################################
    // remove old generic tasks because usertasks are used instead
    // ###########################################################
    for(var currentUserTask of bp[c_definitions][c_process][c_userTasks]){
      var foundTask = bp[c_definitions][c_process][c_tasks].find( currentTask  => currentTask.id == currentUserTask.id);
      removeElement(bp[c_definitions][c_process][c_tasks], foundTask);
    }

    // ###########################################################
    // adapt usertasks which were already present / adapt names
    // ###########################################################
    for(var currentUserTask of bp[c_definitions][c_process][c_userTasks]){

        if(currentUserTask[c_assignee] == undefined){

          var assignee = findOccurenceInString(currentUserTask.name, "[", "]");
          currentUserTask[c_form] = "embedded:deployment:formInput.html";
          currentUserTask[c_assignee] = assignee;

          if(currentUserTask[c_documentation] == undefined){

            currentUserTask[c_documentation] = {
              $t: undefined
            };

          }
        }
    }

    // ###########################################################
    // set expressions on edges -> needed for engine
    // ###########################################################

    for(var edge of bp[c_definitions][c_process][c_sequenceFlow]){

      if(edge.name != undefined){

        var gateway = bp[c_definitions][c_process][c_exclusive].find(e => e.id == edge.sourceRef);

        if(edge.name == 'yes'){
          edge[c_conditionExpression] = {"xsi:type": "bpmn:tFormalExpression", "$t": "${" + gateway.name + "=='yes'}"};
        }

        if(edge.name == 'no'){
          edge[c_conditionExpression] = {"xsi:type": "bpmn:tFormalExpression", "$t": "${" + gateway.name + "=='no'}"};
        }

      }

    }

    // ###########################################################
    // adapt serviceTask IDs if any serviceTasks present
    // ###########################################################

    if(bp[c_definitions][c_process][c_serviceTasks] != undefined){

      var serviceTasks = bp[c_definitions][c_process][c_serviceTasks];

      if(!Array.isArray(serviceTasks)){
        serviceTasks = [serviceTasks];
      }

      for(var serviceTask of serviceTasks){

        var incomingEdge = bp[c_definitions][c_process][c_sequenceFlow].find(e => e.targetRef == serviceTask.id);
        var outgoingEdge = bp[c_definitions][c_process][c_sequenceFlow].find(e => e.sourceRef == serviceTask.id);
        var visualService = bp[c_definitions][c_diagram][c_diagramPlane][c_shape].find( e => e.bpmnElement == serviceTask.id);

        var updatedId = serviceTask.id.replace("BusinessRuleTask_", "Service_");

        if(updatedId == serviceTask.id){
          updatedId = serviceTask.id.replace("Task_", "Service_");
        }

        serviceTask.id = updatedId;

        if(incomingEdge != undefined){
          incomingEdge.targetRef = serviceTask.id;
        }

        if(outgoingEdge != undefined){
          outgoingEdge.sourceRef = serviceTask.id;
        }

        visualService.bpmnElement = serviceTask.id;
        visualService.id = serviceTask.id + "_di";

      }
    }

    // ############################ 
    // documentation added to tasks
    // ############################

    for(var dataObject of dataObjects){
      updateTasks(bp, dataObject);
    }

    // ################### 
    // tree for traversing
    // ###################
    
    var tree = transformBusinessProcess(bp);

    // ############################
    // set the public and global 
    // Sphere for every public and 
    // global Writer and set the 
    // current sphere for each Data 
    // Object for every Reader
    // ############################

    for(var userTask of bp[c_definitions][c_process][c_userTasks]){

      var documentation = JSON.parse(userTask[c_documentation][c_nodeId]);

      // if the user task is not a voting task

      if(documentation.type != undefined){
        for(var sphere of documentation.spheres){

          if(sphere.sphereType == c_public && isInArray(documentation.outgoingData, {name: sphere.dataObject})){
            sphere.members = publicSphereParticipants;
          }
          if(sphere.sphereType == c_global && isInArray(documentation.outgoingData, {name: sphere.dataObject})){
            sphere.members = globalSphereParticipants;
          }      
        }
        userTask[c_documentation][c_nodeId] = JSON.stringify(documentation);
      } 
    }

    // ############################
    // traverse Tree and analyze 
    // strong / weak dynamic cases 
    // ############################

    traverseTree(tree, bp);

    var paths = generateAllPaths(bp);
    //paths.forEach( p => augmentPath(p,bp));

    setDecisionsInTasks(bp, startTask);

    var userTasks = bp[c_definitions][c_process][c_userTasks];

    if(!Array.isArray(userTasks)){
      userTasks = [userTasks];
    }

    for(var pathOfTask of possiblePathsForEachTaskStrongDynamic){
      var foundTask = userTasks.find( e => e.name == pathOfTask.taskObject.name);
      if(foundTask != undefined){
        for(var decision of pathOfTask.pathDecisions){
          console.log("############CURRENT DECISION:", decision);
          findLateSendPosition(bp, pathOfTask.dataObject.name, decision, pathOfTask.taskObject);
        }
      }
    }

    //for(var i of allAugmentedPaths){
      //console.log("Data Object", i.dataObject);
      //console.log("Decision", i.decision);
      //for( var j of i.augmentedPaths){
        //console.log("Path", j);
      //}
    //}

    var allPossibleDecisions = [];

    for(var i of allAugmentedPaths){
      //allPossibleDecisions = mergeDecisions(allPossibleDecisions, i.decision);
    }

    var obj = {
      decisions: []
    };

    for(var i of paths){
      obj.decisions.push(i.decision);
    }

    console.log(obj.decisions.length);

    let json = JSON.stringify(obj);
    fs.writeFile(jsonDecisionsFile, json);

    // für jede mögliche decision
    for(var decision of allPossibleDecisions){
      // betrachte alle möglichen augmentierten Teilpfade
      for(var i of allAugmentedPaths){
        // wenn teilpfad zur aktuellen decision gefunden wurde
        if(JSON.stringify(decision[0]) == JSON.stringify(i.decision[0])){
          for( var j of i.augmentedPaths){
            //console.log(j);
          }
        }
      }
    }

    var newBusinessProcesses = [];
    //copy the bp
    var testBusinessProcess = JSON.parse(JSON.stringify(bp));

    //EMPTY LOGIC

    //empty start
    testBusinessProcess[c_definitions][c_process][c_start] = {};
    //empty end
    testBusinessProcess[c_definitions][c_process][c_end] = {};
    //empty all sequence flows
    testBusinessProcess[c_definitions][c_process][c_sequenceFlow] = [];
    //empty all userTasks 
    testBusinessProcess[c_definitions][c_process][c_userTasks] = [];
    //empty all XORs (if any)
    if(testBusinessProcess[c_definitions][c_process][c_exclusive] != undefined){
      testBusinessProcess[c_definitions][c_process][c_exclusive] = [];
    }
    //empty all Parallels (if any)
    if(testBusinessProcess[c_definitions][c_process][c_parallel] != undefined){
      testBusinessProcess[c_definitions][c_process][c_parallel] = [];
    }

    //EMPTY VISUALS

    //empty all sequence flows coordinates
    testBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge] = [];

    testBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape] = [];
    //console.log(testBusinessProcess);

    //calculate Costs of all paths

    // betrachte alle möglichen augmentierten Teilpfade
    for(var pathMetadata of allAugmentedPaths){
      // wenn teilpfad zur aktuellen decision gefunden wurde
      for(var receiver of pathMetadata.receivers){
        for(var augmentedPath of pathMetadata.augmentedPaths[receiver]){
          // für jeden Task
          var sumCost = 0;
          for(var task of augmentedPath.path){

            //console.log("TASK:", task.name);

            if(task.taskObject[c_documentation] != undefined){

              if(!task.taskObject.id.match("Service_")){

                var documentation = JSON.parse(task.taskObject[c_documentation][c_nodeId]);

                var foundSphere = documentation.spheres.find(e => {
                  if(e.sphereType == c_strongDynamic && e.dataObject == pathMetadata.dataObject){
                    return e;
                  }
                });

                // the writing task is in a strong dynamic sphere
                if(foundSphere != undefined){
                  // the writing task is also exchanging the keys directly
                  if(augmentedPath.mergedKeyExchange != undefined){
                    if(augmentedPath.mergedKeyExchange.find(e => e == task.name) != undefined){
                      sumCost += avgCostTransactionCost;
                    }
                  }
                }else{
                  sumCost += avgCostTransactionCost;
                }

              }

            }
  
              var cost = calculateCostsForTask(task);
              sumCost += cost;
    
          }

          augmentedPath.totalCost = sumCost;
          //console.log(augmentedPath.totalCost);
          //console.log(augmentedPath);
        }
      }
    }
    // sort all paths with the lowest cost first

    var sortedPaths = [];

    for(var pathMetadata of allAugmentedPaths){

      var receiversAugmentedPaths = {};
      
      for(var receiver of pathMetadata.receivers){

        if(receiversAugmentedPaths[receiver] == undefined){
          receiversAugmentedPaths[receiver] = [];
        }

        var augmentedPaths = pathMetadata.augmentedPaths[receiver].slice();

        augmentedPaths.sort( (a,b) => {
          return a.totalCost - b.totalCost;
        });

        receiversAugmentedPaths[receiver].push(augmentedPaths);

      }

      var deDuplicatedDecisions = [];

      for(var decision of pathMetadata.decision){

        var foundAlreadyAddedDecision = deDuplicatedDecisions.find(e => {
          if(e.name == decision.name && e.value == decision.value){
            return e;
          }
        });

        if(foundAlreadyAddedDecision == undefined){
          deDuplicatedDecisions.push(decision);
        }
      }

      sortedPaths.push({dataObject: pathMetadata.dataObject, receivers: pathMetadata.receivers, augmentedPaths: receiversAugmentedPaths, decisions: deDuplicatedDecisions, sendingTask: pathMetadata.sendingTask});
    }

    var newBusinessProcess = buildBusinessProcess2(sortedPaths, testBusinessProcess, bp);

    startTask = newBusinessProcess[c_definitions][c_process][c_start];

    var result = createBPObjectsArray(startTask, newBusinessProcess);

    var bpObjectsArrays = result.array; 
    var bpStartObject = { type: c_start, decisions: [], bpObject: startTask, incomingDataObject: [], outgoingDataObject: [], initiatingDataObject: [] };

    newBusinessProcess = updateServiceTasks(bpStartObject, bpObjectsArrays, newBusinessProcess);

    shareKeyID = 0;
    // MODULE 5: Key Sharing
    analyzeWritersAndReaders(newBusinessProcess);

    return newBusinessProcess;

    
  }catch(e){
    console.error(methodName, e);
  }

}

function updateServiceTasks(currentObject,bpObjectsArray, bp){
  let methodName = ">>> [forwardTraversing]: "; 
  
    try{
  
      var incomingEdges;
      var outgoingEdges;
      var nextObject;
      var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow]; 
      var currentObjectStack = [];
      var gateWaysStack = [];
      var reachedEndGateWay = false;

      var globalDecisions = [];
      var chosenEdgeLoop = null;


      // init stack
      currentObjectStack.push(currentObject);
  
      while(currentObjectStack.length > 0){

        incomingEdges = [];
        outgoingEdges = [];

        // hole Objekt aus dem Stack
        var currentObject = currentObjectStack.pop();

        // Wenn kein BPObjekt mehr vorhanden ist welches traversiert werden kann (also End Event wurde erreicht)
        if(currentObject == undefined){
          // Wenn noch Objekte im Stack liegen
          if(currentObjectStack.length > 0){
            // hole Objekt aus dem Stack
            currentObject = currentObjectStack.pop();
          }else{
            return bp;
          }
        }

        // set the current decision variables in this current path
        if(currentObject.decisions.length > 0){
          globalDecisions = globalDecisions.concat(currentObject.decisions);
        }

        if(currentObject.type == c_serviceTasks){
          if(currentObject.bpObject[c_documentation][c_nodeId] != undefined){
            var serviceTaskDocumentation = JSON.parse(currentObject.bpObject[c_documentation][c_nodeId]);
            serviceTaskDocumentation.decision = globalDecisions;

            for(var serviceTask of bp[c_definitions][c_process][c_serviceTasks]){    
              if(currentObject.bpObject.id == serviceTask.id){
                serviceTask[c_documentation][c_nodeId] = JSON.stringify(serviceTaskDocumentation);
              }
            }  
          }
        }

        // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
        if(currentObject.type == c_parallel || currentObject.type == c_exclusive){

            if(Array.isArray(currentObject.bpObject[c_in])){
              for(var edge of currentObject.bpObject[c_in]){
                incomingEdges.push(edge[c_nodeId]);
              }
            }else{
              incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
            }
            if(Array.isArray(currentObject.bpObject[c_out])){
              for(var edge of currentObject.bpObject[c_out]){
                outgoingEdges.push(edge[c_nodeId]);
              }
            }else{
              outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
            }

            // Wenn das Gateway einem Loop angehört -> Prüfe ob eingehendes oder ausgehendes
            if(currentObject.bpObject.name.includes("Loop")){

              // Loop-Gateway entscheidung -> immer nein da nicht geloopt wird
              if(outgoingEdges.length > incomingEdges.length){
                for(var edge of outgoingEdges){

                  if(chosenEdgeLoop != undefined){
                    continue;
                  }

                  chosenEdgeLoop = sequenceFlows.find(e => {
                    if(e.id == edge){
                      if(e.name == "no"){
                        return e;
                      }
                    }
                  });

                }
              }

            }else{

              if(outgoingEdges.length > incomingEdges.length){
                  for(var edge in outgoingEdges){
                    gateWaysStack.push(currentObject.bpObject.name);
                  }
              }

              if(outgoingEdges.length < incomingEdges.length){
                gateWaysStack.pop();
                if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
                  reachedEndGateWay = true;   
                }
                // reached the end Gateway -> remove Decision Variable because the Decision does not matter for the candidateObject
                globalDecisions = globalDecisions.filter( gateway => gateway.name != currentObject.bpObject.name);
              }

            }

        }

        var outcomingEdge = {};

        if(chosenEdgeLoop != null){

          outcomingEdge[c_nodeId] = chosenEdgeLoop.id;

        }else{

          // hole ausgehende Kante/n vom aktuellen BPObjekt 
          outcomingEdge = currentObject.bpObject[c_out];

        }

        // wenn es Kanten sind...
        if(Array.isArray(outcomingEdge)){
            for(var key in outcomingEdge){
              var edge = outcomingEdge[key][c_nodeId];

              // get edge description for outgoing edge from decision gateway
              if(currentObject.type == c_exclusive){
                var edgeDescription = sequenceFlows.find( e => e.id == edge);
              }

              nextObject = bpObjectsArray.find( processObject => {
                var ingoingEdges = processObject.bpObject[c_in];
                // wenn es mehrere eingehende Kanten vom Objekt sind...
                if(Array.isArray(ingoingEdges)){
                  for(var ingoingEdge of ingoingEdges){
                    if(edge != undefined && edge == ingoingEdge[c_nodeId]){
                      return processObject;
                    }   
                  }
                // nur eine ausgehende Kante
                }else{
                  if(edge != undefined && edge == ingoingEdges[c_nodeId]){
                    return processObject;
                  }    
                }
              });

              if(currentObject.type == c_exclusive && nextObject.bpObject.id == edgeDescription.targetRef && !nextObject.bpObject.name.includes("Loop")){
                if(edgeDescription.name != undefined){
                  nextObject.decisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});
                }
              }

              // lege auf den Stack
              if(reachedEndGateWay != true){
                currentObjectStack.push(nextObject);
              }
            }
            // ..ansonsten nur für eine Kante
        }else{
          nextObject = bpObjectsArray.find( processObject => {
            var ingoingEdges = processObject.bpObject[c_in];
            // wenn es mehrere ausgehende Kanten vom Objekt sind...
            if(Array.isArray(ingoingEdges)){
              for(var ingoingEdge of ingoingEdges){
                if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdge[c_nodeId]){
                  return processObject;
                }   
              }
            // nur eine eingehende Kante
            }else{
              if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdges[c_nodeId]){
                return processObject;
              }    
            }
          })
          // lege auf den Stack
          if(reachedEndGateWay != true){
          currentObjectStack.push(nextObject);
          }
        }

        chosenEdgeLoop = null;
        reachedEndGateWay = false;

    }
  
    }catch(e){
      console.error(methodName, e);
    }
  
}

function buildBusinessProcess2(sortedPaths, newBusinessProcess, bp){
  let methodName = ">>> [buildBusinessProcess]: ";  

  try{

    var incomingEdges;
    var outgoingEdges;
    var nextObject;
    var previousObject;
    var dataObjects = bp[c_definitions][c_process][c_dataRef];
    var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow]; 
    var currentObjectStack = [];
    var gateWaysStack = [];
    var reachedEndGateWay = false;

    var globalDecisions = [];
    var gatewaysPassed = [];

    var exchangeForReceiversAdded = [];

    var newExchangeTaskAdded;

    var possibleData = [];
    var visualsAlreadyAdjusted = [];
    var visualGatewaysAlreadyAdjusted = [];
    var visualGatewayAdjusted = false;

    var visualOffset = 0;
    var visualMedian = 0;
    const visualStandardWidth = 100;
    const visualStandardHeight = 80;

    var nextObject;

    var builtBusinessProcesses = []; 
    var chosenEdgeLoop = null;
    var loopEdgeChosen = false;

    //console.log(sortedPaths[0].augmentedPaths.Task_1yuchn6[0][0]);

    // get all relevant dataObjects
    for(var sortedPath of sortedPaths){
      if(!possibleData.includes(sortedPath.dataObject)){
        possibleData.push(sortedPath.dataObject);
      }
    }

    // add annotations shapes from those that are not bound to a task

    for(var annotation of newBusinessProcess[c_definitions][c_process][c_annotation]){

        var annotationVisual = bp[c_definitions][c_diagram][c_diagramPlane][c_shape].find(e => e.bpmnElement == annotation.id);
        annotationVisual[c_bounds].x =  ((+annotationVisual[c_bounds].x) + visualOffset).toString();
        newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape].push(annotationVisual);

    }

    // TODO:
    // 0. initially start with the start object
    // 1. create outgoing edge/s with help of old BP
    // 2. lookup the next object in the old BP
    // 3. compare with next object in the building path
    // 4. if not in building path or not same => add object to new BP and go to 1.
    //    else => create new exchange task and go to 1.


    // 0. Start Object

    var currentObject = bp[c_definitions][c_process][c_start];
    currentObjectStack.push(currentObject);

    var startObjectVisual = bp[c_definitions][c_diagram][c_diagramPlane][c_shape].find(e => e.bpmnElement == currentObject.id);
    var visualMedian = ((+startObjectVisual[c_bounds].y) + ((+startObjectVisual[c_bounds].height)/2));
    
    while(currentObjectStack.length > 0){

      currentObject = currentObjectStack.pop();

      // lookup if a receiverTask is now the currentObject
      for(var sortedPath of sortedPaths){

        var foundReceiver = sortedPath.receivers.find(e => e == currentObject.id);

        // if yes, delete all augmented Paths for this receiver because they are no longer relevant
        if(foundReceiver != undefined){
            delete sortedPath.augmentedPaths[currentObject.id];
        }
      
      }

      newExchangeTaskAdded = false;

      var currentObjectVisual = bp[c_definitions][c_diagram][c_diagramPlane][c_shape].find(e => e.bpmnElement == currentObject.id);

      if(currentObject.id.match("ExclusiveGateway_") || currentObject.id.match("ParallelGateway_")){

        var inEdge = currentObject[c_in];
        var outEdge = currentObject[c_out];

        if(!Array.isArray(inEdge)){
          inEdge = [inEdge];
        }

        if(!Array.isArray(outEdge)){
          outEdge = [outEdge];
        }

        if(inEdge.length > outEdge.length){

          if(visualGatewaysAlreadyAdjusted.find(e => e == currentObject.id) != undefined){

            currentObjectVisual[c_bounds].x = ((+currentObjectVisual[c_bounds].x) + visualOffset).toString();
            visualGatewayAdjusted = true;
  
            if(currentObjectVisual[c_label] != undefined){
              currentObjectVisual[c_label][c_bounds].x = ((+currentObjectVisual[c_label][c_bounds].x) + visualOffset).toString();
            }    

          }else{
            visualGatewaysAlreadyAdjusted.push(currentObject.id);
          }

        }else if(inEdge.length < outEdge.length){

          currentObjectVisual[c_bounds].x = ((+currentObjectVisual[c_bounds].x) + visualOffset).toString();
          visualsAlreadyAdjusted.push(currentObjectVisual.id);

          if(currentObjectVisual[c_label] != undefined){
            currentObjectVisual[c_label][c_bounds].x = ((+currentObjectVisual[c_label][c_bounds].x) + visualOffset).toString();
          }
        }

      }else if(visualsAlreadyAdjusted.find(e => e == currentObjectVisual.id) == undefined ){

        currentObjectVisual[c_bounds].x = ((+currentObjectVisual[c_bounds].x) + visualOffset).toString();
        visualsAlreadyAdjusted.push(currentObjectVisual.id);

        if(currentObjectVisual[c_label] != undefined){
          currentObjectVisual[c_label][c_bounds].x = ((+currentObjectVisual[c_label][c_bounds].x) + visualOffset).toString();
        }

      }
      

      // 1. Create outgoing edges with help of old BP

      var currentOutgoingEdges = [];

      for(var edge of bp[c_definitions][c_process][c_sequenceFlow]){
        if(edge.sourceRef == currentObject.id){
          currentOutgoingEdges.push(edge);
        }
      }
 
      if(currentOutgoingEdges.length == 0){
        if(currentObject.id.match("EndEvent_") != null){
          newBusinessProcess[c_definitions][c_process][c_end] = currentObject;
          newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape] = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape].concat(currentObjectVisual);            
        }

         //eingehende und ausgehende Kanten des Datenobjekts anpassen
         var dataObjects = newBusinessProcess[c_definitions][c_process][c_data];

         var dataReferences = newBusinessProcess[c_definitions][c_process][c_dataRef];

        if(!Array.isArray(dataObjects)){
          dataObjects = [dataObjects];
        }

        if(!Array.isArray(dataReferences)){
          dataReferences = [dataReferences];
        }

        // Passe die Datenobjekte abhängig vom VisualOffset an
        for(var dataObject of dataObjects){        

          var dataLogicReference = dataReferences.find(e => e.dataObjectRef == dataObject.id);

          if(dataLogicReference != undefined){

            // das datenobjekt anpassen
            var dataObjectVisual = bp[c_definitions][c_diagram][c_diagramPlane][c_shape].find(e => e.bpmnElement == dataLogicReference.id);
            dataObjectVisual[c_bounds].x = ((+dataObjectVisual[c_bounds].x) + visualOffset).toString();
            dataObjectVisual[c_label][c_bounds].x = ((+dataObjectVisual[c_label][c_bounds].x) + visualOffset).toString();
            newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape].push(dataObjectVisual);

            // die kanten vom ausgehend und eingehend vom datenobjekt anpassen.
            for(var userTask of newBusinessProcess[c_definitions][c_process][c_userTasks]){

              var taskShape = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape].find(e => e.bpmnElement == userTask.id);

              if(userTask[c_outData] != undefined){

                if(!Array.isArray(userTask[c_outData])){
                  userTask[c_outData] = [userTask[c_outData]];
                }
    
                for(var outgoingData of userTask[c_outData]){

                  if(outgoingData[c_target][c_nodeId] == dataLogicReference.id){
                  
                    var dataOutVisual = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].find(e => e.bpmnElement == outgoingData.id);
                    var index = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].indexOf(dataOutVisual);

                    dataOutVisual[c_waypoint][0].x = ((+taskShape[c_bounds].x) + visualStandardWidth/2).toString();

                    dataOutVisual[c_waypoint].push({
                      x: ((+dataObjectVisual[c_bounds].x) + ((+dataObjectVisual[c_bounds].width)/2)).toString(),
                      y: ((+dataObjectVisual[c_bounds].y) + ((+dataObjectVisual[c_bounds].height)/2)).toString()
                    });

                    // wenn die Datenkante von der Mitte nach Oben geht,
                    if((+dataOutVisual[c_waypoint][0].y) > (+dataOutVisual[c_waypoint][dataOutVisual[c_waypoint].length - 1].y) && (+dataOutVisual[c_waypoint][dataOutVisual[c_waypoint].length - 1].y) < visualMedian){

                      dataOutVisual[c_waypoint].splice(1,0,{
                        x: dataOutVisual[c_waypoint][0].x,
                        y: dataOutVisual[c_waypoint][dataOutVisual[c_waypoint].length - 1].y
                      });

                    }else if((+dataOutVisual[c_waypoint][0].y) < (+dataOutVisual[c_waypoint][dataOutVisual[c_waypoint].length - 1].y) && (+dataOutVisual[c_waypoint][dataOutVisual[c_waypoint].length - 1].y) < visualMedian){
                    // wenn die Datenkante von Oben zur Mitte geht,
                      
                      dataOutVisual[c_waypoint].splice(1,0,{
                        x: dataOutVisual[c_waypoint][dataOutVisual[c_waypoint].length - 1].x,
                        y: dataOutVisual[c_waypoint][0].y
                      });

                    }else if((+dataOutVisual[c_waypoint][0].y) < (+dataOutVisual[c_waypoint][dataOutVisual[c_waypoint].length - 1].y) && (+dataOutVisual[c_waypoint][dataOutVisual[c_waypoint].length - 1].y) > visualMedian){
                    // wenn die Datenkante von der Mitte nach Unten geht,
                      
                      dataOutVisual[c_waypoint].splice(1,0,{
                        x: dataOutVisual[c_waypoint][0].x,
                        y: dataOutVisual[c_waypoint][dataOutVisual[c_waypoint].length - 1].y
                      });

                    }else if((+dataOutVisual[c_waypoint][0].y) > (+dataOutVisual[c_waypoint][dataOutVisual[c_waypoint].length - 1].y) && (+dataOutVisual[c_waypoint][dataOutVisual[c_waypoint].length - 1].y) > visualMedian){
                    // wenn die Datenkante von Unten zur Mitte geht, 
                      
                      dataOutVisual[c_waypoint].splice(1,0,{
                        x: dataOutVisual[c_waypoint][dataOutVisual[c_waypoint].length - 1].x,
                        y: dataOutVisual[c_waypoint][0].y
                      });

                    }

                    newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].splice(index,1,dataOutVisual);
                  }

                }
    
              }
              
              if(userTask[c_inData] != undefined){
    
                if(!Array.isArray(userTask[c_inData])){
                  userTask[c_inData] = [userTask[c_inData]];
                }
    
                for(var incomingData of userTask[c_inData]){

                  if(incomingData[c_source][c_nodeId] == dataLogicReference.id){   
    
                    var dataInVisual = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].find(e => e.bpmnElement == incomingData.id);
                    var index = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].indexOf(dataInVisual);

                    dataInVisual[c_waypoint].splice(0, 0, {
                      x: ((+dataObjectVisual[c_bounds].x) + ((+dataObjectVisual[c_bounds].width)/2)).toString(),
                      y: ((+dataObjectVisual[c_bounds].y) + ((+dataObjectVisual[c_bounds].height)/2)).toString()
                    })

                    // wenn die Datenkante von der Mitte nach Oben geht,
                    if((+dataInVisual[c_waypoint][0].y) > (+dataInVisual[c_waypoint][dataInVisual[c_waypoint].length - 1].y) && (+dataInVisual[c_waypoint][0].y) < visualMedian){
                      
                      dataInVisual[c_waypoint].splice(1,0,{
                        x: dataInVisual[c_waypoint][0].x,
                        y: dataInVisual[c_waypoint][dataInVisual[c_waypoint].length - 1].y
                      });

                    }else if((+dataInVisual[c_waypoint][0].y) < (+dataInVisual[c_waypoint][dataInVisual[c_waypoint].length - 1].y) && (+dataInVisual[c_waypoint][0].y) < visualMedian){
                    // wenn die Datenkante von Oben zur Mitte geht,
                      
                      dataInVisual[c_waypoint].splice(1,0,{
                        x: dataInVisual[c_waypoint][dataInVisual[c_waypoint].length - 1].x,
                        y: dataInVisual[c_waypoint][0].y
                      });

                    }else if((+dataInVisual[c_waypoint][0].y) < (+dataInVisual[c_waypoint][dataInVisual[c_waypoint].length - 1].y) && (+dataInVisual[c_waypoint][0].y) > visualMedian){
                    // wenn die Datenkante von der Mitte nach Unten geht,
                  
                      dataInVisual[c_waypoint].splice(1,0,{
                        x: dataInVisual[c_waypoint][0].x,
                        y: dataInVisual[c_waypoint][dataInVisual[c_waypoint].length - 1].y
                      });

                    }else if((+dataInVisual[c_waypoint][0].y) > (+dataInVisual[c_waypoint][dataInVisual[c_waypoint].length - 1].y) && (+dataInVisual[c_waypoint][0].y) > visualMedian){
                    // wenn die Datenkante von Unten zur Mitte geht, 

                      dataInVisual[c_waypoint].splice(1,0,{
                        x: dataInVisual[c_waypoint][dataInVisual[c_waypoint].length - 1].x,
                        y: dataInVisual[c_waypoint][0].y
                      });
                    }
      
                    newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].splice(index,1,dataInVisual);
                  }

                }
    
              }

            }

          }

        }

        

        return checkVisualEdges(newBusinessProcess);
      }

      incomingEdges = [];
      outgoingEdges = [];

      // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
      
      if(currentObject[c_in] != undefined){
        if(Array.isArray(currentObject[c_in])){
          for(var edge of currentObject[c_in]){
            incomingEdges.push(edge[c_nodeId]);
          }
        }else{
          incomingEdges.push(currentObject[c_in][c_nodeId]);
        }
      }

      if(currentObject[c_out] != undefined){
        if(Array.isArray(currentObject[c_out])){
          for(var edge of currentObject[c_out]){
            outgoingEdges.push(edge[c_nodeId]);
          }
        }else{
          outgoingEdges.push(currentObject[c_out][c_nodeId]);
        }
      }

      if(currentObject[c_in] != undefined && currentObject[c_out] != undefined){

        // Wenn das Gateway einem Loop angehört -> Prüfe ob eingehendes oder ausgehendes
        if(currentObject.name.includes("Loop")){

          // Loop-Gateway entscheidung -> überprüfe ob loop edge ausgewählt wird
          if(outgoingEdges.length > incomingEdges.length){
            var found;
            for(var edge of outgoingEdges){
            
              found = sequenceFlows.find(e => {
                if(e.id == edge){
                  if(e.name == "yes"){
                    return e;
                  }
                }
              });

              if(found != undefined){
                chosenEdgeLoop = found;
              }
            }
          }

        }else{
      
          if(outgoingEdges.length > incomingEdges.length){
              for(var edge in outgoingEdges){
                gateWaysStack.push(currentObject.name);
              }

              currentObject[c_out] = [];
          }

          if(outgoingEdges.length < incomingEdges.length){
            gateWaysStack.pop();
            if(currentObject.name == gateWaysStack[gateWaysStack.length - 1]){
              reachedEndGateWay = true; 
            }

            currentObject[c_out] = [];
          }

        }
      }

      for(var outgoingEdge of currentOutgoingEdges){

        if(chosenEdgeLoop != null){
          if(outgoingEdge.id == chosenEdgeLoop.id){
            loopEdgeChosen = true;
            chosenEdgeLoop = null;
          }
        }

        // wenn das current object ein exclusive Gateway is
        if(currentObject.id.match("ExclusiveGateway_")){
          // füge die decision hinzu
          if(outgoingEdge.name != undefined){
            globalDecisions.push({name: currentObject.name, value: outgoingEdge.name});
            var found = gatewaysPassed.find(e => e == currentObject.name);

            // store passed gateway till the last corresponding gateway is found
            // indicating the gateway influence of the path
            if(found == undefined){
              gatewaysPassed.push(currentObject.name);
            }
          }
        }

        var outgoingEdgeShape = bp[c_definitions][c_diagram][c_diagramPlane][c_edge].find(e => e.bpmnElement == outgoingEdge.id);
 
        // 2. lookup the next object in old bp

        if(bp[c_definitions][c_process][c_userTasks] != undefined && !Array.isArray(bp[c_definitions][c_process][c_userTasks])){
          bp[c_definitions][c_process][c_userTasks] = [bp[c_definitions][c_process][c_userTasks]];
        }
        if(bp[c_definitions][c_process][c_serviceTasks] != undefined && !Array.isArray(bp[c_definitions][c_process][c_serviceTasks])){
          bp[c_definitions][c_process][c_serviceTasks] = [bp[c_definitions][c_process][c_serviceTasks]];
        }
        if(bp[c_definitions][c_process][c_exclusive] != undefined && !Array.isArray(bp[c_definitions][c_process][c_exclusive])){
          bp[c_definitions][c_process][c_exclusive] = [bp[c_definitions][c_process][c_exclusive]];
        }
        if(bp[c_definitions][c_process][c_parallel] != undefined  && !Array.isArray(bp[c_definitions][c_process][c_parallel])){
          bp[c_definitions][c_process][c_parallel] = [bp[c_definitions][c_process][c_parallel]];
        }
        if(!Array.isArray(bp[c_definitions][c_process][c_end])){
          bp[c_definitions][c_process][c_end] = [bp[c_definitions][c_process][c_end]];
        }
          
        if(bp[c_definitions][c_process][c_userTasks].find(e => e.id == outgoingEdge.targetRef) != undefined){

          nextObject = bp[c_definitions][c_process][c_userTasks].find(e => e.id == outgoingEdge.targetRef);

        }else if(bp[c_definitions][c_process][c_serviceTasks] != undefined && bp[c_definitions][c_process][c_serviceTasks].find(e => e.id == outgoingEdge.targetRef) != undefined){

          nextObject = bp[c_definitions][c_process][c_serviceTasks].find(e => e.id == outgoingEdge.targetRef);

        }else if(bp[c_definitions][c_process][c_exclusive] != undefined && bp[c_definitions][c_process][c_exclusive].find(e => e.id == outgoingEdge.targetRef) != undefined){

          nextObject = bp[c_definitions][c_process][c_exclusive].find(e => e.id == outgoingEdge.targetRef);
            
        }else if(bp[c_definitions][c_process][c_parallel] != undefined && bp[c_definitions][c_process][c_parallel].find(e => e.id == outgoingEdge.targetRef) != undefined){

          nextObject = bp[c_definitions][c_process][c_parallel].find(e => e.id == outgoingEdge.targetRef)
            
        }else if(bp[c_definitions][c_process][c_end].find(e => e.id == outgoingEdge.targetRef) != undefined){

          nextObject = bp[c_definitions][c_process][c_end].find(e => e.id == outgoingEdge.targetRef)
            
        }

        //console.log(currentObject.name);

        // 3. compare with next object in buildingPath

        var currentEdge = outgoingEdge;

        
        if(!loopEdgeChosen){

          // if the currentObject is the startEvent -> skip exchangeTask checking 
          // because exchange Task after startevent or before endEvent is impossible
          if(currentObject.id.match("StartEvent_") == undefined){

            // for every path
            for(var sortedPath of sortedPaths){         
              // for every receiving task the optimal path is chosen and build
              for(var receiverTask of sortedPath.receivers){
                // for every dataObject
                for(var data of possibleData){  
                  // the path contains the dataobject
                  if(sortedPath.dataObject == data){
                    // the path is still relevant because the receiver is not passed yet  
                    if(sortedPath.augmentedPaths[receiverTask] != undefined){    
                      
                      var pathsForReceiver = sortedPath.augmentedPaths[receiverTask][0];

                      // currently picking the first path if we have two or more paths with same decision and with same costs
                      // later optimization is to build a tree which has k successors if we have k paths with the same costs
                      if(pathsForReceiver[0] != undefined && pathsForReceiver[0].path.find(e => e.id == currentObject.id) != undefined){

                          var augmentedPath = pathsForReceiver[0];  
                          //console.log(currentObject.name, augmentedPath);            

                          //lookup if the current object is right to the next object in the array
                          // i = index of current object in augmentedPath
                          // j = index of next object in augmentedPath
                                      
                          var indexCurrentObject = augmentedPath.path.indexOf(augmentedPath.path.find(e => e.id == currentObject.id));                  
                          var exchangeTaskNext = augmentedPath.path[indexCurrentObject + 1];
                          var nextObjectAfter = augmentedPath.path[indexCurrentObject + 2];

                          // MODULE 2: Piggy Packing of Key Exchange with tasks

                          // if the current object is the sending task and the next object in the path is a exchange task -> exchange task merge with current task
                          if(augmentedPath.mergedKeyExchange != undefined){                     
                            if(augmentedPath.mergedKeyExchange.find(e => e == currentObject.name) != undefined){                      
                                                              
                                var documentation = JSON.parse(currentObject[c_documentation][c_nodeId]);           
                                var sphere = documentation.spheres.find( e => e.dataObject == sortedPath.dataObject);
                                if(sphere.exchangeKeys == undefined){
                                  sphere.exchangeKeys = [];
                                }

                                var candidateReceiver = findOccurenceInString(augmentedPath.path[augmentedPath.path.length-1].name, '[', ']');

                                // if the receiver is not being exchanged already
                                if(sphere.exchangeKeys.find( e => e.receiver == candidateReceiver) == undefined){
                                  sphere.exchangeKeys.push({receiver: candidateReceiver, exchange: true});
                                  currentObject[c_documentation][c_nodeId] = JSON.stringify(documentation);
                                }
                            }
                          // if next index is an exchangeTask in the array and the object after it is the nextobject
                          }
                          
                          if((exchangeTaskNext != undefined) && (exchangeTaskNext.id == 0) && (nextObjectAfter.id == nextObject.id) && (reachedEndGateWay == false)){

                          // get key Exchange Task in the augmented Path
                          var keyExchangeTaskRaw = augmentedPath.path[indexCurrentObject + 1];  

                          var foundAlreadyGeneratedExchangeTask = exchangeForReceiversAdded.find( e => {
                              if(e.sender == augmentedPath.path[0].id && e.receiver == receiverTask && e.dataObject == data){
                              return e;
                              }
                          })

                          // get relevant decisions
                          var relevantDecisions = [];

                          for(var g of gatewaysPassed){

                            var foundDecision = sortedPath.decisions.find(e => e.name == g);

                            if(foundDecision != undefined){
                              relevantDecisions.push(foundDecision);
                            }
                            
                          }

                          // the exchangeTask has been inserted already
                          if(foundAlreadyGeneratedExchangeTask != undefined){

                            var existingExchangeTask = newBusinessProcess[c_definitions][c_process][c_serviceTasks].find(e => e.id == foundAlreadyGeneratedExchangeTask.exchangeTaskId);
                            var exchangeTaskDocumentation = JSON.parse(existingExchangeTask[c_documentation][c_nodeId]);

                            var sender = findOccurenceInString(existingExchangeTask.name, '[', ']');

                            var foundExchangeEntry = exchangeTaskDocumentation.exchange.find(e => e.participant == sender);
                            var indexOfExchange = exchangeTaskDocumentation.exchange.indexOf(foundExchangeEntry);

                            exchangeTaskDocumentation.exchange.splice(indexOfExchange,1);

                            //console.log("HERE 1:", foundExchangeEntry);
                            //console.log("HERE 2:", relevantDecisions);

                            var candidateDecisions = foundExchangeEntry.decisions.concat(relevantDecisions);

                            var deDuplicatedDecisions = [];

                            for(var decision of candidateDecisions){

                              var foundAlreadyAddedDecision = deDuplicatedDecisions.find(e => {
                                if(e.name == decision.name && e.value == decision.value){
                                  return e;
                                }
                              });

                              if(foundAlreadyAddedDecision == undefined){
                                deDuplicatedDecisions.push(decision);
                              }
                            }

                            foundExchangeEntry.decisions = deDuplicatedDecisions;
                            exchangeTaskDocumentation.exchange.push(foundExchangeEntry);
                            existingExchangeTask[c_documentation][c_nodeId] = JSON.stringify(exchangeTaskDocumentation);

                          }

                          // if the exchangeTask for the currentDataobject has not been inserted
                          if(foundAlreadyGeneratedExchangeTask == undefined){

                              //check if an exchangetask already exists at this position
                              var foundExistingEntry = exchangeForReceiversAdded.find( e => e.receiver == receiverTask);

                              if(foundExistingEntry != undefined){

                                var existingExchangeTask = newBusinessProcess[c_definitions][c_process][c_serviceTasks].find(e => e.id == foundExistingEntry.exchangeTaskId);
                                var exchangeTaskDocumentation = JSON.parse(existingExchangeTask[c_documentation][c_nodeId]);

                                var name = existingExchangeTask.name;
                                var participants = findOccurenceInString(name, "[","]");
                                var dataObjects = findOccurenceInString(name, "{","}");

                                // check if an distributor exists and if the distributor is the sender of an existing key exchange task
                                // if yes => merge with the existing key exchange task 

                                // MODULE 4: Alternative Distributor

                                var alternativeDistributors = augmentedPath.distributors
                                var foundExchangeEntry = undefined;

                                if(alternativeDistributors.length > 0){

                                    foundExchangeEntry = exchangeTaskDocumentation.exchange.find(e => e.participant == alternativeDistributors[0].distributor);

                                }

                                // MODULE 3: Merging Key Exchange Tasks
                                // if an entry exists -> add the path decisions to the exchangeEntry because the sender stays the same
                                // and will exchange in the decisions present
                                if(foundExchangeEntry != undefined){  
                
                                    var indexOfExchange = exchangeTaskDocumentation.exchange.indexOf(foundExchangeEntry);
                                    exchangeTaskDocumentation.exchange.splice(indexOfExchange,1);

                                    foundExchangeEntry.decisions.push(relevantDecisions);

                                    exchangeTaskDocumentation.exchange.push(foundExchangeEntry);

                                    existingExchangeTask[c_documentation][c_nodeId] = JSON.stringify(exchangeTaskDocumentation);
                                  
                                    
                                }else{
                                  // if no entry exists and the entry is not already added -> add a new exchange procedure

                                    var sender = findOccurenceInString(keyExchangeTaskRaw.name, '{', '}');
                                    var receiver = findOccurenceInString(augmentedPath.path[augmentedPath.path.length - 1].name, '[', ']');                      
                                    var dataObjectShort = findOccurenceInString(keyExchangeTaskRaw.name, '[', ']');

                                    var newExchangeEntry = {
                                      "participant": sender,
                                      "decisions": relevantDecisions,
                                      "receiver": {dataObject: data, assignee: receiver}
                                    }

                                    var alreadyAdded = exchangeTaskDocumentation.exchange.find( e => {
                                        if(JSON.stringify(e) == JSON.stringify(newExchangeEntry)){
                                          return e;
                                        }
                                    });

                                    /* if(!alreadyAdded){                             

                                      exchangeTaskDocumentation.exchange.push(newExchangeEntry);

                                      existingExchangeTask[c_documentation][c_nodeId] = JSON.stringify(exchangeTaskDocumentation);

                                      var participantsArray = participants.split(",");
                                      var dataObjectsArray = dataObjects.split(",");
                                      
                                      if(participantsArray.find( e => e == sender) == undefined){

                                        var updatedParticipants = participants + "," + sender;
                                        name = name.replace(participants, updatedParticipants);

                                      }

                                      if(dataObjectsArray.find( e => e == dataObjectShort) == undefined){

                                        var updatedDataObjects = dataObjects + "," + dataObjectShort
                                        name = name.replace(dataObjects, updatedDataObjects);

                                      } 
                                  }  */
                                
                                }

                                existingExchangeTask.name = name;


                              }else{

                              newExchangeTaskAdded = true;

                              // 4. 

                              // create new ID for exchangeTask
                              var exchangeTaskId = createID(newBusinessProcess, c_serviceTasks);

                              // ### THE EXCHANGE TASK IS HANDLED HERE ###

                              // HERE recursion to generate more bps with other alternative distributors
                              // for now pick the first alternative distributor

                              //console.log(currentObject.name, sortedPath.decisions);                         
                              var keyExchangeTask = generateKeyExchangeTask(keyExchangeTaskRaw, augmentedPath.path[augmentedPath.path.length - 1], data, relevantDecisions, exchangeTaskId, augmentedPath.distributors);
                              // if an alternative distributor has been found and the receiving task happens to be the same
                              // participant as the distirbutor -> abort generating exchangeTask
                              if(findOccurenceInString(keyExchangeTask.name, '[', ']') == nextObject[c_assignee]){
                                  newExchangeTaskAdded = false;
                                  break;
                              }

                              // ### THE OUTGOING EDGE FOR THE EXCHANGE TASK IS HANDLED HERE ###

                              // set the sourceRef of the current Edge to the exchangeTask and add the edge to the new BP
                              currentEdge.sourceRef = exchangeTaskId;

                              var currentEdgePresent = newBusinessProcess[c_definitions][c_process][c_sequenceFlow].find(e => e.id == currentEdge.id);

                              if(currentEdgePresent != undefined){
                                  var index = newBusinessProcess[c_definitions][c_process][c_sequenceFlow].indexOf(currentEdgePresent);
                                  newBusinessProcess[c_definitions][c_process][c_sequenceFlow].splice(index,1);
                                  newBusinessProcess[c_definitions][c_process][c_sequenceFlow] = newBusinessProcess[c_definitions][c_process][c_sequenceFlow].concat(currentEdge);                              
                              }else{
                                  newBusinessProcess[c_definitions][c_process][c_sequenceFlow] = newBusinessProcess[c_definitions][c_process][c_sequenceFlow].concat(currentEdge);           
                              }
                              
                              keyExchangeTask[c_out][c_nodeId] = currentEdge.id;

                              // ### THE OUTGOING EDGE FOR THE EXCHANGE TASK IS HANDLED HERE ###

                              // create a new Edge (logic and visual) which is outgoing from exchangeTask

                              var newEdgeId = createID(newBusinessProcess, c_sequenceFlow);
                  
                              //console.log(+currentObjectVisual);
                          
                              //console.log(currentObject.name, newEdgeShape);

                              // creating logic for outgoing edge
                              var newOutgoingEdge = {
                                  id: newEdgeId,
                                  sourceRef: currentObject.id,
                                  targetRef: keyExchangeTask.id
                              }

                              // if the old edge was outgoing from a exclusive gateway and had a name
                              if(currentEdge.name != undefined){
                                  newOutgoingEdge.name = currentEdge.name;
                                  newOutgoingEdge[c_conditionExpression] = currentEdge[c_conditionExpression];
                                  //delete the name from old edge
                                  delete currentEdge.name;
                                  delete currentEdge[c_conditionExpression];
                              }

                              // add the outgoing Edge to the exchangeTask
                              keyExchangeTask[c_in][c_nodeId] = newEdgeId;

                              // create the keyExchangeTask Visual
                              var keyExchangeTaskShape = {
                                  id: keyExchangeTask.id + "_di",
                                  bpmnElement: keyExchangeTask.id,
                                  'dc:Bounds': {
                                  x: 0,
                                  y: 0,
                                  width: visualStandardWidth,
                                  height: visualStandardHeight
                                  }
                              }

                              var newEdgeShape = {
                                  id: newEdgeId + "_di",
                                  bpmnElement: newEdgeId
                              }

                              // wenn die edge gerade ist
                              if((+outgoingEdgeShape[c_waypoint][0].y) == (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y)){

                                  keyExchangeTaskShape[c_bounds].y = ((+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) - (visualStandardHeight/2)).toString();

                                  newEdgeShape[c_waypoint] = [
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width / 2)).toString(),
                                      y: ((+keyExchangeTaskShape[c_bounds].y) + visualStandardHeight / 2).toString()
                                      },
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width / 2) + 50).toString(),
                                      y: ((+keyExchangeTaskShape[c_bounds].y) + visualStandardHeight / 2).toString()
                                      }
                                  ]

                                  keyExchangeTaskShape[c_bounds].x = ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width + 50) + visualOffset).toString();

                              }else if((+outgoingEdgeShape[c_waypoint][0].y) > (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) && (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) < visualMedian){
                              // wenn die Edge von der Mitte nach Oben geht,

                                  keyExchangeTaskShape[c_bounds].y = ((+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) - (visualStandardHeight/2)).toString();

                                  newEdgeShape[c_waypoint] = [
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width / 2)).toString(),
                                      y: currentObjectVisual[c_bounds].y
                                      },
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width / 2)).toString(),
                                      y: ((+keyExchangeTaskShape[c_bounds].y) + visualStandardHeight / 2).toString()
                                      },
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width + 50)).toString(),
                                      y: ((+keyExchangeTaskShape[c_bounds].y) + visualStandardHeight / 2).toString()
                                      }
                                  ]

                                  keyExchangeTaskShape[c_bounds].x = ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width + 50)).toString();

                              }else if((+outgoingEdgeShape[c_waypoint][0].y) < (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) && (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) < visualMedian){
                              // wenn die Edge von Oben zur Mitte geht,

                                  keyExchangeTaskShape[c_bounds].y = ((+outgoingEdgeShape[c_waypoint][0].y) - (visualStandardHeight/2)).toString();

                                  newEdgeShape[c_waypoint] = [
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width / 2)).toString(),
                                      y: currentObjectVisual[c_bounds].y
                                      },
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width / 2)).toString(),
                                      y: ((+keyExchangeTaskShape[c_bounds].y) + visualStandardHeight / 2).toString()
                                      },
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width + 50)).toString(),
                                      y: ((+keyExchangeTaskShape[c_bounds].y) + visualStandardHeight / 2).toString()
                                      }
                                  ]

                                  keyExchangeTaskShape[c_bounds].x = ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width + 50)).toString();

                              }else if((+outgoingEdgeShape[c_waypoint][0].y) < (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) && (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) > visualMedian){
                              // wenn die Edge von der Mitte nach Unten geht,
                              
                                  keyExchangeTaskShape[c_bounds].y = ((+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) - (visualStandardHeight/2)).toString();
                                  
                                  newEdgeShape[c_waypoint] = [
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width / 2)).toString(),
                                      y: ((+currentObjectVisual[c_bounds].y) + 50).toString()
                                      },
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width / 2)).toString(),
                                      y: ((+keyExchangeTaskShape[c_bounds].y) + visualStandardHeight / 2).toString()
                                      },
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width + 50)).toString(),
                                      y: ((+keyExchangeTaskShape[c_bounds].y) + visualStandardHeight / 2).toString()
                                      }
                                  ]

                                  keyExchangeTaskShape[c_bounds].x = ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width + 50)).toString();

                              }else if((+outgoingEdgeShape[c_waypoint][0].y) > (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) && (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) > visualMedian){
                              // wenn die Edge von Unten zur Mitte geht, 

                                  keyExchangeTaskShape[c_bounds].y = ((+outgoingEdgeShape[c_waypoint][0].y) - (visualStandardHeight/2)).toString();
                                  
                                  newEdgeShape[c_waypoint] = [
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width / 2)).toString(),
                                      y: currentObjectVisual[c_bounds].y
                                      },
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width / 2)).toString(),
                                      y: ((+keyExchangeTaskShape[c_bounds].y) + visualStandardHeight / 2).toString()
                                      },
                                      {
                                      x: ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width + 50)).toString(),
                                      y: ((+keyExchangeTaskShape[c_bounds].y) + visualStandardHeight / 2).toString()
                                      }
                                  ]

                                  keyExchangeTaskShape[c_bounds].x = ((+currentObjectVisual[c_bounds].x) + (+currentObjectVisual[c_bounds].width + 50)).toString();

                              }

                              outgoingEdgeShape[c_waypoint] = 
                                  [
                                  {
                                      x: ((+keyExchangeTaskShape[c_bounds].x) + visualStandardWidth).toString(),
                                      y: ((+keyExchangeTaskShape[c_bounds].y) + (visualStandardHeight/2)).toString()
                                  },
                                  {
                                      x:((+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].x) + visualOffset).toString(),
                                      y: ((+keyExchangeTaskShape[c_bounds].y) + (visualStandardHeight/2)).toString()
                                  }
                                  ]


                              // now add the outgoingEdge with updated coordinates to the BP

                              var edgeShape = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].find( e => e.bpmnElement == outgoingEdgeShape.bpmnElement);                

                              if(edgeShape != undefined){
                                  var index = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].indexOf(edgeShape);
                                  newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].splice(index,1);
                              }

                              newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge] = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].concat(outgoingEdgeShape);
                              

                              // add the logic and visual of the exchangeTask to the newBP
                              if(newBusinessProcess[c_definitions][c_process][c_serviceTasks] == undefined){
                                  newBusinessProcess[c_definitions][c_process][c_serviceTasks] = [];

                                  if(newBusinessProcess[c_definitions][c_process][c_serviceTasks].find(e => e.id == keyExchangeTask.id) == undefined){
                                  newBusinessProcess[c_definitions][c_process][c_serviceTasks].push(keyExchangeTask)
                                  }
                              }else{
                                  if(newBusinessProcess[c_definitions][c_process][c_serviceTasks].find(e => e.id == keyExchangeTask.id) == undefined){
                                  newBusinessProcess[c_definitions][c_process][c_serviceTasks] = newBusinessProcess[c_definitions][c_process][c_serviceTasks].concat(keyExchangeTask);           
                                  }
                              }

                              if(newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape].find(e => e.bpmnElement == keyExchangeTaskShape.bpmnElement) == undefined){
                                  newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape] = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape].concat(keyExchangeTaskShape);
                              }

                              // add the logic and visual of the outgoing Edge to the newBP
                              if(newBusinessProcess[c_definitions][c_process][c_sequenceFlow].find(e => e.id == newOutgoingEdge.id) == undefined){
                                  newBusinessProcess[c_definitions][c_process][c_sequenceFlow] = newBusinessProcess[c_definitions][c_process][c_sequenceFlow].concat(newOutgoingEdge);           
                              }       
                              
                              if(newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].find(e => e.bpmnElement == newEdgeShape.bpmnElement) == undefined){
                                  newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge] = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].concat(newEdgeShape);
                              }

                              // update the outgoing edge in the current object to the newly generated one

                              if(!Array.isArray(currentObject[c_out])){

                                currentObject[c_out][c_nodeId] = newOutgoingEdge.id;

                              }else{

                                currentObject[c_out].push({$t: newOutgoingEdge.id});

                              }
             
                              // add the offset of the new inserted visual element, which is the width of one whole task element
                              visualOffset = visualOffset + visualStandardWidth + 50;       
                              
                              // add to done
                              exchangeForReceiversAdded.push({sender: augmentedPath.path[0].id, receiver: receiverTask, dataObject: data , exchangeTaskId: exchangeTaskId});
                              }
                          }
                          }        
                      }
                  }
                  }
                }      
              }
            }

          }

        }

        // after this point the exchangeTasks have been covered for the current position, add the current Object to the new BP
        // if there was no exchangeTask for the current next position
        if(!newExchangeTaskAdded){

          if(Array.isArray(currentObject[c_out])){
            currentObject[c_out].push({$t: currentEdge.id});
          }else{
            currentObject[c_out] = {$t: currentEdge.id};
          }

          if(newBusinessProcess[c_definitions][c_process][c_sequenceFlow].find(e => e.id == currentEdge.id) == undefined){     
            newBusinessProcess[c_definitions][c_process][c_sequenceFlow] = newBusinessProcess[c_definitions][c_process][c_sequenceFlow].concat(currentEdge);           
          }

          if(newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].find(e => e.bpmnElement == outgoingEdgeShape.bpmnElement) == undefined){
            if(outgoingEdgeShape[c_label] != undefined){
              outgoingEdgeShape[c_label][c_bounds].x = ((+outgoingEdgeShape[c_label][c_bounds].x) + visualOffset).toString();
            }

            outgoingEdgeShape[c_waypoint] = 
            [
              {
                x: ((+outgoingEdgeShape[c_waypoint][0].x) + visualOffset).toString(),
                y: outgoingEdgeShape[c_waypoint][0].y
              },
              {
                x:((+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].x) + visualOffset).toString(),
                y: outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y
              }
            ]

            // wenn die Edge von der Mitte nach Oben geht,
            if((+outgoingEdgeShape[c_waypoint][0].y) > (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) && (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) < visualMedian){

              outgoingEdgeShape[c_waypoint].splice(1,0,{
                x: outgoingEdgeShape[c_waypoint][0].x,
                y: outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y
              });

            }else if((+outgoingEdgeShape[c_waypoint][0].y) < (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) && (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) < visualMedian){
            // wenn die Edge von Oben zur Mitte geht,

              outgoingEdgeShape[c_waypoint].splice(1,0,{
                x: outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].x,
                y: outgoingEdgeShape[c_waypoint][0].y
              });

            }else if((+outgoingEdgeShape[c_waypoint][0].y) < (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) && (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) > visualMedian){
            // wenn die Edge von der Mitte nach Unten geht,
           
              outgoingEdgeShape[c_waypoint].splice(1,0,{
                x: outgoingEdgeShape[c_waypoint][0].x,
                y: outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y
              });

            }else if((+outgoingEdgeShape[c_waypoint][0].y) > (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) && (+outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].y) > visualMedian){
            // wenn die Edge von Unten zur Mitte geht, 

              outgoingEdgeShape[c_waypoint].splice(1,0,{
                x: outgoingEdgeShape[c_waypoint][outgoingEdgeShape[c_waypoint].length - 1].x,
                y: outgoingEdgeShape[c_waypoint][0].y
              });
            }

            newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge] = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].concat(outgoingEdgeShape);

          }
        }

        // ÜBERPRÜFE OB DUPLIKATE DRINNEN!!!
        // add the current object to the new BP
        if(currentObject.id.match("Task_") != null){

          if(newBusinessProcess[c_definitions][c_process][c_userTasks].find(e => e.id == currentObject.id) == undefined){         
            newBusinessProcess[c_definitions][c_process][c_userTasks] = newBusinessProcess[c_definitions][c_process][c_userTasks].concat(currentObject);   
          }

          if(currentObject[c_outData] != undefined){

            var outgoingDataEdges = currentObject[c_outData];

            if(!Array.isArray(outgoingDataEdges)){
              outgoingDataEdges = [outgoingDataEdges];
            }

            for(var outgoingDataEdge of outgoingDataEdges){

              var dataObjectEdgeVisual = bp[c_definitions][c_diagram][c_diagramPlane][c_edge].find( e => e.bpmnElement == outgoingDataEdge.id);
              newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge] = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].concat(dataObjectEdgeVisual);
            
            }
          }

          if(currentObject[c_inData] != undefined){

            var incomingDataEdges = currentObject[c_inData];

            if(!Array.isArray(incomingDataEdges)){
              incomingDataEdges = [incomingDataEdges];
            }

            for(var incomingDataEdge of incomingDataEdges){

              var dataObjectEdgeVisual = bp[c_definitions][c_diagram][c_diagramPlane][c_edge].find( e => e.bpmnElement == incomingDataEdge.id);             
              newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge] = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].concat(dataObjectEdgeVisual);
            
            }

          }
        }else if(currentObject.id.match("Service_") != null){

          if(newBusinessProcess[c_definitions][c_process][c_serviceTasks].find(e => e.id == currentObject.id) == undefined){         
            newBusinessProcess[c_definitions][c_process][c_serviceTasks] = newBusinessProcess[c_definitions][c_process][c_serviceTasks].concat(currentObject);   
          }

        }else if(bp[c_definitions][c_process][c_exclusive] != undefined && bp[c_definitions][c_process][c_exclusive].find(e => e.id == currentObject.id) != undefined){
          // set the outgoing edge of the current object to the new generated one.
          if(newBusinessProcess[c_definitions][c_process][c_exclusive].find(e => e.id == currentObject.id) == undefined){
            newBusinessProcess[c_definitions][c_process][c_exclusive] = newBusinessProcess[c_definitions][c_process][c_exclusive].concat(currentObject);   
          }     
        }else if(bp[c_definitions][c_process][c_parallel] != undefined && bp[c_definitions][c_process][c_parallel].find(e => e.id == currentObject.id) != undefined){
          // set the outgoing edge of the current object to the new generated one.
          if(newBusinessProcess[c_definitions][c_process][c_parallel].find(e => e.id == currentObject.id) == undefined){
            newBusinessProcess[c_definitions][c_process][c_parallel] = newBusinessProcess[c_definitions][c_process][c_parallel].concat(currentObject);  
          }                 
        }else if(currentObject.id.match("StartEvent_") != null){
          newBusinessProcess[c_definitions][c_process][c_start] = currentObject;           
        }

        if(newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape].find(e => e.bpmnElement == currentObjectVisual.bpmnElement) == undefined){

          var associations = newBusinessProcess[c_definitions][c_process][c_association];

          if(!Array.isArray(associations)){
            associations = [associations];
          }

          // hole die associations die zum current object gehören
          var associationsForCurrentObject = associations.filter( e => e.sourceRef == currentObject.id);

          // behandle die Visuals der Associations

          for(var association of associationsForCurrentObject){

            var associationVisual = bp[c_definitions][c_diagram][c_diagramPlane][c_edge].find(e => e.bpmnElement == association.id);
            var annotation = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape].find( e => e.bpmnElement == association.targetRef);

            associationVisual[c_waypoint] = [
              {
                x: ((+associationVisual[c_waypoint][0].x) + visualOffset).toString(),
                y: associationVisual[c_waypoint][0].y
              },
              {
                x: ((+associationVisual[c_waypoint][associationVisual[c_waypoint].length -1].x) + visualOffset).toString(),
                y: associationVisual[c_waypoint][associationVisual[c_waypoint].length -1].y
              }
            ]

            if(annotation != undefined){
              annotation[c_bounds].x = ((+annotation[c_bounds].x) + visualOffset).toString();
            }

            newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].push(associationVisual);

          }

          // behandle die Visuals der DataObjectReferences
          if(currentObject[c_outData] != undefined){

            if(!Array.isArray(currentObject[c_outData])){
              currentObject[c_outData] = [currentObject[c_outData]];
            }

            for(var outgoingData of currentObject[c_outData]){

              var dataOutVisual = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].find(e => e.bpmnElement == outgoingData.id);
              var index = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].indexOf(dataOutVisual);

              var currentObjectVisualMiddleX = ((+currentObjectVisual[c_bounds].x) + ((+currentObjectVisual[c_bounds].width) /2));

              var outgoingCoordinate =
                {
                  x: (currentObjectVisualMiddleX + visualOffset).toString(),
                  y: dataOutVisual[c_waypoint][0].y
                }

              dataOutVisual[c_waypoint] = [];
              dataOutVisual[c_waypoint].push(outgoingCoordinate);

              newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].splice(index,1,dataOutVisual);

            }

          }
          
          if(currentObject[c_inData] != undefined){

            if(!Array.isArray(currentObject[c_inData])){
              currentObject[c_inData] = [currentObject[c_inData]];
            }

            for(var incomingData of currentObject[c_inData]){

              var dataInVisual = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].find(e => e.bpmnElement == incomingData.id);
              var index = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].indexOf(dataInVisual);

              var currentObjectVisualMiddleX = ((+currentObjectVisual[c_bounds].x) + ((+currentObjectVisual[c_bounds].width) /2));

              var incomingCoordinate = 
                {
                  x: (currentObjectVisualMiddleX).toString(),
                  y: dataInVisual[c_waypoint][dataInVisual[c_waypoint].length-1].y
                }
        
              dataInVisual[c_waypoint] = [];
              dataInVisual[c_waypoint].push(incomingCoordinate);

              newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].splice(index,1,dataInVisual);

            }

          }

          newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape] = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape].concat(currentObjectVisual);
        }
     
        if(!reachedEndGateWay && !loopEdgeChosen){
          currentObjectStack.push(nextObject);
        }
        loopEdgeChosen = false;
        reachedEndGateWay = false;
        newExchangeTaskAdded = false;

        globalDecisions = [];

        //console.log(currentEdge);

        //console.log("QUEUE after adding new:" ,currentObjectStack);

      }

      previousObject = currentObject;

      //console.log("AUSGGEHENE?", currentObject);

      //console.log("stack:",currentObjectStack);

    }
    

  }catch(e){
    console.error(methodName,e);
  }

}

function generateKeyExchangeTask(rawExchangeTaskMetadata, nextObject, data, decisions, exchangeTaskId, alternativeDistributors){
  let methodName = ">>> [createKeyExchangeTask]: "; 
  
  try{

    var newTask;
    var sender = findOccurenceInString(rawExchangeTaskMetadata.name, '{', '}');
    var receiver = findOccurenceInString(nextObject.taskObject.name, '[', ']');
    var dataObjectShort = findOccurenceInString(rawExchangeTaskMetadata.name, '[', ']');

    if(alternativeDistributors.length > 0){
      
      var alternativeDistributor = alternativeDistributors[0].distributor;
    
      var documentation = { 
        "type": c_serviceTasks,
        "exchange" : [
          {
            "participant": sender,
            "decisions": decisions,
            "receiver": {dataObject: data, assignee: receiver},
            "alternativeDistributor": {distributor: alternativeDistributor, decision: alternativeDistributors[0].decision}
          }
        ]
      }

      newTask = {
        id: exchangeTaskId,
        name: "Exchange [" + sender + "] for {" + dataObjectShort + "} (" + alternativeDistributor + ")",
        'camunda:type': "external",
        'camunda:topic': "exchangeKeys",
        'bpmn:documentation': { "$t": JSON.stringify(documentation)},
        'bpmn:incoming': { "$t": 0},
        'bpmn:outgoing': { "$t": 0}
      }

    }else{
    
      var documentation = { 
        "type": c_serviceTasks,
        "exchange" : [
          {
            "participant": sender,
            "decisions": decisions,
            "receiver": {dataObject: data, assignee: receiver},
          }
        ]
      }

      newTask = {
        id: exchangeTaskId,
        name: "Exchange [" + sender + "] for {" + dataObjectShort + "}",
        'camunda:type': "external",
        'camunda:topic': "exchangeKeys",
        'bpmn:documentation': { "$t": JSON.stringify(documentation)},
        'bpmn:incoming': { "$t": 0},
        'bpmn:outgoing': { "$t": 0}
      }

    }

    return newTask;

  }catch(e){
    console.error(methodName, e);
  }
  
}

function checkVisualEdges(newBusinessProcess){
  let methodName = ">>> [checkVisualEdges]: ";

  try{

      var incomingEdges;
      var outgoingEdges;
      var nextObject;
      var edgeLogic = newBusinessProcess[c_definitions][c_process][c_sequenceFlow];
      var edgeVisual = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge];
      var currentObjectStack = [];
      var gateWaysStack = [];
      var reachedEndGateWay = false;

      var visualStandardWidthTask = 100;
      var visualStandardWidthGateway = 50;
      var visualStandardWidthEvent = 36;

      var allObjects = newBusinessProcess[c_definitions][c_process][c_userTasks].slice();
      
      if(newBusinessProcess[c_definitions][c_process][c_exclusive] != undefined){
        allObjects = allObjects.concat(newBusinessProcess[c_definitions][c_process][c_exclusive]);
      }
      if(newBusinessProcess[c_definitions][c_process][c_parallel] != undefined){
        allObjects = allObjects.concat(newBusinessProcess[c_definitions][c_process][c_parallel]);
      }
      if(newBusinessProcess[c_definitions][c_process][c_serviceTasks]){
        allObjects = allObjects.concat(newBusinessProcess[c_definitions][c_process][c_serviceTasks]);
      }

      allObjects = allObjects.concat(newBusinessProcess[c_definitions][c_process][c_end]);

      //console.log(allObjects);

      // init stack
      currentObjectStack.push(newBusinessProcess[c_definitions][c_process][c_start]);
  
      while(currentObjectStack.length > 0){

        //console.log("STACK:", currentObjectStack);

        // hole Objekt aus dem Stack
        var currentObject = currentObjectStack.pop();
        // Wenn kein BPObjekt mehr vorhanden ist welches traversiert werden kann (also End Event wurde erreicht)

        //console.log("START", currentObject);

        incomingEdges = [];
        outgoingEdges = [];

        // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
        
        if(currentObject[c_in] != undefined){
          if(Array.isArray(currentObject[c_in])){
            for(var edge of currentObject[c_in]){
              incomingEdges.push(edge[c_nodeId]);
            }
          }else{
            incomingEdges.push(currentObject[c_in][c_nodeId]);
          }
        }

        if(currentObject[c_out] != undefined){
          if(Array.isArray(currentObject[c_out])){
            for(var edge of currentObject[c_out]){
              outgoingEdges.push(edge[c_nodeId]);
            }
          }else{
            outgoingEdges.push(currentObject[c_out][c_nodeId]);
          }
        }

        if(currentObject[c_in] != undefined && currentObject[c_out] != undefined){
        
          if(outgoingEdges.length > incomingEdges.length){
              for(var edge in outgoingEdges){
                gateWaysStack.push(currentObject.name);
              }
          }

          if(outgoingEdges.length < incomingEdges.length){
            gateWaysStack.pop();
            if(currentObject.name == gateWaysStack[gateWaysStack.length - 1]){
              reachedEndGateWay = true; 
            }
          }
        }

        if(currentObject[c_in] != undefined){

          var currentObjectShape = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape].find(e => e.bpmnElement == currentObject.id);

          var inEdges = currentObject[c_in];

          if(!Array.isArray(inEdges)){
            inEdges = [inEdges];
          }

          for(var inEdge of inEdges){

            var inEdgeLogic = edgeLogic.find(e => e.id == inEdge[c_nodeId]);

            if(inEdgeLogic != undefined){

              var currentInEdgeShape = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].find( e => e.bpmnElement == inEdgeLogic.id);
              //var index = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].indexOf(currentInEdgeShape);
              // visual edge nur links mittig rein, also x ist current object x
              if(currentObject.id.match("Task_") || currentObject.id.match("Service_") || currentObject.id.match("EndEvent_")){

                currentInEdgeShape[c_waypoint][currentInEdgeShape[c_waypoint].length - 1].x = currentObjectShape[c_bounds].x

              // visual edge oben oder unten mittig rein, also x ist current object x + visualStandWidth / 2
              }else if(currentObject.id.match("ExclusiveGateway_") || currentObject.id.match("ParallelGateway_")){

                // wenn es mehrere eingehende kanten sind
                if(currentObject[c_in].length > 1){
                  if((+currentInEdgeShape[c_waypoint][currentInEdgeShape[c_waypoint].length - 1].y) == (+currentInEdgeShape[c_waypoint][0].y)){
                    currentInEdgeShape[c_waypoint][currentInEdgeShape[c_waypoint].length - 1].x = currentObjectShape[c_bounds].x;          
                  }else{
                    currentInEdgeShape[c_waypoint][currentInEdgeShape[c_waypoint].length - 1].x = ((+currentObjectShape[c_bounds].x) + (visualStandardWidthGateway/2)).toString();             
                    currentInEdgeShape[c_waypoint][currentInEdgeShape[c_waypoint].length - 2].x = currentInEdgeShape[c_waypoint][currentInEdgeShape[c_waypoint].length - 1].x;
                    currentInEdgeShape[c_waypoint][currentInEdgeShape[c_waypoint].length - 2].y = currentInEdgeShape[c_waypoint][0].y;
                  }
                }else{
                // eine eingehende kante
                  currentInEdgeShape[c_waypoint][currentInEdgeShape[c_waypoint].length - 1].x = currentObjectShape[c_bounds].x;
                }               
              } 
            }
          }
        }

        //console.log(currentObject.name);

        if(currentObject[c_out] != undefined){

          var currentObjectShape = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape].find(e => e.bpmnElement == currentObject.id);

          var outEdges = currentObject[c_out];

          if(!Array.isArray(outEdges)){
            outEdges = [outEdges];
          }

          for(var outEdge of outEdges){

            var outEdgeLogic = edgeLogic.find(e => e.id == outEdge[c_nodeId]);

            if(outEdgeLogic != undefined){

              var currentOutEdgeShape = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].find( e => e.bpmnElement == outEdgeLogic.id);
              //var index = newBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].indexOf(currentInEdgeShape);

              // visual edge nur links mittig raus, also x ist current object x
              if(currentObject.id.match("Task_")){

                //console.log(currentObject, currentOutEdgeShape);

                currentOutEdgeShape[c_waypoint][0].x = ((+currentObjectShape[c_bounds].x) + visualStandardWidthTask).toString();

              // visual edge oben oder unten mittig raus, also x ist current object x + visualStandWidth / 2
              }else if(currentObject.id.match("StartEvent_")){

                currentOutEdgeShape[c_waypoint][0].x = ((+currentObjectShape[c_bounds].x) + visualStandardWidthEvent).toString();

              }else if(currentObject.id.match("ExclusiveGateway_") || currentObject.id.match("ParallelGateway_")){

              // mehrere ausgehende Kanten
                if(currentObject[c_out].length > 1){
                  if((+currentOutEdgeShape[c_waypoint][0].y) == (+currentOutEdgeShape[c_waypoint][currentOutEdgeShape[c_waypoint].length - 1].y)){
                    currentOutEdgeShape[c_waypoint][0].x = ((+currentObjectShape[c_bounds].x) + visualStandardWidthGateway).toString();            
                  }else{
                    currentOutEdgeShape[c_waypoint][0].x = ((+currentObjectShape[c_bounds].x) + (visualStandardWidthGateway/2)).toString(); 
                    currentOutEdgeShape[c_waypoint][1].x = ((+currentObjectShape[c_bounds].x) + (visualStandardWidthGateway/2)).toString(); 
                    currentOutEdgeShape[c_waypoint][1].y = currentOutEdgeShape[c_waypoint][currentOutEdgeShape[c_waypoint].length -1].y;         
                  }
              // eine ausgehende Kanten
                }else{
                  currentOutEdgeShape[c_waypoint][0].x = ((+currentObjectShape[c_bounds].x) + visualStandardWidthGateway).toString(); 
                  if((+currentOutEdgeShape[c_waypoint][0].y) != (+currentOutEdgeShape[c_waypoint][currentOutEdgeShape[c_waypoint].length - 1].y)){
                    currentOutEdgeShape[c_waypoint][1].x = currentOutEdgeShape[c_waypoint][currentOutEdgeShape[c_waypoint].length -1].x
                    currentOutEdgeShape[c_waypoint][1].y = currentOutEdgeShape[c_waypoint][0].y       
                  }       
                }              
              } 
            }
          }
        }

        if(currentObject.id.match("EndEvent")){
            return newBusinessProcess;
        }

        var outcomingEdge = currentObject[c_out];

        if(!Array.isArray(outcomingEdge)){
          outcomingEdge = [outcomingEdge];
        }

        // für jede ausgehende Kante des current objects
        for(var edge of outcomingEdge){

          var outEdge = edge[c_nodeId];

          var nextObject = allObjects.find( candidateObject => {

            var incomingEdges = candidateObject[c_in];

            if(!Array.isArray(incomingEdges)){
              incomingEdges = [incomingEdges]; 
            }

            // für jede eingehende Kante des candidate Objects
            for(var incomingEdge of incomingEdges){
              var inEdge = incomingEdge[c_nodeId];

              if(outEdge != undefined && inEdge != undefined && outEdge == inEdge){
                return candidateObject;
              }

            }

          });

          if(reachedEndGateWay != true){
            currentObjectStack.push(nextObject);
          }

        }

        reachedEndGateWay = false;

    }

  }catch(e){
    console.error(e);
  }

}

function buildBusinessProcess(startObject, sortedPaths, rawBusinessProcess, bp, bpObjectsArray){
  let methodName = ">>> [buildBusinessProcess]: ";  

  try{

      var incomingEdges;
      var outgoingEdges;
      var nextObject;
      var dataObjects = bp[c_definitions][c_process][c_dataRef];
      var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow]; 
      var currentObjectStack = [];
      var gateWaysStack = [];
      var reachedEndGateWay = false;

      var globalDecisions = [];

      var pathsUsedForBuilding = [];

      var processLogic = bp[c_definitions][c_process];
      var processVisuals = bp[c_definitions][c_diagram][c_diagramPlane];

      var logicObjectsAdded = [];
      var exchangeTasksToAdd = [];

      for(var x of sortedPaths){    
        //console.log(x);
      }

      // init stack
      currentObjectStack.push(startObject);
  
      while(currentObjectStack.length > 0){

        incomingEdges = [];
        outgoingEdges = [];
  
        // hole Objekt aus dem Stack
        var currentObject = currentObjectStack.pop();
        // Wenn kein BPObjekt mehr vorhanden ist welches traversiert werden kann (also End Event wurde erreicht)
        if(currentObject == undefined){
          // Wenn noch Objekte im Stack liegen
          if(currentObjectStack.length > 0){
            // hole Objekt aus dem Stack
            currentObject = currentObjectStack.pop();
          }else{

            for(var exchangeTask of exchangeTasksToAdd){

              //createKeyExchangeTask(rawBusinessProcess, exchangeTask.dataObject, [], )

            }

            return rawBusinessProcess;
          }
        }

        // wenn user task
        if(currentObject.type == c_userTasks){
          //hole doku
          var documentation = JSON.parse(currentObject.bpObject[c_documentation][c_nodeId]);

          // für jedes datenobjekt
          for(var data of documentation.outgoingData){


            var foundPathsForData = [];

            // gehe alle absteigend sortierten augmentiertedn Pfad durch
            for(var sortedPath of sortedPaths){

              
              console.log("For Data: ",sortedPath.dataObject);
              for(var path of sortedPath.augmentedPaths){

                console.log("Path Cost: ", path.totalCost);

                if(bp[c_definitions][c_process][c_userTasks].find(e => e.id == path.position) != undefined){
                  if(path.mergedKeyExchange != undefined){
                    console.log("Exchange included in ", path.mergedKeyExchange[0]);
                  }else{
                    console.log("Exchange placed in front of: ", bp[c_definitions][c_process][c_userTasks].find(e => e.id == path.position).name);
                  }
                }else if(bp[c_definitions][c_process][c_exclusive].find(e => e.id == path.position) != undefined){
                  if(path.mergedKeyExchange != undefined){
                    console.log("Exchange included in ", path.mergedKeyExchange[0]);
                  }else{
                    console.log("Exchange placed in front of: ",bp[c_definitions][c_process][c_exclusive].find(e => e.id == path.position).name);
                
                  }
                }else if(bp[c_definitions][c_process][c_parallel].find(e => e.id == path.position) != undefined){
                  if(path.mergedKeyExchange != undefined){
                    console.log("Exchange included in ", path.mergedKeyExchange[0]);
                  }else{
                    console.log("Exchange placed in front of: ", bp[c_definitions][c_process][c_parallel].find(e => e.id == path.position).name);
                  }
                }
              }
              console.log("############## NEXT #############");

              // wenn der aktuelle augmentierte Pfad für das aktuelle datenobjekt ist und der sendende task des pfad das current object ist
              if(sortedPath.dataObject == data.name && sortedPath.sendingTask == currentObject.bpObject.name){
                // füge den augmentierten pfad als Kandidatpfad hinzu
                foundPathsForData.push(sortedPath);
              }

            }

            //console.log(currentObject.bpObject.name,foundPathsForData);

            var minimum = 0;

            // für alle augmentierten Pfade des aktuellen Datenobjekts
            for(var foundPaths of foundPathsForData){
              // für alle pfade der augmentierten pfade
              for(var path of foundPaths.augmentedPaths){

                // wenn der candidate pfad wirklich ab dem current objekt beginnt
                if(path.path[0].id == currentObject.bpObject.id){

                  if(minimum == path.totalCost){
                    pathsUsedForBuilding.push({dataObject: data.name, path: path, decision: foundPaths.decisions});
                  }

                  if(minimum == 0){              
                      minimum = path.totalCost;
                      pathsUsedForBuilding.push({dataObject: data.name, path: path, decision: foundPaths.decisions});
                  }

                }
              }  
            }  
          }
        }

        //console.log(currentObject.bpObject.name, pathsUsedForBuilding);

        // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
        if(currentObject.type == c_parallel || currentObject.type == c_exclusive){

          if(Array.isArray(currentObject.bpObject[c_in])){
            for(var edge of currentObject.bpObject[c_in]){
              incomingEdges.push(edge[c_nodeId]);
            }
          }else{
            incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
          }
          if(Array.isArray(currentObject.bpObject[c_out])){
            for(var edge of currentObject.bpObject[c_out]){
              outgoingEdges.push(edge[c_nodeId]);
            }
          }else{
            outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
          }

          if(outgoingEdges.length > incomingEdges.length){
              for(var edge in outgoingEdges){
                gateWaysStack.push(currentObject.bpObject.name);
              }
          }

          if(outgoingEdges.length < incomingEdges.length){
            gateWaysStack.pop();
            if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
              reachedEndGateWay = true;   
            }
          }
        }

        // für jeden "bauplan"
        for(var buildingPath of pathsUsedForBuilding){

          var currentObjectLogic;
          var currentObjectVisual;

          //console.log(buildingPath.path);
          //console.log(currentObject.bpObject.name, buildingPath);

          // wenn das current object noch nicht zum neuen BP hinzugefügt wurde
          if(logicObjectsAdded.find(e => e == currentObject.bpObject.id) == undefined && currentObject.type != c_end){


            //console.log(currentObject.bpObject.name);

            // pro objekt typ
            switch (currentObject.type) {
              case c_userTasks:

                // find logic object in default BP
                var currentObjectLogic = processLogic[c_userTasks].find(e => e.id == currentObject.bpObject.id);

                // if the current task is also exchanging the keys directly
                if(buildingPath.path.mergedKeyExchange != undefined){
                  if(buildingPath.path.mergedKeyExchange.find(e => e == currentObjectLogic.name) != undefined){
                    var documentation = JSON.parse(currentObjectLogic[c_documentation][c_nodeId]);
                    var sphere = documentation.spheres.find( e => e.dataObject == buildingPath.dataObject);
                    sphere.exchangeKeys = true;
                    var index = documentation.spheres.indexOf(sphere);
                    documentation.spheres.splice(index);
                    documentation.spheres.push(sphere);
                    currentObjectLogic[c_documentation][c_nodeId] = JSON.stringify(documentation);
                  }
                }

                break;
  
              case c_exclusive:

                // find logic object in default BP
                var currentObjectLogic = processLogic[c_exclusive].find(e => e.id == currentObject.bpObject.id);

                break; 
              
              case c_parallel:

                // find logic object in default BP
                var currentObjectLogic = processLogic[c_parallel].find(e => e.id == currentObject.bpObject.id);

                break;  
            }

            // find visual object in default BP
            var currentObjectVisual = processVisuals[c_shape].find(e => e.bpmnElement == currentObjectLogic.id);

            // find logic of in- and outgoing edges in default BP
            var edges = [];
            for(var edge of processLogic[c_sequenceFlow]){
              if(edge.sourceRef == currentObject.bpObject.id || edge.targetRef == currentObject.bpObject.id){
                edges.push(edge);
              }
            }
            
            // find visual of edges in default BP
            var visualEdges = [];
            for(var edge of edges){
              visualEdges.push(processVisuals[c_edge].find( e => e.bpmnElement == edge.id));
            }

            var index = buildingPath.path.path.map(e => e.id).indexOf(currentObjectLogic.id);

            //console.log(currentObject.bpObject.name, buildingPath.path);
            //console.log(index);

            if(index > 0){
              // add keyExchange task
              exchangeTasksToAdd.push({dataObject: buildingPath.dataObject, beforeObject: currentObject.bpObject, exchangeObjectRaw: buildingPath.path.path[0]})
              //console.log(buildingPath.path.path[0]);
            }

            // add task logic to new BP
            rawBusinessProcess[c_definitions][c_process][c_userTasks].push(currentObjectLogic);
            // add edge logic to new BP
            rawBusinessProcess[c_definitions][c_process][c_sequenceFlow] = rawBusinessProcess[c_definitions][c_process][c_sequenceFlow].concat(edges);
            // add task visual to new BP
            rawBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_shape].push(currentObjectVisual);
            // add edge visuals to new BP
            rawBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge] = rawBusinessProcess[c_definitions][c_diagram][c_diagramPlane][c_edge].concat(visualEdges);


            logicObjectsAdded.push(currentObjectLogic.id);
            //console.log(rawBusinessProcess);

            var index = buildingPath.path.path.map(e => e.id).indexOf(currentObjectLogic.id);
            buildingPath.path.path.splice(index, 1);    
          
          }
        }

        // hole ausgehende Kante/n vom aktuellen BPObjekt 
        var outcomingEdge = currentObject.bpObject[c_out];

        // wenn es Kanten sind...
        if(Array.isArray(outcomingEdge)){
            for(var key in outcomingEdge){
              var edge = outcomingEdge[key][c_nodeId];

              // get edge description for outgoing edge from decision gateway
              if(currentObject.type == c_exclusive){
                var edgeDescription = sequenceFlows.find( e => e.id == edge);
              }

              nextObject = bpObjectsArray.find( processObject => {
                var ingoingEdges = processObject.bpObject[c_in];
                // wenn es mehrere eingehende Kanten vom Objekt sind...
                if(Array.isArray(ingoingEdges)){
                  for(var ingoingEdge of ingoingEdges){
                    if(edge != undefined && edge == ingoingEdge[c_nodeId]){
                      return processObject;
                    }   
                  }
                // nur eine ausgehende Kante
                }else{
                  if(edge != undefined && edge == ingoingEdges[c_nodeId]){
                    return processObject;
                  }    
                }
              });

              // lege auf den Stack
              if(reachedEndGateWay != true){
                currentObjectStack.push(nextObject);
              }
            }
            // ..ansonsten nur für eine Kante
        }else{
          nextObject = bpObjectsArray.find( processObject => {
            var ingoingEdges = processObject.bpObject[c_in];
            // wenn es mehrere ausgehende Kanten vom Objekt sind...
            if(Array.isArray(ingoingEdges)){
              for(var ingoingEdge of ingoingEdges){
                if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdge[c_nodeId]){
                  return processObject;
                }   
              }
            // nur eine ausgehende Kante
            }else{
              if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdges[c_nodeId]){
                return processObject;
              }    
            }
          })
          // lege auf den Stack
          if(reachedEndGateWay != true){
          currentObjectStack.push(nextObject);
          }
        }

        reachedEndGateWay = false;

    }

  }catch(e){
    console.error(e);
  }

}

function transformBusinessProcess(bp){
  let methodName = ">>> [transformBusinessProcess]: ";  
  
    var treeStruct = {
      treeNodes: []
    }
  
    try{
  
      var reachedEnd = false;
      
      var startTask = bp[c_definitions][c_process][c_start];
      var traversedBusinessProcess = startTraversing(startTask, null, bp, c_forward, true, undefined, undefined, undefined);
  
      for(var traversedElement of traversedBusinessProcess){
  
        var nextElement;
        var currentElementAdded = false;
        var chosenNextNode = [];
        var candidateNextNode = [];
  
        var currentElement = {  
          bpmnObject: "",    
          type: "",
          taskName: "",
          participant: ""
        };
  
        candidateNextNode.push(traversedElement);
  
        var outgoingEdge = traversedElement.bpObject[c_out];
        if(!Array.isArray(outgoingEdge)){
          outgoingEdge = [outgoingEdge];
        }

        //console.log(outgoingEdge)

        if(traversedElement.bpObject.name.includes("Loop") && traversedElement.bpObject.id.includes("split")){

          var outgoingEdgeFromLoop = [];

          for(var edge of outgoingEdge){

            var found = bp[c_definitions][c_process][c_sequenceFlow].find(e => {

              if(e.id == edge[c_nodeId] && e.name == "no"){
                return e;
              }
            });

            if(found != undefined){
              outgoingEdgeFromLoop.push(edge);
            }

          }

          outgoingEdge = outgoingEdgeFromLoop;              
        }
  
        outgoingEdge.forEach( edge => {
  
            var foundNextNode = traversedBusinessProcess.find( candidateElement => {
    
              var incomingEdges = candidateElement.bpObject[c_in];
              if(!Array.isArray(incomingEdges)){
                incomingEdges = [incomingEdges];
              }
      
              // suche für jede eingehene Kante des Kandidaten..
              var resultIn = incomingEdges.find( inEdge => {
                if(edge != undefined && inEdge != undefined){
                  if(edge[c_nodeId] == inEdge[c_nodeId]){
                    return inEdge;
                  }
                }
              });
      
              if(resultIn != null){
                return candidateElement;
              }
            });
    
            if(foundNextNode != null){
              candidateNextNode.push(foundNextNode);
            }
    
        });
  
        if(candidateNextNode.length == 0){
          reachedEnd = true;
        }
  
        candidateNextNode.forEach( candidate => {
  
          nextElement = {
            bpmnObject: "",
            type: "",
            taskName: "",
            participant: ""
          };
  
          switch(candidate.type){
            case c_tasks:
              if(!currentElementAdded && candidate.type == traversedElement.type){
                currentElement.bpmnObject = traversedElement.bpObject;
                currentElement.type = c_taskType;
                currentElement.taskName = traversedElement.bpObject.name;
                currentElement.participant = findOccurenceInString(traversedElement.bpObject.name,'[', ']');
                currentElementAdded = true;
              }else{
                nextElement.bpmnObject = candidate.bpObject;
                nextElement.type = c_taskType;
                nextElement.taskName = candidate.bpObject.name;
                nextElement.participant = findOccurenceInString(candidate.bpObject.name,'[', ']');
                chosenNextNode.push(nextElement);
              }
  
              break;
            case c_serviceTasks:
              if(!currentElementAdded && candidate.type == traversedElement.type){
                currentElement.bpmnObject = traversedElement.bpObject;
                currentElement.type = c_serviceTasks;
                currentElement.taskName = traversedElement.bpObject.name;
                currentElement.participant = findOccurenceInString(traversedElement.bpObject.name,'[', ']');
                currentElementAdded = true;
              }else{
                nextElement.bpmnObject = candidate.bpObject;
                nextElement.type = c_serviceTasks;
                nextElement.taskName = candidate.bpObject.name;
                nextElement.participant = findOccurenceInString(candidate.bpObject.name,'[', ']');
                chosenNextNode.push(nextElement);
              }
  
              break;

            case c_userTasks:
              if(!currentElementAdded && candidate.type == traversedElement.type){
                currentElement.bpmnObject = traversedElement.bpObject;
                currentElement.type = c_userTasks;
                currentElement.taskName = traversedElement.bpObject.name;
                currentElement.participant = findOccurenceInString(traversedElement.bpObject.name, '[', ']');
                currentElementAdded = true;
              }else{
                nextElement.bpmnObject = candidate.bpObject;
                nextElement.type = c_taskType;
                nextElement.taskName = candidate.bpObject.name;
                nextElement.participant = findOccurenceInString(candidate.bpObject.name, '[', ']');
                chosenNextNode.push(nextElement);
              }
    
              break;  
            case c_parallel:
              if(!currentElementAdded && candidate.type == traversedElement.type){
                currentElement.bpmnObject = traversedElement.bpObject;
                currentElement.type = c_gatewayType;
                currentElement.taskName = traversedElement.bpObject.name;
                currentElement.participant = "All";
                currentElementAdded = true;
              }else{
                nextElement.bpmnObject = candidate.bpObject;
                nextElement.type = c_gatewayType;
                nextElement.taskName = candidate.bpObject.name;
                nextElement.participant = "All";
                chosenNextNode.push(nextElement);
              }
  
              break;
            case c_exclusive:
              if(!currentElementAdded && candidate.type == traversedElement.type){
                currentElement.bpmnObject = traversedElement.bpObject;
                currentElement.type = c_gatewayType;
                currentElement.taskName = traversedElement.bpObject.name;
                currentElement.participant = "All";
                currentElementAdded = true;
              }else{
                nextElement.bpmnObject = candidate.bpObject;
                nextElement.type = c_gatewayType;
                nextElement.taskName = candidate.bpObject.name;
                nextElement.participant = "All";
                chosenNextNode.push(nextElement);
              }
  
              break;
            case c_start:
              if(!currentElementAdded && candidate.type == traversedElement.type){
                currentElement.bpmnObject = traversedElement.bpObject;
                currentElement.type = c_eventType;
                currentElement.taskName = traversedElement.bpObject.name;
                currentElement.participant = "No Participant"
                currentElementAdded = true;
              }else{
                nextElement.bpmnObject = candidate.bpObject;
                nextElement.type = c_eventType;
                nextElement.taskName = candidate.bpObject.name;
                nextElement.participant = "No Participant";
                chosenNextNode.push(nextElement);
              }
  
              break;
            case c_end:
              if(!currentElementAdded && candidate.type == traversedElement.type){
                currentElement.bpmnObject = traversedElement.bpObject;
                currentElement.type = c_eventType;
                currentElement.taskName = traversedElement.bpObject.name;
                currentElement.participant = "No Participant"
                currentElementAdded = true;
              }else{
                nextElement.bpmnObject = candidate.bpObject;
                nextElement.type = c_eventType;
                nextElement.taskName = candidate.bpObject.name;
                nextElement.participant = "No Participant";
                chosenNextNode.push(nextElement);
              }
  
              break;
            default:
              break;
          }
  
        });
  
        var tupel = {
          currentNode: null, 
          nextNode: null
        };
  
        tupel.currentNode = currentElement;
  
        if(chosenNextNode.length == 1){
          tupel.nextNode = chosenNextNode[0];
        }else{
          tupel.nextNode = chosenNextNode;
        }
  
        treeStruct.treeNodes.push(tupel);
  
      }
  
      return treeStruct;

    }catch(e){
      console.error(methodName, e);
    }
  
  }

function traverseTree(tree, bp){
  let methodName = ">>> [traverseTree]: ";

  try{

    var tupel = tree.treeNodes.find( tupel => tupel.currentNode.taskName == startTask.name);

    var tupelStack = [];
    var passedObjects = [];
    var dataRef = bp[c_definitions][c_process][c_dataRef];

    if(!Array.isArray(dataRef)){
      dataRef = [dataRef];
    }

    tupelStack.push(tupel);

    while(tupelStack.length > 0){

      tupel = tupelStack.pop();
      var foundObject = passedObjects.find( e => tupel.currentNode.taskName == e.name);

      if(foundObject == undefined){

        passedObjects.push(tupel.currentNode.bpmnObject);

        if(tupel.currentNode.type == c_userTasks){

          var documentation = JSON.parse(tupel.currentNode.bpmnObject[c_documentation][c_nodeId]);

          // wenn der UserTask ausgehende Daten hat und Teil einer Strong-Dynamic Sphere ist
          if(documentation.outgoingData != undefined){

            for(var currentData of documentation.outgoingData){

              var dataObject = dataRef.find( data => data.name == currentData.name);

              documentation.spheres.find( sphere => {
                if(sphere.sphereType == c_weakDynamic && sphere.dataObject == dataObject.name){
                  // traversing used to find all possible path decisions
                  var possiblePathDecisionsWeakDynamic = startTraversing(tupel.currentNode.bpmnObject, dataObject, bp, c_pathDecisionTraversing, undefined, undefined, undefined, undefined);
                  possiblePathsForEachTaskWeakDynamic.push({taskObject: tupel.currentNode.bpmnObject, dataObject: dataObject , pathDecisions: possiblePathDecisionsWeakDynamic});
                }
              }); 
              
              documentation.spheres.find( sphere => {
                if(sphere.sphereType == c_strongDynamic && sphere.dataObject == dataObject.name){    
                            
                  // traversing used to find all possible path decisions
                  var possiblePathDecisionsStrongDynamic = startTraversing(tupel.currentNode.bpmnObject, dataObject, bp, c_pathDecisionTraversing, undefined, undefined, undefined, undefined);
                  possiblePathsForEachTaskStrongDynamic.push({taskObject: tupel.currentNode.bpmnObject, dataObject: dataObject , pathDecisions: possiblePathDecisionsStrongDynamic});
                }
              });

            }
          }
        }
      }

      var nextNode = tupel.nextNode;

      if(!Array.isArray(nextNode)){
        nextNode = [nextNode];
      }

      nextNode.forEach( node => {
        var newTupel = tree.treeNodes.find( tupel => tupel.currentNode.bpmnObject.id == node.bpmnObject.id);
        tupelStack.push(newTupel);
      });

    }

  }catch(e){
    console.error(e);
  }

}

function getAnnotation(_task, bp){
  let methodName = ">>> [getAnnotation]: "; 

  try{

  var annotations = bp[c_definitions][c_process][c_annotation];
  var associations = bp[c_definitions][c_process][c_association];

  if(annotations == undefined){
    return undefined;
  }

  if(associations != undefined){
    if(!Array.isArray(associations)){
      associations = [associations]; 
    }
  }else{
    return undefined;
  }

  var foundAnnotation = [];

  for(var assoc of associations){

    if(assoc.sourceRef == _task.id){
      foundAnnotation.push(annotations.find(e => e.id == assoc.targetRef));
    }
  
  }

  return foundAnnotation;

  }catch(e){
    console.error(methodName, e);
  }

}

/**
 *    
 * @desc              Search for all members, which access the Data-Object 'dataObject' and edit their task description.                    
 * 
 * @param bp          The imported business process in JSON.
 * @param dataObject  Name of the specific Data-Object
 */
function updateTasks(bp,dataObject){
  let methodName = ">>> [updateTasks]: "; 

  try{

    var startTask = bp[c_definitions][c_process][c_start];
    var dataObjects = bp[c_definitions][c_process][c_dataRef];

    if(!Array.isArray(dataObjects)){
      dataObjects = [dataObjects];
    }

    var traversedBP = startTraversing(startTask, dataObject.id, bp, c_forward, true, undefined, undefined, undefined);
    var initiatingMember = "";

    for(var currentObject of traversedBP){        
      if(currentObject.type == c_userTasks){

        var userTask = bp[c_definitions][c_process][c_userTasks].find( e => currentObject.bpObject.id == e.id);

        // get default sphere for current data-object (if defined)
        var dataName = findOccurenceInString(dataObject.name, '[', ']');
        var defaultSphereForDataObject = globalAnnotations.find(e => e.dataObject == dataName);

        if(defaultSphereForDataObject != undefined){
          var currentSphereForDataObject = defaultSphereForDataObject.defaultSphere;
        }

        // get sphere for current data-object at current task
        var userDefinedAnnotation = getAnnotation(userTask, bp);

        for(var annotation of userDefinedAnnotation){
          if(findOccurenceInString(annotation[c_text][c_nodeId], '[', ']') == dataName){
            currentSphereForDataObject = findOccurenceInString(annotation[c_text][c_nodeId], '{', '}');
          }
        }

        if(isInArray(currentObject.outgoingDataObject,dataObject)){
            allPossibleSpheres.push({dataObject: dataName, participant: currentObject.bpObject[c_assignee] ,sphere: currentSphereForDataObject});
        }

        var documentation = { 
          "type": currentObject.type,
          "decision": [],
          "incomingData": currentObject.incomingDataObject,
          "outgoingData": currentObject.outgoingDataObject,
          "spheres": []
        }

        if(userTask[c_documentation][c_nodeId] != undefined){
          documentation = JSON.parse(userTask[c_documentation][c_nodeId]);

          if(documentation.decisionExpressionPostfix != undefined){

            documentation.type = currentObject.type;
            documentation.decision = [];
            documentation.incomingData = currentObject.incomingDataObject;
            documentation.outgoingData = currentObject.outgoingDataObject;
            documentation.spheres = [];

          }
        }

         // set the variables for each data object

         for(var outgoingData of currentObject.outgoingDataObject){

          var dataObjectShort = findOccurenceInString(outgoingData.name, "[", "]");

          documentation[dataObjectShort] = [];

          var foundData = dataObjects.find(e => e.name == outgoingData.name);

          if(foundData != undefined){

            documentation[dataObjectShort] = foundData[c_extension][c_camundaProperties][c_camundaProperty];

          }

        }

        for(var incomingData of currentObject.incomingDataObject){

          var dataObjectShort = findOccurenceInString(incomingData.name, "[", "]");

          documentation[dataObjectShort] = [];

          var foundData = dataObjects.find(e => e.name == incomingData.name);

          if(foundData != undefined){

            documentation[dataObjectShort] = foundData[c_extension][c_camundaProperties][c_camundaProperty];

          }

        }

          var sphere = {
            "dataObject": dataObject.name,
            "sphereType": "",
            "initiatingMember": "",
            "members": []
          }

          switch(currentSphereForDataObject){

            //###################
            //#### PUBLIC #######
            //###################

            //public - no encryption
            case c_public:

            // update only tasks which have the current data object incoming or outgoing
            if(isInArray(currentObject.incomingDataObject,dataObject) || isInArray(currentObject.outgoingDataObject,dataObject)){

              sphere.sphereType = c_public;

              if(isInArray(currentObject.initiatingDataObject,dataObject)){
                initiatingMember = currentObject.bpObject[c_assignee];
              }
              sphere.initiatingMember = initiatingMember;

              for(var candidateObject of traversedBP){
                
                if(candidateObject.type == c_userTasks){

                  var inDataPresent = isInArray(candidateObject.incomingDataObject,dataObject);
                  var outDataPresent = isInArray(candidateObject.outgoingDataObject,dataObject);

                  var memberInSphere = publicSphereParticipants.find( e => e.name == candidateObject.bpObject[c_assignee]);
                  var alreadyInSphere = false;

                  if(memberInSphere != undefined){
                    alreadyInSphere = true;
                  }                 
                  
                  if((inDataPresent || outDataPresent) && alreadyInSphere == false && isInArray(currentObject.outgoingDataObject,dataObject)){
                    publicSphereParticipants.push({name: candidateObject.bpObject[c_assignee]});
                  }
                }
              }
            }

            break;

            //###################
            //#### GLOBAL #######
            //###################

            //global - one key generated for all chosen objects, used for the objects till process ends.
            case c_global:

              // update only tasks which have the current data object incoming or outgoing
              if(isInArray(currentObject.incomingDataObject,dataObject) || isInArray(currentObject.outgoingDataObject,dataObject)){

                sphere.sphereType = c_global;

                if(isInArray(currentObject.initiatingDataObject,dataObject)){
                  initiatingMember = currentObject.bpObject[c_assignee];
                }
                sphere.initiatingMember = initiatingMember;

                //userTask which generates the keys for the members and distributes them.
                //get all tasks which access the data and distribute the keys to them.
                for(var candidateObject of traversedBP){
                
                  if(candidateObject.type == c_userTasks){

                    var inDataPresent = isInArray(candidateObject.incomingDataObject,dataObject);
                    var outDataPresent = isInArray(candidateObject.outgoingDataObject,dataObject);

                    var memberInSphere = globalSphereParticipants.find( e => e.name == candidateObject.bpObject[c_assignee]);                  
                    var alreadyInSphere = false;

                    if(memberInSphere != undefined){
                      alreadyInSphere = true;
                    }                 
                    
                    if((inDataPresent || outDataPresent) && alreadyInSphere == false && isInArray(currentObject.outgoingDataObject,dataObject) && currentObject.bpObject[c_assignee] != candidateObject.bpObject[c_assignee]){
                      globalSphereParticipants.push({name: candidateObject.bpObject[c_assignee]});
                    }
                  }
                }
              }

              break;

            //###################
            //#### STATIC #######
            //###################  

            // static - one key generated for each data object, used for the objects till process ends.
            case c_static:

              // update only tasks which have the current data object incoming or outgoing
              if(isInArray(currentObject.incomingDataObject,dataObject) || isInArray(currentObject.outgoingDataObject,dataObject)){

                sphere.sphereType = c_static;

                if(isInArray(currentObject.initiatingDataObject,dataObject)){
                  initiatingMember = currentObject.bpObject[c_assignee];
                }
                sphere.initiatingMember = initiatingMember;

                //userTask which generates the keys for the members and distributes them.
                //get all tasks which access the data and distribute the keys to them.
                for(var candidateObject of traversedBP){
                  if(candidateObject.type == c_userTasks){

                    var inDataPresent = isInArray(candidateObject.incomingDataObject,dataObject);
                    var outDataPresent = isInArray(candidateObject.outgoingDataObject,dataObject);

                    var memberInSphere = sphere.members.find( e => e.name == candidateObject.bpObject[c_assignee]);
                    var alreadyInSphere = false;

                    if(memberInSphere != undefined){
                      alreadyInSphere = true;
                    }
                    
                    if((inDataPresent || outDataPresent) && alreadyInSphere == false && currentObject.bpObject[c_assignee] != candidateObject.bpObject[c_assignee]){
                      sphere.members.push({name: candidateObject.bpObject[c_assignee]});
                    }
                  }
                }
              } 

              break;

            //#########################
            //#### WEAK-DYNAMIC #######
            //#########################
            case c_weakDynamic:

              // update only tasks which have the current data object incoming or outgoing
              if(isInArray(currentObject.incomingDataObject,dataObject) || isInArray(currentObject.outgoingDataObject,dataObject)){

                sphere.sphereType = c_weakDynamic;

                if(isInArray(currentObject.initiatingDataObject,dataObject)){
                  initiatingMember = currentObject.bpObject[c_assignee];
                }
                sphere.initiatingMember = initiatingMember;

                //userTask which generates the keys for the members and distributes them.
                //get all tasks which read the data only and distribute the keys to them.
                for(var candidateObject of traversedBP){

                  if(candidateObject.type == c_userTasks){

                    var inDataPresent = isInArray(candidateObject.incomingDataObject,dataObject);

                    var memberInSphere = sphere.members.find( e => e.name == candidateObject.bpObject[c_assignee]);
                    var alreadyInSphere = false;

                    if(memberInSphere != undefined){
                      alreadyInSphere = true;
                    }
                    
                    if(inDataPresent && alreadyInSphere == false){
                      sphere.members.push({name: candidateObject.bpObject[c_assignee]});
                    }
                  }
                }

              }

              break;

            //#########################
            //#### STRONG-DYNAMIC #####
            //#########################
            case c_strongDynamic: 

              // update only tasks which have the current data object incoming or outgoing
              if(isInArray(currentObject.incomingDataObject,dataObject) || isInArray(currentObject.outgoingDataObject,dataObject)){
             
                sphere.sphereType = c_strongDynamic;

                if(isInArray(currentObject.initiatingDataObject,dataObject)){
                  initiatingMember = currentObject.bpObject[c_assignee];
                }

                sphere.initiatingMember = initiatingMember;
                var objectsInWeakDynamicSphere = [];

                //userTask which generates the keys for the members and distributes them.
                //get all tasks which read the data only and distribute the keys to them.
                for(var candidateObject of traversedBP){

                  if(candidateObject.type == c_userTasks){

                    var inDataPresent = isInArray(candidateObject.incomingDataObject,dataObject);
                    var taskInSphere = objectsInWeakDynamicSphere.find( e => e == candidateObject.bpObject.name);
                    var alreadyInSphere = false;

                    if(taskInSphere != undefined){
                      alreadyInSphere = true;
                    }

                    if(inDataPresent && alreadyInSphere == false){                
                      objectsInWeakDynamicSphere.push(candidateObject);
                    }
                  }
                }

                // at this point the weak-dynamic sphere has been generated.
                // the tasks in the weak-dynamic sphere are candidates for the strong-dynamic sphere.

                for(var candidateObject of objectsInWeakDynamicSphere){
                  if(sphere.members.find( e => e.name == candidateObject.bpObject[c_assignee]) == undefined){
                    sphere.members.push({name: candidateObject.bpObject[c_assignee]});
                  }
                }
              }

              break;
          } 

          for(var userTask of bp[c_definitions][c_process][c_userTasks]){

            if(currentObject.bpObject.id == userTask.id){
              if(isInArray(currentObject.outgoingDataObject,dataObject) || isInArray(currentObject.incomingDataObject,dataObject)){
                documentation.spheres.push(sphere);
              }
              userTask[c_documentation][c_nodeId] = JSON.stringify(documentation);
            }
          }
      }
    } 

    return traversedBP;
                

  }catch(e){
    console.error(methodName, e);
  }
}

function getReceiversForSharing(sender,bpObjectsArray, bp){
  let methodName = ">>> [forwardTraversing]: "; 
  
    try{

      var incomingEdges;
      var outgoingEdges;
      var nextObject;
      var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow]; 
      var currentObjectStack = [];
      var gateWaysStack = [];
      var reachedEndGateWay = false;

      var globalDecisions = [];
      var chosenEdgeLoop = null;

      var receivers = {
        otherReceivers: [],
        strongDynamicReceivers: []
      };

      // init stack
      currentObjectStack.push(sender);
  
      while(currentObjectStack.length > 0){

        incomingEdges = [];
        outgoingEdges = [];

        // hole Objekt aus dem Stack
        var currentObject = currentObjectStack.pop();

        // Wenn kein BPObjekt mehr vorhanden ist welches traversiert werden kann (also End Event wurde erreicht)
        if(currentObject == undefined){
          // Wenn noch Objekte im Stack liegen
          if(currentObjectStack.length > 0){
            // hole Objekt aus dem Stack
            currentObject = currentObjectStack.pop();
          }else{
            return receivers;
          }
        }

        if(currentObject.type == c_userTasks && currentObject.bpObject.name != sender.bpObject.name){
          var currentTaskDocumentation = JSON.parse(currentObject.bpObject[c_documentation][c_nodeId]);
          var senderTaskDocumentation = JSON.parse(sender.bpObject[c_documentation][c_nodeId]);



          var outgoingData = senderTaskDocumentation.outgoingData.map(e => e.name);

          if(currentTaskDocumentation.incomingData != undefined){
            
            for(var dataObject of outgoingData){

              var foundSphere = senderTaskDocumentation.spheres.find(e => findOccurenceInString(e.dataObject, "[", "]") == findOccurenceInString(dataObject, "[", "]"));

              if(foundSphere != undefined){

                if(foundSphere.sphereType != c_strongDynamic){
                  if(isInArray(currentTaskDocumentation.incomingData.map(e => e.name), dataObject)){
                    receivers.otherReceivers = Array.from(new Set(receivers.otherReceivers.concat(currentObject.bpObject[c_assignee])));
                  }

                }else{

                  if(isInArray(currentTaskDocumentation.incomingData.map(e => e.name), dataObject)){
                    receivers.strongDynamicReceivers.push({receiver: currentObject.bpObject[c_assignee], decision: globalDecisions});
                  }               

                }               

              }
            }

          }

          /* if(currentTaskDocumentation.outgoingData != undefined){
            
            for(var dataObject of outgoingData){
              if(isInArray(currentTaskDocumentation.outgoingData.map(e => e.name), dataObject)){
                return receivers;
              }
            }

          } */

        }

        // set the current decision variables in this current path
        if(currentObject.decisions.length > 0){
          globalDecisions = globalDecisions.concat(currentObject.decisions);
        }

        // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
        if(currentObject.type == c_parallel || currentObject.type == c_exclusive){

            if(Array.isArray(currentObject.bpObject[c_in])){
              for(var edge of currentObject.bpObject[c_in]){
                incomingEdges.push(edge[c_nodeId]);
              }
            }else{
              incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
            }
            if(Array.isArray(currentObject.bpObject[c_out])){
              for(var edge of currentObject.bpObject[c_out]){
                outgoingEdges.push(edge[c_nodeId]);
              }
            }else{
              outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
            }

            // Wenn das Gateway einem Loop angehört -> Prüfe ob eingehendes oder ausgehendes
            if(currentObject.bpObject.name.includes("Loop")){

              // Loop-Gateway entscheidung -> immer nein da nicht geloopt wird
              if(outgoingEdges.length > incomingEdges.length){
                for(var edge of outgoingEdges){

                  if(chosenEdgeLoop != undefined){
                    continue;
                  }

                  chosenEdgeLoop = sequenceFlows.find(e => {
                    if(e.id == edge){
                      if(e.name == "no"){
                        return e;
                      }
                    }
                  });

                }
              }

            }else{

              if(outgoingEdges.length > incomingEdges.length){
                  for(var edge in outgoingEdges){
                    gateWaysStack.push(currentObject.bpObject.name);
                  }
              }

              if(outgoingEdges.length < incomingEdges.length){
                gateWaysStack.pop();
                if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
                  reachedEndGateWay = true;   
                }
                // reached the end Gateway -> remove Decision Variable because the Decision does not matter for the candidateObject
                //console.log("before Filter: ", currentObject.bpObject.name, globalDecisions);
                globalDecisions = globalDecisions.filter( gateway => gateway.name != currentObject.bpObject.name);
                //console.log("after Filter: ", currentObject.bpObject.name, globalDecisions);
              }

            }

        }

        var outcomingEdge = {};

        if(chosenEdgeLoop != null){

          outcomingEdge[c_nodeId] = chosenEdgeLoop.id;
          chosenEdgeLoop = null;

        }else{

          // hole ausgehende Kante/n vom aktuellen BPObjekt 
          outcomingEdge = currentObject.bpObject[c_out];

        }

        // wenn es Kanten sind...
        if(Array.isArray(outcomingEdge)){
            for(var key in outcomingEdge){
              var edge = outcomingEdge[key][c_nodeId];

              // get edge description for outgoing edge from decision gateway
              if(currentObject.type == c_exclusive){
                var edgeDescription = sequenceFlows.find( e => e.id == edge);
              }

              nextObject = bpObjectsArray.find( processObject => {
                var ingoingEdges = processObject.bpObject[c_in];
                // wenn es mehrere eingehende Kanten vom Objekt sind...
                if(Array.isArray(ingoingEdges)){
                  for(var ingoingEdge of ingoingEdges){
                    if(edge != undefined && edge == ingoingEdge[c_nodeId]){
                      return processObject;
                    }   
                  }
                // nur eine ausgehende Kante
                }else{
                  if(edge != undefined && edge == ingoingEdges[c_nodeId]){
                    return processObject;
                  }    
                }
              });

              if(currentObject.type == c_exclusive && nextObject.bpObject.id == edgeDescription.targetRef && !nextObject.bpObject.name.includes("Loop") && edgeDescription.name != undefined){
                //console.log(nextObject.bpObject.name)
                //console.log(currentObject.bpObject.name, edgeDescription.name);
                nextObject.decisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});
              }

              // lege auf den Stack
              if(reachedEndGateWay != true){
                currentObjectStack.push(nextObject);
              }
            }
            // ..ansonsten nur für eine Kante
        }else{
          nextObject = bpObjectsArray.find( processObject => {
            var ingoingEdges = processObject.bpObject[c_in];
            // wenn es mehrere ausgehende Kanten vom Objekt sind...
            if(Array.isArray(ingoingEdges)){
              for(var ingoingEdge of ingoingEdges){
                if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdge[c_nodeId]){
                  return processObject;
                }   
              }
            // nur eine eingehende Kante
            }else{
              if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdges[c_nodeId]){
                return processObject;
              }    
            }
          })
          // lege auf den Stack
          if(reachedEndGateWay != true){
          currentObjectStack.push(nextObject);
          }
        }

        reachedEndGateWay = false;

    }
  
    }catch(e){
      console.error(methodName, e);
    }
  
  }


function analyzeWritersAndReaders(bp){
    let methodName = ">>> [analyzeWritersAndReaders]: ";   
    
    try{

        var userTasks = bp[c_definitions][c_process][c_userTasks];

        var participantWrite = {};
        var participantRead = {};

        var senders = [];

        for(var currentTask of userTasks){

          var currentDocumentation = JSON.parse(currentTask[c_documentation][c_nodeId]);

          if(currentDocumentation.outgoingData.length > 0){

            var result = createBPObjectsArray(currentTask,bp);

            var sender = result.startObject;
            var bpObjectsArrays = result.array; 
            var receivers = getReceiversForSharing(sender,bpObjectsArrays, bp);

            senders.push({task: currentTask, receivers: receivers});

          }

        }

        // for every participant
        for(var participant of allParticipants){
            // check every task
            var participantName = participant.name;

            for(var task of userTasks){
                // its a task of the current participant
                if(task[c_assignee] == participantName){
                    var currentDocumentation = JSON.parse(task[c_documentation][c_nodeId]);

                    var incomingData = currentDocumentation.incomingData.map(e => findOccurenceInString(e.name, "[", "]"));
                    var outgoingData = currentDocumentation.outgoingData.map(e => findOccurenceInString(e.name, "[", "]"));

                    if(participantWrite[participantName] == undefined){
                        participantWrite[participantName] = [];
                    }
                    if(participantRead[participantName] == undefined){
                        participantRead[participantName] = [];
                    }

                    if(outgoingData.length > 0){
                      var spheresToAdd = [];
                      for(var sphere of currentDocumentation.spheres){
                        if(isInArray(outgoingData, findOccurenceInString(sphere.dataObject, "[", "]"))){
                          spheresToAdd.push(sphere);
                        }
                      }
                      participantWrite[participantName].push({taskName: task.name, sphere: spheresToAdd});
                    }
                    participantRead[participantName] = Array.from(new Set(participantRead[participantName].concat(incomingData)));
                }
            }
        }

        for(var participant in participantWrite){
          //startTraversing(startTask, undefined, bp, c_shareKeys, true, undefined, undefined, participantWrite[participant]);
        }

        for(var sender of senders){
          startTraversing(startTask, undefined, bp, c_shareKeys, true, undefined, undefined, sender);
        }
        

    }catch(e){
      console.error(methodName, e);
    }

}

function startTraversing(task,dataObject,bp,traverseOption,start, pathDecisions, branchToAnalyze, currentParticipant){
let methodName = ">>> [startTraversing]: "; 

  try{

    var result = createBPObjectsArray(task, bp);
    var bpStartObject = result.startObject;
    var bpObjectsArrays = result.array; 

    var bpStartEvent = { type: c_start, decisions: [], bpObject: task, incomingDataObject: [], outgoingDataObject: [], initiatingDataObject: [] };

    if(traverseOption == c_pathDecisionTraversing){
      // returns all paths from the current start Object
      return pathDecisionTraversing(bpStartObject, bpObjectsArrays, bp);
    }else if(traverseOption == c_generatePaths){
      return generatePaths(bpStartObject, dataObject, pathDecisions, bpObjectsArrays, bp);
    }else if(traverseOption == c_forward){
      // returns all objects which were passed till the end event was found
      if(start == true){
        return forwardTraversing(bpStartEvent,bpObjectsArrays, bp);
      }else{
        return forwardTraversing(bpStartObject,bpObjectsArrays, bp);
      }
    }else if(traverseOption == c_branchAnalyze){
      return localBranchTraversing(bpStartObject, bpObjectsArrays, bp, branchToAnalyze);
    }else if(traverseOption == c_shareKeys){
      if(start == true){
        return shareKeyTraversing(bpStartEvent, bpObjectsArrays, bp, currentParticipant);
      }else{
        return shareKeyTraversing(bpStartObject, bpObjectsArrays, bp, currentParticipant);
      }
    }

  }catch(e){
    console.error(methodName, e);
  }

}

function createBPObjectsArray(startTask, bp){
  let methodName = ">>> [createBPObjectsArray]: "; 

  try{

    var businessProcess = bp[c_definitions][c_process];
    var processKeys = [c_tasks,c_serviceTasks,c_userTasks,c_parallel,c_exclusive];
    var bpObjectsArrays = [];
    var bpStartObject;

      processKeys.forEach( key => {
        if(businessProcess[key] != undefined){
          businessProcess[key].forEach( bpObject => {
            if(bpObject.id == startTask.id){
              bpStartObject = { type: key, decisions: [], bpObject: bpObject, incomingDataObject: [], outgoingDataObject: [], initiatingDataObject: [] };
            }
            bpObjectsArrays.push({ type: key, decisions: [], bpObject: bpObject, incomingDataObject: [], outgoingDataObject: [], initiatingDataObject: [] });
          });
        }
      });

      bpObjectsArrays.push({ type: c_end, decisions: [], bpObject: bp[c_definitions][c_process][c_end], incomingDataObject: [], outgoingDataObject: [], initiatingDataObject: [] });

      return {array: bpObjectsArrays, startObject: bpStartObject};

  }catch(e){
    console.error(methodName, e);
  }

}

function otherSendingTasksExists(startObject, receivingTask, dataObject, bpObjectsArray, bp){
  let methodName = ">>> [otherSendingTasksExists]: "; 

  try{
    
      var sendingTasks = [];

      var incomingEdges;
      var outgoingEdges;
      var nextObject;
      var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow]; 
      var currentObjectStack = [];
      var gateWaysStack = [];
      var reachedEndGateWay = false;

      var passedReceivingTask = false;

      var globalDecisions = [];

      // init stack
      currentObjectStack.push(startObject);
  
      while(currentObjectStack.length > 0){

        incomingEdges = [];
        outgoingEdges = [];
  
        // hole Objekt aus dem Stack
        var currentObject = currentObjectStack.pop();

        if(currentObject.type == c_end){
          return sendingTasks;
        }

        // wenn der receiving Task auf dem Weg erreicht wurde, return da der nächste sendende Task nicht relevant ist
        if(currentObject.type == c_userTasks && receivingTask != undefined && currentObject.bpObject.id == receivingTask.bpObject.id){
          return sendingTasks;
        }

        // wenn es sich um einen Task handelt der ebenfalls auf dasselbe Datenobjekt schreibt
        if(currentObject.type == c_userTasks && currentObject.bpObject.name != startObject.bpObject.name){
          var currentTaskDocumentation = JSON.parse(currentObject.bpObject[c_documentation][c_nodeId]);
          if(currentTaskDocumentation.outgoingData != undefined){
            if(isInArray(currentTaskDocumentation.outgoingData.map(e => e.name), dataObject)){
              sendingTasks.push(currentObject.bpObject.name);
            }
          }
        }

        // set the current decision variables in this current path
        if(currentObject.decisions.length > 0){
          globalDecisions = globalDecisions.concat(currentObject.decisions);
        }

        // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
        if(currentObject.type == c_parallel || currentObject.type == c_exclusive){

          if(Array.isArray(currentObject.bpObject[c_in])){
            for(var edge of currentObject.bpObject[c_in]){
              incomingEdges.push(edge[c_nodeId]);
            }
          }else{
            incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
          }
          if(Array.isArray(currentObject.bpObject[c_out])){
            for(var edge of currentObject.bpObject[c_out]){
              outgoingEdges.push(edge[c_nodeId]);
            }
          }else{
            outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
          }

          if(outgoingEdges.length > incomingEdges.length){
              for(var edge in outgoingEdges){
                gateWaysStack.push(currentObject.bpObject.name);
              }
          }

          if(outgoingEdges.length < incomingEdges.length){
            gateWaysStack.pop();
            if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
              reachedEndGateWay = true;   
            }
            // reached the end Gateway -> remove Decision Variable because the Decision does not matter for the candidateObject
            globalDecisions = globalDecisions.filter( gateway => gateway.name != currentObject.bpObject.name);
          }

        }

        // hole ausgehende Kante/n vom aktuellen BPObjekt 
        var outcomingEdge = currentObject.bpObject[c_out];

        // wenn es Kanten sind...
        if(Array.isArray(outcomingEdge)){
            for(var key in outcomingEdge){
              var edge = outcomingEdge[key][c_nodeId];

              // get edge description for outgoing edge from decision gateway
              if(currentObject.type == c_exclusive){
                var edgeDescription = sequenceFlows.find( e => e.id == edge);
              }

              nextObject = bpObjectsArray.find( processObject => {
                var ingoingEdges = processObject.bpObject[c_in];
                // wenn es mehrere eingehende Kanten vom Objekt sind...
                if(Array.isArray(ingoingEdges)){
                  for(var ingoingEdge of ingoingEdges){
                    if(edge != undefined && edge == ingoingEdge[c_nodeId]){
                      return processObject;
                    }   
                  }
                // nur eine ausgehende Kante
                }else{
                  if(edge != undefined && edge == ingoingEdges[c_nodeId]){
                    return processObject;
                  }    
                }
              });

              if(currentObject.type == c_exclusive && nextObject.bpObject.id == edgeDescription.targetRef){
                nextObject.decisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});
              }

              // lege auf den Stack
              if(reachedEndGateWay != true){
                currentObjectStack.push(nextObject);
              }
            }
            // ..ansonsten nur für eine Kante
        }else{
          nextObject = bpObjectsArray.find( processObject => {
            var ingoingEdges = processObject.bpObject[c_in];
            // wenn es mehrere ausgehende Kanten vom Objekt sind...
            if(Array.isArray(ingoingEdges)){
              for(var ingoingEdge of ingoingEdges){
                if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdge[c_nodeId]){
                  return processObject;
                }   
              }
            // nur eine ausgehende Kante
            }else{
              if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdges[c_nodeId]){
                return processObject;
              }    
            }
          })
          // lege auf den Stack
          if(reachedEndGateWay != true){
          currentObjectStack.push(nextObject);
          }
        }

        reachedEndGateWay = false;

    }

  }catch(e){
    console.error(e);
  }

}

function isKeyExchangePossible(startObject, chosenObject, receivingTask ,sendingTasks, currentDecision, dataObject, bpObjectsArray, bp){
  let methodName = ">>> [isKeyExchangePossible]: ";

  try{

    var incomingEdges;
    var outgoingEdges;
    var nextObject;
    var currentObjectStack = [];
    var gateWaysStack = [];
    var reachedEndGateWay = false;
    var globalDecisions = [];

    var traverseDirection;
    var traverseKeyOutgoing;
    var traverseKeyIncoming;
    var exchangePossible;
    var isReceivingObject;

    var decision = currentDecision;

    var currentObject;
    var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow]; 
    var chosenDecisionsEdges = [];

    var chosenEdgeLoop = null;

    traverseDirection = c_forward;

    var startDocumentation = JSON.parse(startObject.bpObject[c_documentation][c_nodeId]);

    // if startDocu has already a decision
    if(startDocumentation.decision.length > 0){
      globalDecisions = startDocumentation.decision.slice();
    }

    // init stack
    currentObjectStack.push(startObject);

    // isReceiving Object? // if yes => observe decisions as well
    var receivingTaskDocumentation = JSON.parse(receivingTask.bpObject[c_documentation][c_nodeId]);

    if(isInArray(receivingTaskDocumentation.outgoingData.map( e => e.name), dataObject)){
      isReceivingObject = false;
    }

    if(isInArray(receivingTaskDocumentation.incomingData.map( e => e.name), dataObject)){
      isReceivingObject = true;
    }

    //console.log(methodName, "RECEIVING?" , receivingTask.bpObject.name, isReceivingObject);

    while(currentObjectStack.length > 0){

      incomingEdges = [];
      outgoingEdges = [];

      // hole Objekt aus dem Stack
      currentObject = currentObjectStack.pop();

      if(traverseDirection == c_forward){
        //console.log(methodName, "FORWARD" ,currentObject.bpObject.name);
      }else{
        //console.log(methodName, "BACKWARD" ,currentObject.bpObject.name);
      }

      // wenn nach vorne traversiert wird -> ist vom aktuellen objekt ein anderer sender nachfolgend
      if(traverseDirection == c_forward){
        var sendingTasks = otherSendingTasksExists(currentObject, receivingTask, dataObject, bpObjectsArray ,bp);

        // falls das end event erreicht wird, return false
        if(currentObject.type == c_end){
          return false;
        }
      }

      if(currentObject.bpObject.id == startObject.bpObject.id && traverseDirection == c_backward){
        if(isReceivingObject){
          // receiver ist in keinem branch
          if(JSON.stringify(receivingTaskDocumentation.decision) == JSON.stringify(startDocumentation.decision)){
            // keine sender dazwischen
            if(sendingTasks.length == 0){
              //console.log("Object in keinem branch und keine sender vor mir");
              return true;
            // sender dazwischen
            }else{
              //console.log("Object in keinem branch und sender vor mir vorhanden!");
              return false;
            }
          }else{
            // receiver ist in einem branch
            // befindet sich im branch und kann key exchangen
            if(containsDecision(globalDecisions, receivingTaskDocumentation.decision)){
              // keine sender dazwischen
              if(sendingTasks.length == 0){
                //console.log("Object ist in einem branch und keine sender vor mir");
                return true;
              // sender dazwischen
              }else{
                //console.log("Object ist in einem branch und sender vor mir vorhanden");
                return false;
              }
            }else{
              // befindet sich außerhalb vom branch
              //console.log("Object ist in keinem branch");
              return false;
            }
          }
        }else{
          // wenn kein receiving object .. do nothing
          //console.log("Object ist kein receiver!");
        }
        //console.log(methodName, "Finished checking for possible Exchange before :", chosenObject.bpObject.name);
        return
      }
      
      // if traversingObject is the chosenObject -> switch traversing direction
      if(currentObject.bpObject.id == chosenObject.bpObject.id){
        traverseDirection = c_backward;
        currentObjectStack = [];
        gateWaysStack = [];
      }

      // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
      if(currentObject.type == c_parallel || currentObject.type == c_exclusive){

        if(Array.isArray(currentObject.bpObject[c_in])){
          for(var edge of currentObject.bpObject[c_in]){
            incomingEdges.push(edge[c_nodeId]);
          }
        }else{
          incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
        }
        if(Array.isArray(currentObject.bpObject[c_out])){
          for(var edge of currentObject.bpObject[c_out]){
            outgoingEdges.push(edge[c_nodeId]);
          }
        }else{
          outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
        }

        if(traverseDirection == c_forward){

          if(currentObject.bpObject.name.includes("Loop")){

            // Loop-Gateway entscheidung -> immer nein da nicht geloopt wird
            if(outgoingEdges.length > incomingEdges.length){
              for(var edge of outgoingEdges){

                if(chosenEdgeLoop != undefined){
                  continue;
                }

                chosenEdgeLoop = sequenceFlows.find(e => {
                  if(e.id == edge){
                    if(e.name == "no"){
                      return e;
                    }
                  }
                });
              }
            }
            
          }else{

            if(outgoingEdges.length > incomingEdges.length && currentObject.type == c_parallel){
              for(var edge in outgoingEdges){
                gateWaysStack.push(currentObject.bpObject.name);
              }
            }

            if(outgoingEdges.length < incomingEdges.length && currentObject.type == c_parallel){
                gateWaysStack.pop();
              if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
                reachedEndGateWay = true;   
              }
            }

          }
          
        }else{

          if(outgoingEdges.length < incomingEdges.length && currentObject.type == c_parallel){
            for(var edge in incomingEdges){
              gateWaysStack.push(currentObject.bpObject.name);
            }
          }

          if(outgoingEdges.length > incomingEdges.length && currentObject.type == c_parallel){
              gateWaysStack.pop();
            if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
              reachedEndGateWay = true;   
            }
          }

        }
      }

      if(traverseDirection == c_forward){
        traverseKeyOutgoing = c_out;
        traverseKeyIncoming = c_in;
      }else{
        traverseKeyOutgoing = c_in;
        traverseKeyIncoming = c_out
      }

      var outcomingEdge = {};

      if(chosenEdgeLoop != null){

        outcomingEdge[c_nodeId] = chosenEdgeLoop.id;
        chosenEdgeLoop = null;

      }else{

        // hole ausgehende Kante/n vom aktuellen BPObjekt 
        outcomingEdge = currentObject.bpObject[traverseKeyOutgoing];

      }

      // ausgehende Kanten vom aktuellen Objekt existieren
      if(outcomingEdge != undefined){

        if(!Array.isArray(outcomingEdge)){
          outcomingEdge = [outcomingEdge];
        }

        var foundPathDecision = false;

        // überprüfe jede ausgehende Kante
        for(var e in outcomingEdge){

          var edge = outcomingEdge[e][c_nodeId];
          var chosenEdge = null;


          // wenn das gateway ein loop gateway ist -> sonderbehandlung
          if(currentObject.bpObject.name.includes("Loop")){

            // Hinteres Gateway beim Loop
            if(outgoingEdges.length > incomingEdges.length && traverseDirection == c_forward){
              
              // nimm die ermittelte Standard Kante um nicht in die Loop zu gehen
              chosenEdge = edge;

            }else if(outgoingEdges.length < incomingEdges.length && traverseDirection == c_backward){
              // falls rückwärts auf ein XOR getroffen wird, muss die Kante ausgewählt werden die der aktuellen PathDecision entspricht
              if(chosenDecisionsEdges.find(e => e == edge) != undefined){
                chosenEdge = edge;
                removeElement(chosenDecisionsEdges, edge);
              }

            }else{
              // falls es sich um Tasks, parallel Gateways handelt nimm die aktuelle Kante und fahre fort
              chosenEdge = edge;
            }

          }else{

            // falls das aktuelle Objekt ein exklusives Gateway ist
            if(currentObject.type == c_exclusive && outgoingEdges.length > incomingEdges.length && traverseDirection == c_forward){
              // finde die Beschreibung der aktuellen Kante
              var edgeDescription = sequenceFlows.find( e => e.id == edge);

              // ist die aktuelle Kanten-Beschreibung in der Decision des Paths enthalten?
              foundPathDecision = decision.find( e => e.name == currentObject.bpObject.name && e.value == edgeDescription.name);

              // falls diese enthalten ist, wähle diese Kante um das nächste Objekt zu finden
              if(foundPathDecision != undefined){
                chosenEdge = edge;
              }
            }else if(currentObject.type == c_exclusive && outgoingEdges.length < incomingEdges.length && traverseDirection == c_backward){
              // falls rückwärts auf ein XOR getroffen wird, muss die Kante ausgewählt werden die der aktuellen PathDecision entspricht

              if(chosenDecisionsEdges.find(e => e == edge) != undefined){
                chosenEdge = edge;
                removeElement(chosenDecisionsEdges, edge);
              }

            }else{
              // falls es sich um Tasks, parallel Gateways handelt nimm die aktuelle Kante und fahre fort
              chosenEdge = edge;
            }

          }

          // wenn die aktuelle Kante ein Kandidat ist
          if(chosenEdge != null){

            nextObject = bpObjectsArray.find( processObject => {
              var ingoingEdges = processObject.bpObject[traverseKeyIncoming];
              // wenn es mehrere eingehende Kanten zum Objekt sind...
              if(Array.isArray(ingoingEdges)){
                for(var ingoingEdge of ingoingEdges){
                  if(chosenEdge == ingoingEdge[c_nodeId]){
                    return processObject;
                  }   
                }
              // nur eine eingehende Kante
              }else{
                if(chosenEdge == ingoingEdges[c_nodeId]){
                  return processObject;
                }    
              }
            });

            if(nextObject.type == c_exclusive && traverseDirection == c_forward && !currentObject.bpObject.name.includes("Loop")){

              var incomingEdgesNextObject = [];
              var outgoingEdgesNextObject = [];

              if(Array.isArray(nextObject.bpObject[traverseKeyIncoming])){
                for(var edge of nextObject.bpObject[traverseKeyIncoming]){
                  incomingEdgesNextObject.push(edge[c_nodeId]);
                }
              }else{
                incomingEdgesNextObject.push(nextObject.bpObject[traverseKeyIncoming][c_nodeId]);
              }

              if(Array.isArray(nextObject.bpObject[traverseKeyOutgoing])){
                for(var edge of nextObject.bpObject[traverseKeyOutgoing]){
                  outgoingEdgesNextObject.push(edge[c_nodeId]);
                }
              }else{
                outgoingEdgesNextObject.push(nextObject.bpObject[traverseKeyOutgoing][c_nodeId]);
              }

              if(incomingEdgesNextObject.length > outgoingEdgesNextObject.length){
                chosenDecisionsEdges.push(chosenEdge);
              }
            }

            if(currentObject.type == c_exclusive && traverseDirection == c_forward && !currentObject.bpObject.name.includes("Loop")){
              if(outgoingEdges.length > incomingEdges.length){
                globalDecisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});
              }

              if(outgoingEdges.length < incomingEdges.length && traverseDirection == c_forward){
                //reached the end Gateway -> remove Decision Variable because the Decision does not matter for the next Objects
                globalDecisions = globalDecisions.filter( gateway => gateway.name != currentObject.bpObject.name);
              }
            }
                      
            if(reachedEndGateWay != true){
              currentObjectStack.push(nextObject);
            }

          }
        }

        reachedEndGateWay = false;
      }
    }
    
  }catch(e){
    console.error(e);
  }
}

function containsDecision(globalDecisions, receiverDecisions){
  let methodName = ">>> [containsDecision]: ";

  try{

    // if array length is smaller than receiverDecisions length -> does not contain all decisions
    var checkForMissingDecision = [];

    for(var receiverDecision of receiverDecisions){

      var found = globalDecisions.find( e => e.name == receiverDecision.name && e.value == receiverDecision.value);

      if(found != undefined){
        checkForMissingDecision.push(found);
      }

    }

    if(receiverDecisions.length == checkForMissingDecision.length){
      return true
    }else{
      return false;
    }

  }catch(e){
    console.error(e);
  }

}

function  lateSendTraversing(startObject, dataObject, decisions, bpObjectsArray, bp){
  let methodName = ">>> [lateSendTraversing]: ";

  try{

    var incomingEdges;
    var outgoingEdges;
    var nextObject;
    var currentObjectStack = [];
    var gateWaysStack = [];
    var reachedEndGateWay = false;
    var globalDecisions = [];

    var currentPath = []; 

    var checkedReceivingTask = [];

    var traverseDirection;
    var traverseKeyOutgoing;
    var traverseKeyIncoming;
    var receivingTask;

    var currentObject;
    var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow]; 
    var chosenDecisionsEdges = [];
    var alternativeDistributors = [];

    var augmentedPath = {};

    augmentedPath.decision = decisions;
    augmentedPath.dataObject = dataObject;
    augmentedPath.receivers = [];
    augmentedPath.augmentedPaths = {};

    var chosenEdgeLoop = null;

    traverseDirection = c_forward;

    console.log(methodName, "START:", startObject.bpObject.name);
    var startDocumentation = JSON.parse(startObject.bpObject[c_documentation][c_nodeId]);

    var sendingTasks = otherSendingTasksExists(startObject, undefined, dataObject, bpObjectsArray ,bp);

    // init stack

    currentObjectStack.push(startObject);

    while(currentObjectStack.length > 0){

      incomingEdges = [];
      outgoingEdges = [];

      // hole Objekt aus dem Stack
      currentObject = currentObjectStack.pop();

      var receivingTaskDecision = [];

      if(currentObject.bpObject.id == startObject.bpObject.id && traverseDirection == c_backward){
        checkedReceivingTask.push(receivingTask.bpObject.name);
        traverseDirection = c_forward;
        currentPath = [];
      }

      if(traverseDirection == c_forward){
        currentPath.push({name: currentObject.bpObject.name, id: currentObject.bpObject.id ,taskObject: currentObject.bpObject, includedExchangeTask: []});
      }

      if(currentObject.type == c_userTasks){
        var documentation = JSON.parse(currentObject.bpObject[c_documentation][c_nodeId]);

        // if the task has the data as incoming and the participant of the task is the candidate
        if((isInArray(documentation.incomingData.map(e => e.name), dataObject)) && checkedReceivingTask.find(e => e == currentObject.bpObject.name) == undefined && startObject.bpObject.id != currentObject.bpObject.id){
          receivingTask = currentObject;  
          receivingTaskDecision = documentation.decision;
          // add receiver to path description
          augmentedPath.receivers.push(receivingTask.bpObject.id);
          augmentedPath.augmentedPaths[receivingTask.bpObject.id] = [];
          traverseDirection = c_backward;
          currentObjectStack = [];
          gateWaysStack = [];
        }else{

          if(isInArray(documentation.outgoingData.map(e => e.name), dataObject) && currentObject.bpObject.id != startObject.bpObject.id && traverseDirection == c_forward){
            // if there is a task which also writes to data, abort.
              allAugmentedPaths.push(augmentedPath);
              return;
          }

        }

      }

      if(traverseDirection == c_backward){
        var mergedDecision = mergeDecisions(startDocumentation.decision,decisions);
        //console.log("STARTDEC:",startDocumentation.decision,"CURR:",  decisions);
        //console.log("MERGED", mergedDecision);
        var reached = hasReceivedKey(currentObject.bpObject, decisions, receivingTaskDecision, startObject.bpObject[c_assignee], dataObject, bp);
        var isPossible = isKeyExchangePossible(startObject, currentObject, receivingTask , sendingTasks, decisions , dataObject, bpObjectsArray, bp);
        //console.log(methodName, "AT POSITION '"+ currentObject.bpObject.name + "' REACHABLE: ", reached);
        //console.log(methodName, "AT POSITION '" + currentObject.bpObject.name + "' EXCHANGE POSSIBLE: ", isPossible);
        if(isPossible && (startObject.bpObject[c_assignee] != receivingTask.bpObject[c_assignee])){

          //console.log(currentObject.bpObject.name, decisions);

          // find alternative distributors
          if(receivingTaskDecision.length > 0){            
            alternativeDistributors = findAlternativeDistributor(startObject, receivingTask, dataObject, bpObjectsArray, bp);
          }
          
          var possibleExchangePath = {position: currentObject.bpObject.id, receiver: receivingTask.bpObject.id, distributors: alternativeDistributors, path: []};
          possibleExchangePath.path = currentPath.slice();
          var currentObjectIndex = possibleExchangePath.path.map(e => e.id).indexOf(currentObject.bpObject.id);         
          possibleExchangePath.path.splice(currentObjectIndex, 0, {name: "Exchange for [" + findOccurenceInString(dataObject, "[", "]") + "] by {" + startObject.bpObject[c_assignee] + "}", id: 0 ,taskObject: [], includedExchangeTask: []});
          augmentedPath.sendingTask = startObject.bpObject.name;         
          augmentedPath.decision = decisions;
          augmentedPath.augmentedPaths[receivingTask.bpObject.id].push(possibleExchangePath);

          // wenn der exchange Task direkt nach dem Sende Task kommt -> mergen und als neuen Path hinzufügen
          if(possibleExchangePath.path[0].name == startObject.bpObject.name && possibleExchangePath.path[1].taskObject.length == 0){
            var possibleMergedExchangePath = {position: currentObject.bpObject.id, receiver: receivingTask.bpObject.id, distributors: alternativeDistributors, path: []};
            // copy the current path
            possibleMergedExchangePath.path = currentPath.slice();
            possibleMergedExchangePath.mergedKeyExchange = [possibleExchangePath.path[0].name];
            augmentedPath.sendingTask = startObject.bpObject.name;
            augmentedPath.decision = decisions;
            augmentedPath.augmentedPaths[receivingTask.bpObject.id].push(possibleMergedExchangePath);
          }

        }
      }

      //console.log(currentObject.bpObject.name, augmentedPath);

      // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
      if(currentObject.type == c_parallel || currentObject.type == c_exclusive){

        if(Array.isArray(currentObject.bpObject[c_in])){
          for(var edge of currentObject.bpObject[c_in]){
            incomingEdges.push(edge[c_nodeId]);
          }
        }else{
          incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
        }
        if(Array.isArray(currentObject.bpObject[c_out])){
          for(var edge of currentObject.bpObject[c_out]){
            outgoingEdges.push(edge[c_nodeId]);
          }
        }else{
          outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
        }


        if(traverseDirection == c_forward){

          if(currentObject.bpObject.name.includes("Loop")){

            // Loop-Gateway entscheidung -> immer nein da nicht geloopt wird
            if(outgoingEdges.length > incomingEdges.length){
              for(var edge of outgoingEdges){

                if(chosenEdgeLoop != undefined){
                  continue;
                }

                chosenEdgeLoop = sequenceFlows.find(e => {
                  if(e.id == edge){
                    if(e.name == "no"){
                      return e;
                    }
                  }
                });
              }
            }
            
          }else{

            if(outgoingEdges.length > incomingEdges.length && currentObject.type == c_parallel){
              for(var edge in outgoingEdges){
                gateWaysStack.push(currentObject.bpObject.name);
              }
            }

            if(outgoingEdges.length < incomingEdges.length && currentObject.type == c_parallel){
                gateWaysStack.pop();
              if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
                reachedEndGateWay = true;   
              }
            }

          }
          
        }else{

          if(outgoingEdges.length < incomingEdges.length && currentObject.type == c_parallel){
            for(var edge in incomingEdges){
              gateWaysStack.push(currentObject.bpObject.name);
            }
          }

          if(outgoingEdges.length > incomingEdges.length && currentObject.type == c_parallel){
              gateWaysStack.pop();
            if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
              reachedEndGateWay = true;   
            }
          }

        }
      }

      if(traverseDirection == c_forward){
        traverseKeyOutgoing = c_out;
        traverseKeyIncoming = c_in;
      }else{
        traverseKeyOutgoing = c_in;
        traverseKeyIncoming = c_out
      }

      var outcomingEdge = {};

      if(chosenEdgeLoop != null){

        outcomingEdge[c_nodeId] = chosenEdgeLoop.id;
        chosenEdgeLoop = null;

      }else{

        // hole ausgehende Kante/n vom aktuellen BPObjekt 
        outcomingEdge = currentObject.bpObject[traverseKeyOutgoing];

      }

      // ausgehende Kanten vom aktuellen Objekt existieren
      if(outcomingEdge != undefined){

        if(!Array.isArray(outcomingEdge)){
          outcomingEdge = [outcomingEdge];
        }

        var foundPathDecision = false;

        // überprüfe jede ausgehende Kante
        for(var e in outcomingEdge){

          var edge = outcomingEdge[e][c_nodeId];
          var chosenEdge = null;

          // wenn das gateway ein loop gateway ist -> sonderbehandlung
          if(currentObject.bpObject.name.includes("Loop")){

            // Hinteres Gateway beim Loop
            if(outgoingEdges.length > incomingEdges.length && traverseDirection == c_forward){
              
              // nimm die ermittelte Standard Kante um nicht in die Loop zu gehen
              chosenEdge = edge;

            }else if(outgoingEdges.length < incomingEdges.length && traverseDirection == c_backward){
              // falls rückwärts auf ein XOR getroffen wird, muss die Kante ausgewählt werden die der aktuellen PathDecision entspricht
              if(chosenDecisionsEdges.find(e => e == edge) != undefined){
                chosenEdge = edge;
                removeElement(chosenDecisionsEdges, edge);
              }

            }else{
              // falls es sich um Tasks, parallel Gateways handelt nimm die aktuelle Kante und fahre fort
              chosenEdge = edge;
            }

          }else{

            // falls das aktuelle Objekt ein exklusives Gateway ist
            if(currentObject.type == c_exclusive && outgoingEdges.length > incomingEdges.length && traverseDirection == c_forward){
              // finde die Beschreibung der aktuellen Kante
              var edgeDescription = sequenceFlows.find( e => e.id == edge);

              // ist die aktuelle Kanten-Beschreibung in der Decision des Paths enthalten?
              foundPathDecision = decisions.find( e => e.name == currentObject.bpObject.name && e.value == edgeDescription.name);

              // falls diese enthalten ist, wähle diese Kante um das nächste Objekt zu finden
              if(foundPathDecision != undefined){
                chosenEdge = edge;
              }
            }else if(currentObject.type == c_exclusive && outgoingEdges.length < incomingEdges.length && traverseDirection == c_backward){
              // falls rückwärts auf ein XOR getroffen wird, muss die Kante ausgewählt werden die der aktuellen PathDecision entspricht

              if(chosenDecisionsEdges.find(e => e == edge) != undefined){
                chosenEdge = edge;
                removeElement(chosenDecisionsEdges, edge);
              }

            }else{
              // falls es sich um Tasks, parallel Gateways handelt nimm die aktuelle Kante und fahre fort
              chosenEdge = edge;
            }

          }

          // wenn die aktuelle Kante ein Kandidat ist
          if(chosenEdge != null){

            nextObject = bpObjectsArray.find( processObject => {
              var ingoingEdges = processObject.bpObject[traverseKeyIncoming];
              // wenn es mehrere eingehende Kanten zum Objekt sind...
              if(Array.isArray(ingoingEdges)){
                for(var ingoingEdge of ingoingEdges){
                  if(chosenEdge == ingoingEdge[c_nodeId]){
                    return processObject;
                  }   
                }
              // nur eine eingehende Kante
              }else{
                if(chosenEdge == ingoingEdges[c_nodeId]){
                  return processObject;
                }    
              }
            });

            if(nextObject.type == c_exclusive && traverseDirection == c_forward && !currentObject.bpObject.name.includes("Loop")){

              var incomingEdgesNextObject = [];
              var outgoingEdgesNextObject = [];

              if(Array.isArray(nextObject.bpObject[traverseKeyIncoming])){
                for(var edge of nextObject.bpObject[traverseKeyIncoming]){
                  incomingEdgesNextObject.push(edge[c_nodeId]);
                }
              }else{
                incomingEdgesNextObject.push(nextObject.bpObject[traverseKeyIncoming][c_nodeId]);
              }

              if(Array.isArray(nextObject.bpObject[traverseKeyOutgoing])){
                for(var edge of nextObject.bpObject[traverseKeyOutgoing]){
                  outgoingEdgesNextObject.push(edge[c_nodeId]);
                }
              }else{
                outgoingEdgesNextObject.push(nextObject.bpObject[traverseKeyOutgoing][c_nodeId]);
              }

              if(incomingEdgesNextObject.length > outgoingEdgesNextObject.length){
                chosenDecisionsEdges.push(chosenEdge);
              }
            }

            if(currentObject.type == c_exclusive && traverseDirection == c_forward && !currentObject.bpObject.name.includes("Loop")){
              if(outgoingEdges.length > incomingEdges.length){
                globalDecisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});
              }

              if(outgoingEdges.length < incomingEdges.length && traverseDirection == c_forward){
                //reached the end Gateway -> remove Decision Variable because the Decision does not matter for the next Objects
                globalDecisions = globalDecisions.filter( gateway => gateway.name != currentObject.bpObject.name);
              }
            }
                      
            if(reachedEndGateWay != true){
              currentObjectStack.push(nextObject);
            }

          }
        }

        reachedEndGateWay = false;
      }
    }

    allAugmentedPaths.push(augmentedPath);

  }catch(e){
    console.error(methodName, e);
  }

}

function findAlternativeDistributor(startObject, receivingTask, dataObject, bpObjectsArray, bp){
  let methodName = ">>> [findAlternativeDistributor]: ";

  try{

    //(1) get all participants in the local branch
    
    var localBranchParticipants = [];
    var enteredLocalBranch = false;

    var incomingEdges;
    var outgoingEdges;
    var nextObject;
    var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow]; 
    var currentObjectStack = [];
    var gateWaysStack = [];
    var reachedEndGateWay = false;
    var currentObject;

    var chosenEdgeLoop = null;

    var globalDecisions = [];

    var receiverDocumentation = JSON.parse(receivingTask.bpObject[c_documentation][c_nodeId]);

    // hole den branch namen des letzten decision eintrags des receivers, da dies die tiefste verschachtelung ist
    var analyzingBranch = receiverDocumentation.decision[receiverDocumentation.decision.length-1].name;

    // init stack
    currentObjectStack.push(startObject);

    while(currentObjectStack.length > 0){

      incomingEdges = [];
      outgoingEdges = [];

      // hole Objekt aus dem Stack
      currentObject = currentObjectStack.pop();
      // Wenn kein BPObjekt mehr vorhanden ist welches traversiert werden kann (also End Event wurde erreicht)
      if(currentObject == undefined){
        // Wenn noch Objekte im Stack liegen
        if(currentObjectStack.length > 0){
          // hole Objekt aus dem Stack
          currentObject = currentObjectStack.pop();
        }else{
          break;
        }
      }

      if(currentObject.bpObject.name == analyzingBranch){
        enteredLocalBranch = true;
      }

      if(enteredLocalBranch && currentObject.bpObject.name != analyzingBranch && currentObject.type != c_serviceTasks && currentObject.bpObject[c_assignee] != undefined){
        if(localBranchParticipants.find(e => e.name == currentObject.bpObject[c_assignee]) == undefined){
          localBranchParticipants.push({name: currentObject.bpObject[c_assignee]});
        }
      }

      // set the current decision variables in this current path
      if(currentObject.decisions.length > 0){
        globalDecisions = globalDecisions.concat(currentObject.decisions);
      }

      // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
      if(currentObject.type == c_parallel || currentObject.type == c_exclusive){

        if(Array.isArray(currentObject.bpObject[c_in])){
          for(var edge of currentObject.bpObject[c_in]){
            incomingEdges.push(edge[c_nodeId]);
          }
        }else{
          incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
        }
        if(Array.isArray(currentObject.bpObject[c_out])){
          for(var edge of currentObject.bpObject[c_out]){
            outgoingEdges.push(edge[c_nodeId]);
          }
        }else{
          outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
        }

        // Wenn das Gateway einem Loop angehört -> Prüfe ob eingehendes oder ausgehendes
        if(currentObject.bpObject.name.includes("Loop")){

          // Loop-Gateway entscheidung -> immer nein da nicht geloopt wird
          if(outgoingEdges.length > incomingEdges.length){
            for(var edge of outgoingEdges){

              if(chosenEdgeLoop != undefined){
                continue;
              }

              chosenEdgeLoop = sequenceFlows.find(e => {
                if(e.id == edge){
                  if(e.name == "no"){
                    return e;
                  }
                }
              });
            }
          }

        }else{

          if(outgoingEdges.length > incomingEdges.length){
              for(var edge in outgoingEdges){
                gateWaysStack.push(currentObject.bpObject.name);
              }
          }

          if(outgoingEdges.length < incomingEdges.length){
            gateWaysStack.pop();
            if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
              reachedEndGateWay = true;   
            }else{
              enteredLocalBranch = false;
            }
            // reached the end Gateway -> remove Decision Variable because the Decision does not matter for the candidateObject
            globalDecisions = globalDecisions.filter( gateway => gateway.name != currentObject.bpObject.name);
          }

        }

      }

      var outcomingEdge = {};

      if(chosenEdgeLoop != null){

        outcomingEdge[c_nodeId] = chosenEdgeLoop.id;
        chosenEdgeLoop = null;

      }else{

        // hole ausgehende Kante/n vom aktuellen BPObjekt 
        outcomingEdge = currentObject.bpObject[c_out];

      }

      // wenn es Kanten sind...
      if(Array.isArray(outcomingEdge)){
          for(var key in outcomingEdge){
            var edge = outcomingEdge[key][c_nodeId];

            // get edge description for outgoing edge from decision gateway
            if(currentObject.type == c_exclusive){
              var edgeDescription = sequenceFlows.find( e => e.id == edge);
            }

            nextObject = bpObjectsArray.find( processObject => {
              var ingoingEdges = processObject.bpObject[c_in];
              // wenn es mehrere eingehende Kanten vom Objekt sind...
              if(Array.isArray(ingoingEdges)){
                for(var ingoingEdge of ingoingEdges){
                  if(edge != undefined && edge == ingoingEdge[c_nodeId]){
                    return processObject;
                  }   
                }
              // nur eine ausgehende Kante
              }else{
                if(edge != undefined && edge == ingoingEdges[c_nodeId]){
                  return processObject;
                }    
              }
            });

            if(currentObject.type == c_exclusive && nextObject.bpObject.id == edgeDescription.targetRef){
              nextObject.decisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});
            }

            // lege auf den Stack
            if(reachedEndGateWay != true){
              currentObjectStack.push(nextObject);
            }
          }
          // ..ansonsten nur für eine Kante
      }else{
        nextObject = bpObjectsArray.find( processObject => {
          var ingoingEdges = processObject.bpObject[c_in];
          // wenn es mehrere ausgehende Kanten vom Objekt sind...
          if(Array.isArray(ingoingEdges)){
            for(var ingoingEdge of ingoingEdges){
              if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdge[c_nodeId]){
                return processObject;
              }   
            }
          // nur eine ausgehende Kante
          }else{
            if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdges[c_nodeId]){
              return processObject;
            }    
          }
        })
        // lege auf den Stack
        if(reachedEndGateWay != true){
        currentObjectStack.push(nextObject);
        }
      }

      reachedEndGateWay = false;

  }

  // (2) if from sender to receiver are one or more participants, who receiver data as well
  // and are in the local branch as well, add them as potential distributors

  var currentObjectStack = [];
  var gateWaysStack = [];
  var reachedEndGateWay = false;
  var globalDecisions = [];

  var alternativeDistributors = [];

  currentObjectStack.push(startObject);

  while(currentObjectStack.length > 0){

    incomingEdges = [];
    outgoingEdges = [];

    // hole Objekt aus dem Stack
    currentObject = currentObjectStack.pop();

    // if the branch is reached, return alternative distributors
    if(currentObject.bpObject.name == analyzingBranch){
        return alternativeDistributors;
    }

    // if current object is not start or end task and receives data as well and is a local Branch participant
    if(currentObject.bpObject.id != startObject.bpObject.id && currentObject.bpObject.id != receivingTask.bpObject.id && currentObject.type == c_userTasks){
      
      var currentObjectDocumentation = JSON.parse(currentObject.bpObject[c_documentation][c_nodeId]);

      if(isInArray(currentObjectDocumentation.incomingData.map(e => e.name), dataObject) && localBranchParticipants.find(e => e.name == currentObject.bpObject[c_assignee]) != undefined){
        alternativeDistributors.push({distributor: currentObject.bpObject[c_assignee], decision: currentObjectDocumentation.decision});
      }
    }

    // set the current decision variables in this current path
    if(currentObject.decisions.length > 0){
      globalDecisions = globalDecisions.concat(currentObject.decisions);
    }

    // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
    if(currentObject.type == c_parallel || currentObject.type == c_exclusive){

      if(Array.isArray(currentObject.bpObject[c_in])){
        for(var edge of currentObject.bpObject[c_in]){
          incomingEdges.push(edge[c_nodeId]);
        }
      }else{
        incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
      }
      if(Array.isArray(currentObject.bpObject[c_out])){
        for(var edge of currentObject.bpObject[c_out]){
          outgoingEdges.push(edge[c_nodeId]);
        }
      }else{
        outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
      }

      // Wenn das Gateway einem Loop angehört -> Prüfe ob eingehendes oder ausgehendes
      if(currentObject.bpObject.name.includes("Loop")){

        // Loop-Gateway entscheidung -> immer nein da nicht geloopt wird
        if(outgoingEdges.length > incomingEdges.length){
          for(var edge of outgoingEdges){

            if(chosenEdgeLoop != undefined){
              continue;
            }

            chosenEdgeLoop = sequenceFlows.find(e => {
              if(e.id == edge){
                if(e.name == "no"){
                  return e;
                }
              }
            });
          }
        }

      }else{

        if(outgoingEdges.length > incomingEdges.length){
            for(var edge in outgoingEdges){
              gateWaysStack.push(currentObject.bpObject.name);
            }
        }

        if(outgoingEdges.length < incomingEdges.length){
          gateWaysStack.pop();
          if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
            reachedEndGateWay = true;   
          }
          // reached the end Gateway -> remove Decision Variable because the Decision does not matter for the candidateObject
          globalDecisions = globalDecisions.filter( gateway => gateway.name != currentObject.bpObject.name);
        }

      }

    }

    var outcomingEdge = {};

    if(chosenEdgeLoop != null){

      outcomingEdge[c_nodeId] = chosenEdgeLoop.id;
      chosenEdgeLoop = null;

    }else{

      // hole ausgehende Kante/n vom aktuellen BPObjekt 
      outcomingEdge = currentObject.bpObject[c_out];

    }

    // wenn es Kanten sind...
    if(Array.isArray(outcomingEdge)){
        for(var key in outcomingEdge){
          var edge = outcomingEdge[key][c_nodeId];

          // get edge description for outgoing edge from decision gateway
          if(currentObject.type == c_exclusive){
            var edgeDescription = sequenceFlows.find( e => e.id == edge);
          }

          nextObject = bpObjectsArray.find( processObject => {
            var ingoingEdges = processObject.bpObject[c_in];
            // wenn es mehrere eingehende Kanten vom Objekt sind...
            if(Array.isArray(ingoingEdges)){
              for(var ingoingEdge of ingoingEdges){
                if(edge != undefined && edge == ingoingEdge[c_nodeId]){
                  return processObject;
                }   
              }
            // nur eine ausgehende Kante
            }else{
              if(edge != undefined && edge == ingoingEdges[c_nodeId]){
                return processObject;
              }    
            }
          });

          if(currentObject.type == c_exclusive && nextObject.bpObject.id == edgeDescription.targetRef){
            nextObject.decisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});
          }

          // lege auf den Stack
          if(reachedEndGateWay != true){
            currentObjectStack.push(nextObject);
          }
        }
        // ..ansonsten nur für eine Kante
    }else{
      nextObject = bpObjectsArray.find( processObject => {
        var ingoingEdges = processObject.bpObject[c_in];
        // wenn es mehrere ausgehende Kanten vom Objekt sind...
        if(Array.isArray(ingoingEdges)){
          for(var ingoingEdge of ingoingEdges){
            if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdge[c_nodeId]){
              return processObject;
            }   
          }
        // nur eine ausgehende Kante
        }else{
          if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdges[c_nodeId]){
            return processObject;
          }    
        }
      })
      // lege auf den Stack
      if(reachedEndGateWay != true){
      currentObjectStack.push(nextObject);
      }
    }

    reachedEndGateWay = false;

  }

  }catch(e){
    console.error(methodName, e);
  }

}

function keyReceiveCheckTraversing(startObject,chosenObject, dataObject, participant, decisions, _receivingTaskDecisions ,bpObjectsArray, bp){
  let methodName = ">>> [keyReceiveCheckTraversing]: ";

  try{

    var incomingEdges;
    var outgoingEdges;
    var nextObject;
    var currentObjectStack = [];
    var gateWaysStack = [];
    var reachedEndGateWay = false;
    var globalDecisions = [];
    var receivedKey = false;

    var currentObject;
    var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow]; 

    var chosenObjectDecision = _receivingTaskDecisions;

    // init stack
    currentObjectStack.push(startObject);

    //console.log("REC.TASK:", chosenObject.bpObject.name);

    while(currentObjectStack.length > 0){

      incomingEdges = [];
      outgoingEdges = [];

      // hole Objekt aus dem Stack
      currentObject = currentObjectStack.pop();

      if(currentObject.type == c_userTasks){
        var documentation = JSON.parse(currentObject.bpObject[c_documentation][c_nodeId]);
        // if the task has the data as incoming and the participant of the task is the candidate

        if(chosenObjectDecision.length == 0 || JSON.stringify(chosenObjectDecision) == JSON.stringify(globalDecisions)){
          receivedKey = true;
        }

        if((isInArray(documentation.incomingData.map(e => e.name), dataObject) || isInArray(documentation.outgoingData.map(e => e.name), dataObject))  && (findOccurenceInString(currentObject.bpObject.name, "[", "]") == participant)){
          //receivedKey = true;
        }
      }

      if(currentObject.bpObject.id == chosenObject.bpObject.id){
        return receivedKey;
      }

      // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
      if(currentObject.type == c_parallel || currentObject.type == c_exclusive){

        if(Array.isArray(currentObject.bpObject[c_in])){
          for(var edge of currentObject.bpObject[c_in]){
            incomingEdges.push(edge[c_nodeId]);
          }
        }else{
          incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
        }
        if(Array.isArray(currentObject.bpObject[c_out])){
          for(var edge of currentObject.bpObject[c_out]){
            outgoingEdges.push(edge[c_nodeId]);
          }
        }else{
          outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
        }

        if(outgoingEdges.length > incomingEdges.length && currentObject.type == c_parallel){
            for(var edge in outgoingEdges){
              gateWaysStack.push(currentObject.bpObject.name);
            }
        }

        if(outgoingEdges.length < incomingEdges.length && currentObject.type == c_parallel){
            gateWaysStack.pop();
          if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
            reachedEndGateWay = true;   
          }
        }
      }

      var outcomingEdge = currentObject.bpObject[c_out];

      // ausgehende Kanten vom aktuellen Objekt existieren
      if(outcomingEdge != undefined){

        if(!Array.isArray(outcomingEdge)){
          outcomingEdge = [outcomingEdge];
        }

        var foundPathDecision = false;

        // überprüfe jede ausgehende Kante
        for(var e in outcomingEdge){

          var edge = outcomingEdge[e][c_nodeId];
          var chosenEdge = null;

          // falls das aktuelle Objekt ein exklusives Gateway ist
          if(currentObject.type == c_exclusive && outgoingEdges.length > incomingEdges.length){
            // finde die Beschreibung der aktuellen Kante
            var edgeDescription = sequenceFlows.find( e => e.id == edge);

            // ist die aktuelle Kanten-Beschreibung in der Decision des Paths enthalten?
            foundPathDecision = decisions.find( e => e.name == currentObject.bpObject.name && e.value == edgeDescription.name);

            // falls diese enthalten ist, wähle diese Kante um das nächste Objekt zu finden
            if(foundPathDecision != undefined){
              chosenEdge = edge;
            }

          }else{
            // falls es sich um Tasks, parallel Gateways handelt nimm die aktuelle Kante und fahre fort
            chosenEdge = edge;
          }

          // wenn die aktuelle Kante ein Kandidat ist
          if(chosenEdge != null){

            nextObject = bpObjectsArray.find( processObject => {
              var ingoingEdges = processObject.bpObject[c_in];
              // wenn es mehrere eingehende Kanten zum Objekt sind...
              if(Array.isArray(ingoingEdges)){
                for(var ingoingEdge of ingoingEdges){
                  if(edge == ingoingEdge[c_nodeId]){
                    return processObject;
                  }   
                }
              // nur eine eingehende Kante
              }else{
                if(edge == ingoingEdges[c_nodeId]){
                  return processObject;
                }    
              }
            });

            if(currentObject.type == c_exclusive ){
              if(outgoingEdges.length > incomingEdges.length){
                globalDecisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});
              }

              if(outgoingEdges.length < incomingEdges.length){
                //reached the end Gateway -> remove Decision Variable because the Decision does not matter for the next Objects
                globalDecisions = globalDecisions.filter( gateway => gateway.name != currentObject.bpObject.name);
              }
            }
                      
            if(reachedEndGateWay != true){
              currentObjectStack.push(nextObject);
            }

          }
        }

        reachedEndGateWay = false;
      }
  }

  }catch(e){
    console.error(methodName, e);
  }

}

function createPathsWithDecisions(currentObject, decisions ,bpObjectsArray, bp){
  let methodName = ">>> [keyReceiveCheckTraversing]: ";

  try{

    var incomingEdges;
    var outgoingEdges;
    var nextObject;
    var currentObjectStack = [];
    var gateWaysStack = [];
    var reachedEndGateWay = false;
    var globalDecisions = [];

    var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow]; 

    var path = [];

    // init stack
    currentObjectStack.push(currentObject);

    while(currentObjectStack.length > 0){

      incomingEdges = [];
      outgoingEdges = [];

      // hole Objekt aus dem Stack
      currentObject = currentObjectStack.pop();

      if(currentObject.type == c_end){
        return path;
      }

      if(currentObject.type == c_userTasks || currentObject.type == c_serviceTasks){
        path.push(currentObject);
      }

      // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
      if(currentObject.type == c_parallel || currentObject.type == c_exclusive){

        if(Array.isArray(currentObject.bpObject[c_in])){
          for(var edge of currentObject.bpObject[c_in]){
            incomingEdges.push(edge[c_nodeId]);
          }
        }else{
          incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
        }
        if(Array.isArray(currentObject.bpObject[c_out])){
          for(var edge of currentObject.bpObject[c_out]){
            outgoingEdges.push(edge[c_nodeId]);
          }
        }else{
          outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
        }

        if(outgoingEdges.length > incomingEdges.length && currentObject.type == c_parallel){
            for(var edge in outgoingEdges){
              gateWaysStack.push(currentObject.bpObject.name);
            }
        }

        if(outgoingEdges.length < incomingEdges.length && currentObject.type == c_parallel){
            gateWaysStack.pop();
          if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
            reachedEndGateWay = true;   
          }
        }
      }

      var outcomingEdge = currentObject.bpObject[c_out];


      // ausgehende Kanten vom aktuellen Objekt existieren
      if(outcomingEdge != undefined){

        if(!Array.isArray(outcomingEdge)){
          outcomingEdge = [outcomingEdge];
        }

        var foundPathDecision = false;

        // überprüfe jede ausgehende Kante
        for(var e in outcomingEdge){

          var edge = outcomingEdge[e][c_nodeId];
          var chosenEdge = null;

          // falls das aktuelle Objekt ein exklusives Gateway ist
          if(currentObject.type == c_exclusive && outgoingEdges.length > incomingEdges.length){
            // finde die Beschreibung der aktuellen Kante
            var edgeDescription = sequenceFlows.find( e => e.id == edge);

            // ist die aktuelle Kanten-Beschreibung in der Decision des Paths enthalten?
            foundPathDecision = decisions.find( e => e.name == currentObject.bpObject.name && e.value == edgeDescription.name);

            // falls diese enthalten ist, wähle diese Kante um das nächste Objekt zu finden
            if(foundPathDecision != undefined){
              chosenEdge = edge;
            }

          }else{
            // falls es sich um Tasks, parallel Gateways handelt nimm die aktuelle Kante und fahre fort
            chosenEdge = edge;
          }

          // wenn die aktuelle Kante ein Kandidat ist
          if(chosenEdge != null){

            nextObject = bpObjectsArray.find( processObject => {
              var ingoingEdges = processObject.bpObject[c_in];
              // wenn es mehrere eingehende Kanten zum Objekt sind...
              if(Array.isArray(ingoingEdges)){
                for(var ingoingEdge of ingoingEdges){
                  if(edge == ingoingEdge[c_nodeId]){
                    return processObject;
                  }   
                }
              // nur eine eingehende Kante
              }else{
                if(edge == ingoingEdges[c_nodeId]){
                  return processObject;
                }    
              }
            });

            if(currentObject.type == c_exclusive ){
              if(outgoingEdges.length > incomingEdges.length){
                globalDecisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});
              }

              if(outgoingEdges.length < incomingEdges.length){
                //reached the end Gateway -> remove Decision Variable because the Decision does not matter for the next Objects
                globalDecisions = globalDecisions.filter( gateway => gateway.name != currentObject.bpObject.name);
              }
            }
                      
            if(reachedEndGateWay != true){
              currentObjectStack.push(nextObject);
            }

          }
        }

        reachedEndGateWay = false;
      }
  }

  }catch(e){
    console.error(methodName, e);
  }

}

function forwardTraversing(currentObject,bpObjectsArray, bp){
  let methodName = ">>> [forwardTraversing]: "; 
  
    try{
  
      var passedObjectsForShifting = [];

      var incomingEdges;
      var outgoingEdges;
      var nextObject;
      var dataObjects = bp[c_definitions][c_process][c_dataRef];
      var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow]; 
      var currentObjectStack = [];
      var gateWaysStack = [];
      var reachedEndGateWay = false;

      var globalDecisions = [];
      var chosenEdgeLoop = null;


      // init stack
      currentObjectStack.push(currentObject);
  
      while(currentObjectStack.length > 0){

        incomingEdges = [];
        outgoingEdges = [];

        // hole Objekt aus dem Stack
        var currentObject = currentObjectStack.pop();

        // Wenn kein BPObjekt mehr vorhanden ist welches traversiert werden kann (also End Event wurde erreicht)
        if(currentObject == undefined){
          // Wenn noch Objekte im Stack liegen
          if(currentObjectStack.length > 0){
            // hole Objekt aus dem Stack
            currentObject = currentObjectStack.pop();
          }else{
            return passedObjectsForShifting;
          }
        }

        // set the current decision variables in this current path
        if(currentObject.decisions.length > 0){
          globalDecisions = globalDecisions.concat(currentObject.decisions);
        }

        if(currentObject.type == c_userTasks){
          if(currentObject.bpObject[c_documentation][c_nodeId] != undefined){
            var candidateDocumentation = JSON.parse(currentObject.bpObject[c_documentation][c_nodeId]);

            // if the userTask is not a voting Task
            if(candidateDocumentation.type != undefined){
              if(candidateDocumentation.decision.length == 0){
                candidateDocumentation.decision = globalDecisions;

                  for(var userTask of bp[c_definitions][c_process][c_userTasks]){    
                    if(currentObject.bpObject.id == userTask.id){
                      userTask[c_documentation][c_nodeId] = JSON.stringify(candidateDocumentation);
                    }
                  }  
              }
            }
          }
        }

        // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
        if(currentObject.type == c_parallel || currentObject.type == c_exclusive){

            if(Array.isArray(currentObject.bpObject[c_in])){
              for(var edge of currentObject.bpObject[c_in]){
                incomingEdges.push(edge[c_nodeId]);
              }
            }else{
              incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
            }
            if(Array.isArray(currentObject.bpObject[c_out])){
              for(var edge of currentObject.bpObject[c_out]){
                outgoingEdges.push(edge[c_nodeId]);
              }
            }else{
              outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
            }

            // Wenn das Gateway einem Loop angehört -> Prüfe ob eingehendes oder ausgehendes
            if(currentObject.bpObject.name.includes("Loop")){

              // Loop-Gateway entscheidung -> immer nein da nicht geloopt wird
              if(outgoingEdges.length > incomingEdges.length){
                for(var edge of outgoingEdges){

                  if(chosenEdgeLoop != undefined){
                    continue;
                  }

                  chosenEdgeLoop = sequenceFlows.find(e => {
                    if(e.id == edge){
                      if(e.name == "no"){
                        return e;
                      }
                    }
                  });

                }
              }

              passedObjectsForShifting.push(currentObject);

            }else{

              if(outgoingEdges.length > incomingEdges.length){
                  for(var edge in outgoingEdges){
                    gateWaysStack.push(currentObject.bpObject.name);
                  }
                  passedObjectsForShifting.push(currentObject);
              }

              if(outgoingEdges.length < incomingEdges.length){
                gateWaysStack.pop();
                if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
                  reachedEndGateWay = true;   
                }else{
                  passedObjectsForShifting.push(currentObject);
                }
                // reached the end Gateway -> remove Decision Variable because the Decision does not matter for the candidateObject
                globalDecisions = globalDecisions.filter( gateway => gateway.name != currentObject.bpObject.name);
              }

            }

        }else{

          var dataObjects = bp[c_definitions][c_process][c_dataRef];
              if(!Array.isArray(dataObjects)){
                dataObjects = [dataObjects];
          }

          // Füge alle Elemente einmalig zum Array hinzu
          if(!passedObjectsForShifting.includes(currentObject)){

            if(currentObject.bpObject[c_inData] != null){

              var incomingData = currentObject.bpObject[c_inData];
              if(!Array.isArray(incomingData)){
                incomingData = [incomingData];
              }

              for(var inData of incomingData){
                var foundData = dataObjects.find( e => e.id == inData[c_source][c_nodeId])

                if(foundData != undefined){
                  currentObject.incomingDataObject.push({name: foundData.name});
                }
              }
            }

            if(currentObject.bpObject[c_outData] != null){

              var outgoingData = currentObject.bpObject[c_outData];
              if(!Array.isArray(outgoingData)){
                outgoingData = [outgoingData];
              }

              for(var outData of outgoingData){
                var foundData = dataObjects.find(e => e.id == outData[c_target][c_nodeId]);

                if(foundData != undefined){
                  currentObject.outgoingDataObject.push({name: foundData.name});
                }
              }
              
              if(!Array.isArray(dataObjects)){
                dataObjects = [dataObjects];
              }
              
              outgoingData.forEach( dataEdge => {
                var dataObject = dataObjects.find( result => result.id == dataEdge[c_target][c_nodeId]);

                 var foundPassedObject = passedObjectsForShifting.find( passedObject => {
                  if(passedObject.bpObject[c_outData] != undefined && passedObject.initiatingDataObject.length > 0){
                    var foundDataObject = passedObject.initiatingDataObject.find( initDataObject => {
                      if(initDataObject.id == dataObject.id){
                        return initDataObject;
                      }
                    });

                    if(foundDataObject != undefined){
                      return passedObject;
                    }
                  }
                });

                if(foundPassedObject == undefined){
                  currentObject.initiatingDataObject.push(dataObject);
                }

              });
            }
            passedObjectsForShifting.push(currentObject);
          }

        }

        var outcomingEdge = {};

        if(chosenEdgeLoop != null){

          outcomingEdge[c_nodeId] = chosenEdgeLoop.id;
          chosenEdgeLoop = null;

        }else{

          // hole ausgehende Kante/n vom aktuellen BPObjekt 
          outcomingEdge = currentObject.bpObject[c_out];

        }

        // wenn es Kanten sind...
        if(Array.isArray(outcomingEdge)){
            for(var key in outcomingEdge){
              var edge = outcomingEdge[key][c_nodeId];

              // get edge description for outgoing edge from decision gateway
              if(currentObject.type == c_exclusive){
                var edgeDescription = sequenceFlows.find( e => e.id == edge);
              }

              nextObject = bpObjectsArray.find( processObject => {
                var ingoingEdges = processObject.bpObject[c_in];
                // wenn es mehrere eingehende Kanten vom Objekt sind...
                if(Array.isArray(ingoingEdges)){
                  for(var ingoingEdge of ingoingEdges){
                    if(edge != undefined && edge == ingoingEdge[c_nodeId]){
                      return processObject;
                    }   
                  }
                // nur eine ausgehende Kante
                }else{
                  if(edge != undefined && edge == ingoingEdges[c_nodeId]){
                    return processObject;
                  }    
                }
              });

              if(currentObject.type == c_exclusive && nextObject.bpObject.id == edgeDescription.targetRef){
                nextObject.decisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});
              }

              // lege auf den Stack
              if(reachedEndGateWay != true){
                currentObjectStack.push(nextObject);
              }
            }
            // ..ansonsten nur für eine Kante
        }else{
          nextObject = bpObjectsArray.find( processObject => {
            var ingoingEdges = processObject.bpObject[c_in];
            // wenn es mehrere ausgehende Kanten vom Objekt sind...
            if(Array.isArray(ingoingEdges)){
              for(var ingoingEdge of ingoingEdges){
                if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdge[c_nodeId]){
                  return processObject;
                }   
              }
            // nur eine eingehende Kante
            }else{
              if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdges[c_nodeId]){
                return processObject;
              }    
            }
          })
          // lege auf den Stack
          if(reachedEndGateWay != true){
          currentObjectStack.push(nextObject);
          }
        }

        reachedEndGateWay = false;

    }
  
    }catch(e){
      console.error(methodName, e);
    }
  
  }

  function pathDecisionTraversing(startObject, bpObjectsArray, bp){
    let methodName = ">>> [pathDecisionTraversing]: "; 

    try{

      var incomingEdges;
      var outgoingEdges;
      var nextObject;
      var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow];
      var currentObjectStack = [];

      var decisionsForPaths = [];
      var gateWaysStack = [];
      var reachedEndGateWay = false;  

      var chosenEdgeLoop = null;

      if(startObject.bpObject[c_documentation] != undefined){

        var startObjectDocumentation = JSON.parse(startObject.bpObject[c_documentation][c_nodeId]);  
        
        for(var decision of startObjectDocumentation.decision){
          startObject.decisions.push(decision);
        }

      }

      currentObjectStack.push(startObject);

      console.log("START: ", startObject.bpObject.name);

      while(currentObjectStack.length > 0){

        var currentObject = currentObjectStack.pop();

        incomingEdges = [];
        outgoingEdges = [];

        if(currentObject.type == c_end){
          currentObject = currentObjectStack.pop();
          //console.log("POP: ", currentObject.bpObject.name);
          console.log("____________________________________")
        }

        if(currentObject == undefined){         
          return decisionsForPaths;
        }

        if(currentObject.type == c_parallel){

          if(Array.isArray(currentObject.bpObject[c_in])){
            for(var edge of currentObject.bpObject[c_in]){
              incomingEdges.push(edge[c_nodeId]);
            }
          }else{
            incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
          }
          if(Array.isArray(currentObject.bpObject[c_out])){
            for(var edge of currentObject.bpObject[c_out]){
              outgoingEdges.push(edge[c_nodeId]);
            }
          }else{
            outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
          }

          if(outgoingEdges.length > incomingEdges.length){
              for(var edge in outgoingEdges){
                gateWaysStack.push(currentObject.bpObject.name);
              }
          }

          if(outgoingEdges.length < incomingEdges.length){
            gateWaysStack.pop();
            if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
              reachedEndGateWay = true; 
            }
          }

        }

        if(currentObject.type == c_exclusive){

          if(Array.isArray(currentObject.bpObject[c_in])){
            for(var edge of currentObject.bpObject[c_in]){
              incomingEdges.push(edge[c_nodeId]);
            }
          }else{
            incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
          }
          if(Array.isArray(currentObject.bpObject[c_out])){
            for(var edge of currentObject.bpObject[c_out]){
              outgoingEdges.push(edge[c_nodeId]);
            }
          }else{
            outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
          }

          // Wenn das Gateway einem Loop angehört -> Prüfe ob eingehendes oder ausgehendes
          if(currentObject.bpObject.name.includes("Loop")){

            // Loop-Gateway entscheidung -> immer nein da nicht geloopt wird
            if(outgoingEdges.length > incomingEdges.length){
              for(var edge of outgoingEdges){

                if(chosenEdgeLoop != undefined){
                  continue;
                }
                
                chosenEdgeLoop = sequenceFlows.find(e => {
                  if(e.id == edge){
                    if(e.name == "no"){
                      return e;
                    }
                  }
                });
              }
            }
          }

        }

        var outcomingEdge = {};

        if(chosenEdgeLoop != null){

          outcomingEdge[c_nodeId] = chosenEdgeLoop.id;
          chosenEdgeLoop = null;

        }else{

          // hole ausgehende Kante/n vom aktuellen BPObjekt 
          outcomingEdge = currentObject.bpObject[c_out];

        }

        if(outcomingEdge != undefined){
        
          // wenn es Kanten sind...
          if(Array.isArray(outcomingEdge)){

              for(var key in outcomingEdge){
                var edge = outcomingEdge[key][c_nodeId];

                // get edge description for outgoing edge from decision gateway
                if(currentObject.type == c_exclusive){
                  var edgeDescription = sequenceFlows.find( e => e.id == edge);
                }

                nextObject = bpObjectsArray.find( processObject => {
                  var ingoingEdges = processObject.bpObject[c_in];
                  // wenn es mehrere eingehende Kanten vom Objekt sind...
                  if(Array.isArray(ingoingEdges)){
                    for(var ingoingEdge of ingoingEdges){
                      if(edge != undefined && edge == ingoingEdge[c_nodeId]){
                        return processObject;
                      }   
                    }
                  // nur eine eingehende Kante
                  }else{
                    if(edge != undefined && edge == ingoingEdges[c_nodeId]){
                      return processObject;
                    }    
                  }
                });

                nextObject.decisions = [];

                if(currentObject.type == c_exclusive && nextObject.bpObject.id == edgeDescription.targetRef){

                  //console.log("NEXT: ", nextObject.decisions);
                  //console.log("CURRENT: ", currentObject.decisions);
                  nextObject.decisions = nextObject.decisions.concat(currentObject.decisions);
                  nextObject.decisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});

                }

                if(currentObject.type == c_parallel){
                    
                  nextObject.decisions = currentObject.decisions;                
                  currentObject.decisions = [];

                }
  

                if(reachedEndGateWay != true){                  
                  currentObjectStack.push(nextObject);
                }
              }

              // ..ansonsten nur für eine Kante
          }else{
            nextObject = bpObjectsArray.find( processObject => {
              var ingoingEdges = processObject.bpObject[c_in];
              // wenn es mehrere ausgehende Kanten vom Objekt sind...
              if(Array.isArray(ingoingEdges)){
                for(var ingoingEdge of ingoingEdges){
                  if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdge[c_nodeId]){
                    return processObject;
                  }   
                }
              // nur eine ausgehende Kante
              }else{
                if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdges[c_nodeId]){
                  return processObject;
                }    
              }
            });

            nextObject.decisions = [];

            if(nextObject.type == c_end){

              var fullDecision = []; 

              if(startObject.type == c_userTasks){

                var startDocu = JSON.parse(startObject.bpObject[c_documentation][c_nodeId]);   
              
                for(var decision of startDocu.decision){
                  fullDecision.push(decision);
                }
              }

              //if(JSON.stringify(fullDecision) != JSON.stringify(currentObject.decisions)){
                fullDecision = fullDecision.concat(currentObject.decisions);
              //}
              
              decisionsForPaths.push(fullDecision);
              
            }

            nextObject.decisions = currentObject.decisions;           
            currentObject.decisions = [];

            if(reachedEndGateWay != true){
              currentObjectStack.push(nextObject);
            }
          }

          reachedEndGateWay = false;

        }

      }

    }catch(e){
      console.error(methodName, e);
    }

  }

  function generatePaths(startObject, dataObject, pathDecisions, bpObjectsArray, bp){
    let methodName = ">>> [generatePaths]: "; 

    try{

      var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow];
      var currentPathStack = [];
      var gateWaysStack = [];
      var currentObject;

      var globalDecisions = [];
      var currentDecision = [];

      var reachedMembers = [];
      var generatedKeyExchangeTasks = [];
      var chosenEdge = null;

      var reachedEndGateWay = false;

      var startObjectDocumentation = JSON.parse(startObject.bpObject[c_documentation][c_nodeId]);
      var currentSphere = startObjectDocumentation.spheres.find( e => e.dataObject == dataObject.name);

      for(var pathDecision of pathDecisions){

            var globalDecisions = [];
            var currentDecision = [];
            var costs = 0;
          
            currentPathStack.push(startObject);

            while(currentPathStack.length > 0){

              var incomingEdges = [];
              var outgoingEdges = [];
              var nextObject;

              currentObject = currentPathStack.pop();

              if(currentObject.bpObject[c_in] != undefined){
                if(Array.isArray(currentObject.bpObject[c_in])){
                  for(var edge of currentObject.bpObject[c_in]){
                    incomingEdges.push(edge[c_nodeId]);
                  }
                }else{
                  incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
                }
              }

              if(currentObject.bpObject[c_out] != undefined){
                if(Array.isArray(currentObject.bpObject[c_out])){
                  for(var edge of currentObject.bpObject[c_out]){
                    outgoingEdges.push(edge[c_nodeId]);
                  }
                }else{
                  outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
                }
              }
              
              if(currentObject.type == c_parallel){

                if(outgoingEdges.length > incomingEdges.length){
                    for(var edge in outgoingEdges){
                      gateWaysStack.push(currentObject.bpObject.name);
                    }
                }

                if(outgoingEdges.length < incomingEdges.length){
                  gateWaysStack.pop();
                  if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
                    reachedEndGateWay = true;   
                  }
                }
              }

              // set the current decision variables in this current path
              if(currentObject.type == c_userTasks){
                currentObject.decisions = globalDecisions;
              }

              var sendsData = false;  
              var receivesData = false;

              if(currentObject.type == c_userTasks){

                
                var candidateDocumentation = JSON.parse(currentObject.bpObject[c_documentation][c_nodeId]);
                currentDecision = mergeDecisions(currentDecision,candidateDocumentation.decision);

                if(currentObject.bpObject.name != startObject.bpObject.name){
                  receivesData = isInArray(candidateDocumentation.incomingData, dataObject);
                  sendsData = isInArray(candidateDocumentation.outgoingData, dataObject);
                } 
              }

              if(currentObject.type == c_serviceTasks){
                var exchangeTaskDocumentation = JSON.parse(currentObject.bpObject[c_documentation][c_nodeId]);
                var exchangeTaskParticipant = exchangeTaskDocumentation.participant;

                if(exchangeTaskParticipant == startObject.bpObject[c_assignee]){
                  // add alternative decisions which can be taken
                  
                  exchangeTaskDocumentation.decisions = mergeDecisions(exchangeTaskDocumentation.decisions, pathDecision);
                  for(var serviceTask of bp[c_definitions][c_process][c_serviceTasks]){    
                    if(currentObject.bpObject.id == serviceTask.id){
                      serviceTask[c_documentation][c_nodeId] = JSON.stringify(exchangeTaskDocumentation);
                    }
                  }

                  bpObjectsArray = createBPObjectsArray(startObject.bpObject,bp).array;

                }


              }

              if(currentObject.type == c_end){
                currentObject = undefined;
                currentPathStack = [];
              }

              if(sendsData){
                currentPathStack = [];    
              }

              if(receivesData && currentSphere.sphereType == c_weakDynamic){
                reachedMembers.push({name: currentObject.bpObject[c_assignee], decision: globalDecisions});
              }

              if(receivesData && currentSphere.sphereType == c_strongDynamic){

                var found = generatedKeyExchangeTasks.find( e => e.createdForTask == currentObject.bpObject.name);
                if(found == undefined){

                  var alternativeDistributor = undefined;
                  // If the receiving task is in a branch, try "alternative distributor" optimization
                  if(globalDecisions.length > 0){
                    var localBranchParticipants = startTraversing(startObject.bpObject, dataObject, bp, c_branchAnalyze, undefined, undefined, globalDecisions[globalDecisions.length-1].name, undefined);       
                    alternativeDistributor = occursInArray(reachedMembers,localBranchParticipants);
                  }

                  currentDecision = mergeDecisions(currentDecision, pathDecision);
                  createKeyExchangeTask(bp, dataObject, currentDecision, startObject, currentObject.bpObject, c_before, alternativeDistributor);
                  
                  if(globalDecisions.length > 0){
                    reachedMembers.push({name: currentObject.bpObject[c_assignee], decision: globalDecisions});
                  }else{
                    reachedMembers.push({name: currentObject.bpObject[c_assignee]});
                  }
                  generatedKeyExchangeTasks.push({createdForTask: currentObject.bpObject.name});

                  bpObjectsArray = createBPObjectsArray(startObject.bpObject,bp).array;
                }

              }
              
              if(currentObject != undefined && sendsData == false){

                var outcomingEdge = currentObject.bpObject[c_out];

                // ausgehende Kanten vom aktuellen Objekt existieren
                if(outcomingEdge != undefined){

                  if(!Array.isArray(outcomingEdge)){
                    outcomingEdge = [outcomingEdge];
                  }

                  var foundPathDecision = false;

                  // überprüfe jede ausgehende Kante
                  for(var e in outcomingEdge){

                    var edge = outcomingEdge[e][c_nodeId];
                    chosenEdge = null;

                    // falls das aktuelle Objekt ein exklusives Gateway ist
                    if(currentObject.type == c_exclusive && outgoingEdges.length > incomingEdges.length){
                      // finde die Beschreibung der aktuellen Kante
                      var edgeDescription = sequenceFlows.find( e => e.id == edge);

                    // ist die aktuelle Kanten-Beschreibung in der Decision des Paths enthalten?
                    foundPathDecision = pathDecision.find( e => e.name == currentObject.bpObject.name && e.value == edgeDescription.name);

                      // falls diese enthalten ist, wähle diese Kante um das nächste Objekt zu finden
                      if(foundPathDecision != undefined){
                        chosenEdge = edge;
                      }

                    }else{
                    // falls es sich um Tasks, parallel Gateways handelt nimm die aktuelle Kante und fahre fort
                      chosenEdge = edge;
                    }

                    // wenn die aktuelle Kante ein Kandidat ist
                    if(chosenEdge != null){

                      nextObject = bpObjectsArray.find( processObject => {
                        var ingoingEdges = processObject.bpObject[c_in];
                        // wenn es mehrere eingehende Kanten zum Objekt sind...
                        if(Array.isArray(ingoingEdges)){
                          for(var ingoingEdge of ingoingEdges){
                            if(edge == ingoingEdge[c_nodeId]){
                              return processObject;
                            }   
                          }
                        // nur eine eingehende Kante
                        }else{
                          if(edge == ingoingEdges[c_nodeId]){
                            return processObject;
                          }    
                        }
                      });

                      if(currentObject.type == c_exclusive ){
                        if(outgoingEdges.length > incomingEdges.length){
                          globalDecisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});
                        }

                        if(outgoingEdges.length < incomingEdges.length){
                            //reached the end Gateway -> remove Decision Variable because the Decision does not matter for the next Objects
                            globalDecisions = globalDecisions.filter( gateway => gateway.name != currentObject.bpObject.name);
                        }
                      }
                      
                      if(reachedEndGateWay != true){
                        currentPathStack.push(nextObject);
                      }

                    }
                  }

                  reachedEndGateWay = false;

                }

              }

            }
      }

      removeElement(startObjectDocumentation.spheres, currentSphere);
      currentSphere.members = reachedMembers;

      startObjectDocumentation.spheres.push(currentSphere);

      for(var userTask of bp[c_definitions][c_process][c_userTasks]){    
        if(startObject.bpObject.id == userTask.id){
          userTask[c_documentation][c_nodeId] = JSON.stringify(startObjectDocumentation);
        }
      }

    }catch(e){
      console.error(methodName, e);
    }

  }



  function localBranchTraversing(currentObject,bpObjectsArray, bp, analyzingBranch){
    let methodName = ">>> [localBranchTraversing]: "; 
    
      try{
    
        var localBranchParticipants = [];
        var enteredLocalBranch = false;
  
        var incomingEdges;
        var outgoingEdges;
        var nextObject;
        var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow]; 
        var currentObjectStack = [];
        var gateWaysStack = [];
        var reachedEndGateWay = false;
  
        var globalDecisions = [];
  
        // init stack
        currentObjectStack.push(currentObject);
    
        while(currentObjectStack.length > 0){
  
          incomingEdges = [];
          outgoingEdges = [];
    
          // hole Objekt aus dem Stack
          currentObject = currentObjectStack.pop();
          // Wenn kein BPObjekt mehr vorhanden ist welches traversiert werden kann (also End Event wurde erreicht)
          if(currentObject == undefined){
            // Wenn noch Objekte im Stack liegen
            if(currentObjectStack.length > 0){
              // hole Objekt aus dem Stack
              currentObject = currentObjectStack.pop();
            }else{
              return localBranchParticipants;
            }
          }

          if(currentObject.bpObject.name == analyzingBranch){
            enteredLocalBranch = true;
          }

          if(enteredLocalBranch && currentObject.bpObject.name != analyzingBranch && currentObject.type != c_serviceTasks){
            localBranchParticipants.push({name: currentObject.bpObject[c_assignee]});
          }
  
          // set the current decision variables in this current path
          if(currentObject.decisions.length > 0){
            globalDecisions = globalDecisions.concat(currentObject.decisions);
          }
  
          // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
          if(currentObject.type == c_parallel || currentObject.type == c_exclusive){
  
            if(Array.isArray(currentObject.bpObject[c_in])){
              for(var edge of currentObject.bpObject[c_in]){
                incomingEdges.push(edge[c_nodeId]);
              }
            }else{
              incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
            }
            if(Array.isArray(currentObject.bpObject[c_out])){
              for(var edge of currentObject.bpObject[c_out]){
                outgoingEdges.push(edge[c_nodeId]);
              }
            }else{
              outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
            }
  
            if(outgoingEdges.length > incomingEdges.length){
                for(var edge in outgoingEdges){
                  gateWaysStack.push(currentObject.bpObject.name);
                }
            }
  
            if(outgoingEdges.length < incomingEdges.length){
              gateWaysStack.pop();
              if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
                reachedEndGateWay = true;   
              }else{
                enteredLocalBranch = false;
              }
              // reached the end Gateway -> remove Decision Variable because the Decision does not matter for the candidateObject
              globalDecisions = globalDecisions.filter( gateway => gateway.name != currentObject.bpObject.name);
            }
  
          }
  
          // hole ausgehende Kante/n vom aktuellen BPObjekt 
          var outcomingEdge = currentObject.bpObject[c_out];
  
          // wenn es Kanten sind...
          if(Array.isArray(outcomingEdge)){
              for(var key in outcomingEdge){
                var edge = outcomingEdge[key][c_nodeId];
  
                // get edge description for outgoing edge from decision gateway
                if(currentObject.type == c_exclusive){
                  var edgeDescription = sequenceFlows.find( e => e.id == edge);
                }
  
                nextObject = bpObjectsArray.find( processObject => {
                  var ingoingEdges = processObject.bpObject[c_in];
                  // wenn es mehrere eingehende Kanten vom Objekt sind...
                  if(Array.isArray(ingoingEdges)){
                    for(var ingoingEdge of ingoingEdges){
                      if(edge != undefined && edge == ingoingEdge[c_nodeId]){
                        return processObject;
                      }   
                    }
                  // nur eine ausgehende Kante
                  }else{
                    if(edge != undefined && edge == ingoingEdges[c_nodeId]){
                      return processObject;
                    }    
                  }
                });
  
                if(currentObject.type == c_exclusive && nextObject.bpObject.id == edgeDescription.targetRef){
                  nextObject.decisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});
                }
  
                // lege auf den Stack
                if(reachedEndGateWay != true){
                  currentObjectStack.push(nextObject);
                }
              }
              // ..ansonsten nur für eine Kante
          }else{
            nextObject = bpObjectsArray.find( processObject => {
              var ingoingEdges = processObject.bpObject[c_in];
              // wenn es mehrere ausgehende Kanten vom Objekt sind...
              if(Array.isArray(ingoingEdges)){
                for(var ingoingEdge of ingoingEdges){
                  if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdge[c_nodeId]){
                    return processObject;
                  }   
                }
              // nur eine ausgehende Kante
              }else{
                if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdges[c_nodeId]){
                  return processObject;
                }    
              }
            })
            // lege auf den Stack
            if(reachedEndGateWay != true){
            currentObjectStack.push(nextObject);
            }
          }
  
          reachedEndGateWay = false;
  
      }
    
      }catch(e){
        console.error(methodName, e);
      }
    
    }


    function shareKeyTraversing(currentObject,bpObjectsArray, bp, sender){
      let methodName = ">>> [shareKeyTraversing]: "; 
      
        try{
    
          var incomingEdges;
          var outgoingEdges;
          var nextObject;
          var sequenceFlows = bp[c_definitions][c_process][c_sequenceFlow]; 
          var currentObjectStack = [];
          var gateWaysStack = [];
          var reachedEndGateWay = false;
    
          var globalDecisions = [];
    
          var currentShareKeyId;
          var chosenEdgeLoop = null;

          // init stack
          currentObjectStack.push(currentObject);
      
          while(currentObjectStack.length > 0){
    
            incomingEdges = [];
            outgoingEdges = [];
      
            // hole Objekt aus dem Stack
            var currentObject = currentObjectStack.pop();

            // Wenn kein BPObjekt mehr vorhanden ist welches traversiert werden kann (also End Event wurde erreicht)
            if(currentObject == undefined){
              // Wenn noch Objekte im Stack liegen
              if(currentObjectStack.length > 0){
                // hole Objekt aus dem Stack
                currentObject = currentObjectStack.pop();
              }else{
                return 0;
              }
            }

            if(sender.task.id == currentObject.bpObject.id){  

              var sendersReceivers = sender.receivers.otherReceivers;
              var senderStrongReceivers = sender.receivers.strongDynamicReceivers;
              var mappedStrongReceivers = senderStrongReceivers.map( e => e.receiver);
              var mappedDecision = senderStrongReceivers.map(e => e.decision);
              var createNewShareId = true;

              var senderDoc = JSON.parse(sender.task[c_documentation][c_nodeId]);
              var outgoingData = senderDoc.outgoingData.map(e => findOccurenceInString(e.name, "[", "]"));
              for(var receiver of currentReceivers){
                var mappedArrayReceiver = receiver.receivers;
                var mappedArrayWrittenData = receiver.writtenData;

                if(sendersReceivers.length > 0){       
                  if(containsArray(sendersReceivers, mappedArrayReceiver) && containsArray(mappedArrayWrittenData, outgoingData)){        
                    createNewShareId = false;
                    currentShareKeyId = receiver.shareKeyId;
                  }
                }

                if(senderStrongReceivers.length > 0){
                  if(containsArray(mappedStrongReceivers, mappedArrayReceiver) && containsArray(mappedArrayWrittenData, outgoingData)){              
                    createNewShareId = false;
                    currentShareKeyId = receiver.shareKeyId;                                     
                  }
                }

              }

              if(createNewShareId){

                if(senderStrongReceivers.length > 0){
                  currentReceivers.push({shareKeyId: shareKeyID, receivers: mappedStrongReceivers, decisions: mappedDecision , writtenData: outgoingData});
                }else{
                  currentReceivers.push({shareKeyId: shareKeyID, receivers: sendersReceivers, writtenData: outgoingData});
                }

                currentShareKeyId = shareKeyID;
                shareKeyID += 1;
              }

              for(var userTask of bp[c_definitions][c_process][c_userTasks]){

                if(currentObject.bpObject.id == userTask.id){
                  var currentDocumentation = JSON.parse(userTask[c_documentation][c_nodeId]);

                  if(currentDocumentation.optimize == undefined){
                    currentDocumentation.optimize = {};
                    if(currentDocumentation.optimize.shareKey == undefined){
                      currentDocumentation.optimize.shareKey = [];
                    }
                  }

                  var foundShareKeyReceivers = currentReceivers.find(e => e.shareKeyId == currentShareKeyId);
                  if(foundShareKeyReceivers != undefined){

                    var mappedSharedKeyReceiver;

                    if(senderStrongReceivers.length > 0){
                      mappedSharedKeyReceiver = {shareKeyId: foundShareKeyReceivers.shareKeyId, receivers: foundShareKeyReceivers.receivers, decision: senderStrongReceivers, writtenData: outgoingData};
                    }else{
                      mappedSharedKeyReceiver = {shareKeyId: foundShareKeyReceivers.shareKeyId, receivers: foundShareKeyReceivers.receivers, writtenData: outgoingData};             
                    }

                    currentDocumentation.optimize.shareKey.push(mappedSharedKeyReceiver);
                  }

                  userTask[c_documentation][c_nodeId] = JSON.stringify(currentDocumentation);
                }
              }

            }

            /* var foundParticipant = currentParticipant.find(e => e.taskName == currentObject.bpObject.name)
            var currentShareKeyId;

            if(foundParticipant != undefined){

              for(var sphere of foundParticipant.sphere){
                //console.log(currentObject.bpObject.name, sphere);
                var mappedArraySphereReachedMembers = sphere.members.map(e => e.name);
                //console.log(mappedArraySphereReachedMembers);
                var createNewShareId = true;
                //console.log(currentReceivers);
                for(var receiver of currentReceivers){
                  var mappedArrayReceiver = receiver.receivers.map(e => e.name);
                  if(containsArray(mappedArrayReceiver, mappedArraySphereReachedMembers)){          
                    createNewShareId = false;
                    currentShareKeyId = receiver.shareKeyId;
                  }
                }

                if(createNewShareId){
                  currentReceivers.push({shareKeyId: shareKeyID, receivers: sphere.members});
                  currentShareKeyId = shareKeyID;
                  shareKeyID += 1;
                }

                for(var userTask of bp[c_definitions][c_process][c_userTasks]){

                  if(currentObject.bpObject.id == userTask.id){
                    var currentDocumentation = JSON.parse(userTask[c_documentation][c_nodeId]);

                    if(currentDocumentation.optimize == undefined){
                      currentDocumentation.optimize = {};
                      if(currentDocumentation.optimize.shareKey == undefined){
                        currentDocumentation.optimize.shareKey = [];
                      }
                    }

                    var foundShareKeyReceivers = currentReceivers.find(e => e.shareKeyId == currentShareKeyId);
                    if(foundShareKeyReceivers != undefined){
                      var mappedSharedKeyReceiver = {shareKeyId: foundShareKeyReceivers.shareKeyId, receivers: foundShareKeyReceivers.receivers.map(e => e.name)};
                      currentDocumentation.optimize.shareKey.push(mappedSharedKeyReceiver);
                    }

                    userTask[c_documentation][c_nodeId] = JSON.stringify(currentDocumentation);
                  }
                }
              }         
            } */
    
            // set the current decision variables in this current path
            if(currentObject.decisions.length > 0){
              globalDecisions = globalDecisions.concat(currentObject.decisions);
            }
    
            // Überprüfe ob jeder Pfad eines Gateways besucht wurde und fahre anschließend fort
            if(currentObject.type == c_parallel || currentObject.type == c_exclusive){
    
              if(Array.isArray(currentObject.bpObject[c_in])){
                for(var edge of currentObject.bpObject[c_in]){
                  incomingEdges.push(edge[c_nodeId]);
                }
              }else{
                incomingEdges.push(currentObject.bpObject[c_in][c_nodeId]);
              }
              if(Array.isArray(currentObject.bpObject[c_out])){
                for(var edge of currentObject.bpObject[c_out]){
                  outgoingEdges.push(edge[c_nodeId]);
                }
              }else{
                outgoingEdges.push(currentObject.bpObject[c_out][c_nodeId]);
              }


                // Wenn das Gateway einem Loop angehört -> Prüfe ob eingehendes oder ausgehendes
              if(currentObject.bpObject.name.includes("Loop")){

                // Loop-Gateway entscheidung -> immer nein da nicht geloopt wird
                if(outgoingEdges.length > incomingEdges.length){
                  for(var edge of outgoingEdges){

                    if(chosenEdgeLoop != undefined){
                      continue;
                    }

                    chosenEdgeLoop = sequenceFlows.find(e => {
                      if(e.id == edge){
                        if(e.name == "no"){
                          return e;
                        }
                      }
                    });

                  }
                }

              }else{

                if(outgoingEdges.length > incomingEdges.length){
                    for(var edge in outgoingEdges){
                      gateWaysStack.push(currentObject.bpObject.name);
                    }
                }

                if(outgoingEdges.length < incomingEdges.length){
                  gateWaysStack.pop();
                  if(currentObject.bpObject.name == gateWaysStack[gateWaysStack.length - 1]){
                    reachedEndGateWay = true;   
                  }
                  // reached the end Gateway -> remove Decision Variable because the Decision does not matter for the candidateObject
                  globalDecisions = globalDecisions.filter( gateway => gateway.name != currentObject.bpObject.name);
                }

              }

            }

            var outcomingEdge = {};

            if(chosenEdgeLoop != null){

              outcomingEdge[c_nodeId] = chosenEdgeLoop.id;
              chosenEdgeLoop = null;

            }else{

              // hole ausgehende Kante/n vom aktuellen BPObjekt 
              outcomingEdge = currentObject.bpObject[c_out];

            }

            // wenn es Kanten sind...
            if(Array.isArray(outcomingEdge)){
                for(var key in outcomingEdge){
                  var edge = outcomingEdge[key][c_nodeId];
    
                  // get edge description for outgoing edge from decision gateway
                  if(currentObject.type == c_exclusive){
                    var edgeDescription = sequenceFlows.find( e => e.id == edge);

                  }
    
                  nextObject = bpObjectsArray.find( processObject => {
                    var ingoingEdges = processObject.bpObject[c_in];
                    // wenn es mehrere eingehende Kanten vom Objekt sind...
                    if(Array.isArray(ingoingEdges)){
                      for(var ingoingEdge of ingoingEdges){
                        if(edge != undefined && edge == ingoingEdge[c_nodeId]){
                          return processObject;
                        }   
                      }
                    // nur eine ausgehende Kante
                    }else{
                      if(edge != undefined && edge == ingoingEdges[c_nodeId]){
                        return processObject;
                      }    
                    }
                  });
    
                  if(currentObject.type == c_exclusive && nextObject.bpObject.id == edgeDescription.targetRef){
                    nextObject.decisions.push({name: currentObject.bpObject.name, value: edgeDescription.name});
                  }
    
                  // lege auf den Stack
                  if(reachedEndGateWay != true){
                    currentObjectStack.push(nextObject);
                  }
                }
                // ..ansonsten nur für eine Kante
            }else{
              nextObject = bpObjectsArray.find( processObject => {
                var ingoingEdges = processObject.bpObject[c_in];
                // wenn es mehrere ausgehende Kanten vom Objekt sind...
                if(Array.isArray(ingoingEdges)){
                  for(var ingoingEdge of ingoingEdges){
                    if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdge[c_nodeId]){
                      return processObject;
                    }   
                  }
                // nur eine ausgehende Kante
                }else{
                  if(outcomingEdge != undefined && outcomingEdge[c_nodeId] == ingoingEdges[c_nodeId]){
                    return processObject;
                  }    
                }
              })
              // lege auf den Stack
              if(reachedEndGateWay != true){
              currentObjectStack.push(nextObject);
              }
            }
    
            reachedEndGateWay = false;
    
        }
      
        }catch(e){
          console.error(methodName, e);
        }
      
      }


  function createKeyExchangeTask(bp, dataInSphere, decisions, sendingTask, task, position, alternativeDistributor){
  let methodName = ">>> [createKeyExchangeTask]: ";   
  
    try{
  
      var traversedProcess;
      var onlyTaskArray = bp[c_definitions][c_process][c_tasks];
      var onlyUserTaskArray = bp[c_definitions][c_process][c_userTasks];

      if(!Array.isArray(onlyTaskArray)){
        onlyTaskArray = [onlyTaskArray];
      }
      if(!Array.isArray(onlyUserTaskArray)){
        onlyUserTaskArray = [onlyUserTaskArray];
      }

      var taskArray = onlyTaskArray.concat(onlyUserTaskArray);

      if(bp[c_definitions][c_process][c_serviceTasks] != undefined){
        var onlyServiceTaskArray = bp[c_definitions][c_process][c_serviceTasks];

        if(!Array.isArray(onlyServiceTaskArray)){
          onlyServiceTaskArray = [onlyServiceTaskArray];
        }

        taskArray = taskArray.concat(onlyServiceTaskArray);
      }

      var shapeArray = bp[c_definitions][c_diagram][c_diagramPlane][c_shape]; 
      var edgeArray = bp[c_definitions][c_diagram][c_diagramPlane][c_edge]; 
      var sequenceFlowArray = bp[c_definitions][c_process][c_sequenceFlow];
      var shape = shapeArray.find( result => task.id == result.bpmnElement);

      var taskId = createID(bp,c_tasks);
      var edgeId = createID(bp,c_sequenceFlow);
 
      var taskName = c_KeyExchange + c_KeyExchangeCounter; 
      c_KeyExchangeCounter++;

      var incEdge;
      var outEdge;
      if(position == c_before){
        incEdge = task[c_in][c_nodeId];
        outEdge = edgeId;
      }else{
        incEdge = edgeId;
        outEdge = task[c_out][c_nodeId];
      }
      
      var documentation = { 
        "type": c_serviceTasks,
        "participant": sendingTask.bpObject[c_assignee],
        "decisions": [],
        "receiver": {dataObject: dataInSphere.name, assignee: task[c_assignee]}
      }

      documentation.decisions = decisions;

      var exchangeTaskDistributor = undefined;

      if(alternativeDistributor != undefined){
        exchangeTaskDistributor = alternativeDistributor;
      }else{
        exchangeTaskDistributor = documentation.participant;
      }

      var newPseudoTask = {
        id: taskId,
        name: taskName + " [" + exchangeTaskDistributor + "] \n" + "(" + dataInSphere.name + "," + task[c_assignee] + ")",
        'camunda:type': "external",
        'camunda:topic': "exchangeKeys",
        'bpmn:documentation': { "$t": JSON.stringify(documentation)},
        'bpmn:incoming': { "$t": incEdge},
        'bpmn:outgoing': { "$t": outEdge}
      }

      var xPos;

      if(position == c_before){
        xPos = shape[c_bounds].x;
      }else{
        xPos = (+shape[c_bounds].x + shiftOffset).toString();
      }
  
      var newPseudoTaskShape = {
        id: taskId + "_di",
        bpmnElement: taskId,
        'dc:Bounds': {
          x: xPos,
          y: shape[c_bounds].y,
          width: shape[c_bounds].width,
          height: shape[c_bounds].height
        }
      }

      var sourceObject;
      var targetObject;

      if(position == c_before){
        sourceObject = newPseudoTask.id;
        targetObject = task.id;
      }else{
        sourceObject = task.id;
        targetObject = newPseudoTask.id;
      }
  
      var newPseudoEdge = {
        id: edgeId,
        sourceRef: sourceObject,
        targetRef: targetObject
      }
  
      var newPseudoEdgeShape = {
        id: edgeId + "_di",
        bpmnElement: edgeId,
        'di:waypoint': 
        [ {
            x: (+shape[c_bounds].x + (+shape[c_bounds].width)).toString(),
            y: (+shape[c_bounds].y + (+shape[c_bounds].height / 2)).toString()
          },
          {
            x: (+shape[c_bounds].x + shiftOffset).toString(),
            y: (+shape[c_bounds].y + (+shape[c_bounds].height / 2)).toString()
          }
        ],
      }

      traversedProcess = startTraversing(startTask, dataInSphere, bp, c_forward, true, undefined, undefined, undefined);

      // shift all BP-Elements to the right to insert the Task in the specific Spot
      shiftAllBPElements(bp,traversedProcess,task, position);
  

      for(var seq of sequenceFlowArray){
        if(position == c_before){
          if(task.id == seq.targetRef){
            seq.targetRef = taskId;
          }
        }
        if(position == c_after){
          if(task.id == seq.sourceRef){
            seq.sourceRef = taskId;
          }
        }
      }

      for(var tempTask of taskArray){
          if(tempTask.id == task.id){
            if(position == c_before){
              tempTask[c_in][c_nodeId] = newPseudoEdge.id;

            }else{
              tempTask[c_out][c_nodeId] = newPseudoEdge.id;
            }
          }
      }
      
      taskArray.push(newPseudoTask);
      edgeArray.push(newPseudoEdgeShape);
      sequenceFlowArray.push(newPseudoEdge);
      
      var taskArrayOnly = [];
      var userTaskArrayOnly = [];
      var serviceTaskArrayOnly = [];
      for(var tempTask of taskArray){
        if(tempTask[c_type] != null){
          serviceTaskArrayOnly.push(tempTask);
        }
        if(tempTask[c_assignee] != null){
          userTaskArrayOnly.push(tempTask);
        }
        if(tempTask[c_type] == null && tempTask[c_assignee] == null){
          taskArrayOnly.push(tempTask);
        }
      }

      bp[c_definitions][c_diagram][c_diagramPlane][c_edge] = edgeArray;
      bp[c_definitions][c_process][c_sequenceFlow] = sequenceFlowArray;
      bp[c_definitions][c_process][c_tasks] = taskArrayOnly;
      bp[c_definitions][c_process][c_userTasks] = userTaskArrayOnly;
      bp[c_definitions][c_process][c_serviceTasks] = serviceTaskArrayOnly;
      bp[c_definitions][c_diagram][c_diagramPlane][c_shape].push(newPseudoTaskShape);

      for(var edge of bp[c_definitions][c_diagram][c_diagramPlane][c_edge]){
        if(position == c_before){
          if(edge.bpmnElement == newPseudoTask[c_in][c_nodeId]){
            edge[c_waypoint][edge[c_waypoint].length-1].x = newPseudoTaskShape[c_bounds].x;
          }
        }
        if(position == c_after){
          if(edge.bpmnElement == newPseudoTask[c_out][c_nodeId]){
            edge[c_waypoint][0].x = (+newPseudoTaskShape[c_bounds].x + (+newPseudoTaskShape[c_bounds].width)).toString();
          }
        }
      }

      return newPseudoTask;
  
    }catch(e){
      console.error(methodName, e);
    }
  
}

function findOccurenceInString(_input, _symbolFrom, _symbolTo){
  let methodName = ">>> [findOccurenceInString]: ";  

  try{

    var startIndex = _input.indexOf(_symbolFrom);
    var endIndex = _input.indexOf(_symbolTo);

    return _input.slice(startIndex+1,endIndex);

  }catch(e){
    console.error(methodName, e);
  }

}

function shiftAllBPElements(bp,traversedBP,task){
let methodName = ">>> [shiftAllBPElements]: ";   
  
  try{

    var passedObjects = traversedBP.slice(0);
    var currentObject;
    var reachedStartObject = false;
    var dataKeysForIteration = [c_inData,c_outData];
    var edgeKeysForIteration = [c_in, c_out];

    // shift all Elements till the task is found or till a corresponding gate was reached 
    //(all elements in this path of the gate have to be shifted as well)
    while(reachedStartObject == false){

      currentObject = passedObjects.pop();
      if(currentObject.bpObject.id == task.id){
        reachedStartObject = true;
      }

      // shift all Tasks,Gateways,Events,Data Objects and Annotations

      for(var shape of bp[c_definitions][c_diagram][c_diagramPlane][c_shape]){

        if(shape.bpmnElement == currentObject.bpObject.id){
            shape[c_bounds].x = (+shape[c_bounds].x + shiftOffset).toString();
          if(shape[c_label] != null){
            shape[c_label][c_bounds].x = (+shape[c_label][c_bounds].x + shiftOffset).toString(); 
          }

        }

        if(currentObject.bpObject[c_outData] != null){
          var outgoingData = currentObject.bpObject[c_outData];
  
          if(!Array.isArray(outgoingData)){
            outgoingData = [outgoingData];
          }

          outgoingData.forEach(outgoingDataObject => {

            var foundInitiatingDataObject = currentObject.initiatingDataObject.find( result => result.id == outgoingDataObject[c_target][c_nodeId]);
  
            if(shape.bpmnElement == outgoingDataObject[c_target][c_nodeId] && foundInitiatingDataObject != undefined){
                shape[c_bounds].x = (+shape[c_bounds].x + shiftOffset).toString();
                if(shape[c_label] != null){
                  shape[c_label][c_bounds].x = (+shape[c_label][c_bounds].x + shiftOffset).toString();
                }  
            }
          });
        }

        var annotations = getAnnotation(currentObject.bpObject, bp);

        if(annotations != undefined){

          var associations = bp[c_definitions][c_process][c_association];

          for(var annotation of annotations){
            if(shape.bpmnElement == annotation.id){
              shape[c_bounds].x = (+shape[c_bounds].x + shiftOffset).toString();

              var foundAssociation = associations.find( e => e.sourceRef == currentObject.bpObject.id && annotation.id == e.targetRef);
              bp[c_definitions][c_diagram][c_diagramPlane][c_edge].forEach( edge => {

                if(edge.bpmnElement == foundAssociation.id){
                  for(var point of edge[c_waypoint]){
                    point.x = (+shape[c_bounds].x).toString();
                  }
                }
              });
            }  
          } 
        }

      }

      

      var currentShape = bp[c_definitions][c_diagram][c_diagramPlane][c_shape].find( result => currentObject.bpObject.id == result.bpmnElement);

      bp[c_definitions][c_diagram][c_diagramPlane][c_edge].forEach( edge => {

        edgeKeysForIteration.forEach( key => {

          if(currentObject.bpObject[key] != null){
            var currentObjectEdges = currentObject.bpObject[key];

            if(!Array.isArray(currentObjectEdges)){
              currentObjectEdges = [currentObjectEdges];
            }

            currentObjectEdges.forEach(currentObjectEdge => {

              if(currentObjectEdge[c_nodeId] == edge.bpmnElement){

                var sum = 0;
                for(var singleWayPoint of edge[c_waypoint]){
                  sum = sum + (+singleWayPoint.x);
                }

                var mean = sum / edge[c_waypoint].length;
                edge[c_waypoint].forEach( singleWayPoint => {
                  if(key == c_in){
                    if((+singleWayPoint.x) >= mean){
                      // Objekt ist ein Gateway, deshalb x-Koord zur Mitte des Shapes setzen
                      if(currentObject.type == c_exclusive || currentObject.type == c_parallel){
                        if(currentObjectEdges.length > 1){
                          singleWayPoint.x = (+currentShape[c_bounds].x + (+currentShape[c_bounds].width / 2)).toString();
                        }else{
                          singleWayPoint.x = currentShape[c_bounds].x;
                        }
                      // Objekt ist ein Task/Data, deshalb x-Koord gleich dem x-Koord des Shapes setzen
                      }else{
                        singleWayPoint.x = currentShape[c_bounds].x;
                      }
                    }           
                  }else{
                    if((+singleWayPoint.x) <= mean){
                      // Objekt ist ein Gateway, deshalb x-Koord zur Mitte des Shapes setzen
                      if(currentObject.type == c_exclusive || currentObject.type == c_parallel){
                        if(currentObjectEdges.length > 1){
                          singleWayPoint.x = (+currentShape[c_bounds].x + (+currentShape[c_bounds].width / 2)).toString();
                        }else{
                          singleWayPoint.x = ((+currentShape[c_bounds].x) + (+currentShape[c_bounds].width)).toString();
                        }
                      // Objekt ist ein Task/Data, deshalb x-Koord gleich dem x-Koord des Shapes setzen
                      }else{
                        singleWayPoint.x = ((+currentShape[c_bounds].x) + (+currentShape[c_bounds].width)).toString();
                      }
                    }
                  }
                });

                if(edge[c_label] != null){
                  edge[c_label][c_bounds].x = (+edge[c_waypoint][0].x + 30).toString(); 
                }  
              }
            });
          }
      });
        dataKeysForIteration.forEach( key => {

          if(currentObject.bpObject[key] != null){

            var dataEdges = currentObject.bpObject[key];

            if(!Array.isArray(dataEdges)){
              dataEdges = [dataEdges];
            }

            dataEdges.forEach( dataEdge => {

              if(edge.bpmnElement == dataEdge.id){

                var sum = 0;
                for(var singleWayPoint of edge[c_waypoint]){
                  sum = sum + (+singleWayPoint.x);
                } 
                var mean = sum / edge[c_waypoint].length;
                
                edge[c_waypoint].forEach( singleWayPoint => {
                  if(key == c_outData){
                    if((+singleWayPoint.x) <= mean){
                      singleWayPoint.x = (+currentShape[c_bounds].x + (+currentShape[c_bounds].width / 2)).toString();
                    }
                  }else{
                    if((+singleWayPoint.x) >= mean){
                      singleWayPoint.x = (+currentShape[c_bounds].x + (+currentShape[c_bounds].width / 2)).toString();
                    }
                  }
                });

                if(edge[c_label] != null){
                  edge[c_label][c_bounds].x = (+edge[c_label][c_bounds].x + shiftOffset).toString(); 
                } 
              }
            });          
            }
          });




        });
      }

      // Adjust all data edges wich are incoming and outgoing from data objects

      var onlyTaskArray = bp[c_definitions][c_process][c_tasks];
      var onlyUserTaskArray = bp[c_definitions][c_process][c_userTasks];
      if(!Array.isArray(onlyTaskArray)){
        onlyTaskArray = [onlyTaskArray];
      }
      if(!Array.isArray(onlyUserTaskArray)){
        onlyUserTaskArray = [onlyUserTaskArray];
      }

      var taskArray = onlyTaskArray.concat(onlyUserTaskArray);

      var edgeArray = bp[c_definitions][c_diagram][c_diagramPlane][c_edge];
      if(!Array.isArray(edgeArray)){
        edgeArray = [edgeArray];
      }

      var shapeArray = bp[c_definitions][c_diagram][c_diagramPlane][c_shape];
      if(!Array.isArray(shapeArray)){
        shapeArray = [shapeArray];
      }

      var direction = null;

      // for each Task
      taskArray.forEach( task => {

        dataKeysForIteration.forEach( key => {

          if(task[key] != null){
            var dataEdges = task[key];
            if(!Array.isArray(dataEdges)){
              dataEdges = [dataEdges];
            }

            dataEdges.forEach( edge => {

              var dataObject = shapeArray.find( shape => {

                if(key == c_outData){
                  direction = c_target;
                }else{
                  direction = c_source;
                }

                if(edge[direction][c_nodeId] == shape.bpmnElement){
                  return shape;
                }
              });
              
              var taskShape = shapeArray.find( shape => task.id == shape.bpmnElement);
              var edgeShape = edgeArray.find( result => result.bpmnElement == edge.id);
          
              if(key == c_outData){
                
                var sum = 0;
                for(var singleWayPoint of edgeShape[c_waypoint]){
                  sum = sum + (+singleWayPoint.x);
                } 
                var mean = sum / edgeShape[c_waypoint].length;
                
                edgeShape[c_waypoint].forEach( singleWayPoint => {
                  if((+singleWayPoint.x) <= mean){
                    singleWayPoint.x = (+taskShape[c_bounds].x + (+taskShape[c_bounds].width / 2)).toString();
                  }
                });

                edgeShape[c_waypoint][edgeShape[c_waypoint].length -1].x = ((+dataObject[c_bounds].x) + ((+dataObject[c_bounds].width) / 2)).toString();
                edgeShape[c_waypoint][edgeShape[c_waypoint].length -1].y = ((+dataObject[c_bounds].y) + ((+dataObject[c_bounds].height) / 2)).toString();

              }else{

                var sum = 0;
                for(var singleWayPoint of edgeShape[c_waypoint]){
                  sum = sum + (+singleWayPoint.x);
                } 
                var mean = sum / edgeShape[c_waypoint].length;
                
                edgeShape[c_waypoint].forEach( singleWayPoint => {
                  if((+singleWayPoint.x) >= mean){
                    singleWayPoint.x = (+taskShape[c_bounds].x + (+taskShape[c_bounds].width / 2)).toString();
                  }
                });

                edgeShape[c_waypoint][0].x = ((+dataObject[c_bounds].x) + ((+dataObject[c_bounds].width) / 2)).toString();
                edgeShape[c_waypoint][0].y = ((+dataObject[c_bounds].y) + ((+dataObject[c_bounds].height) / 2)).toString();  
              }

            });
          }
        });
      });

      
    
  }catch(e){
    console.error(methodName, e);
  }
}

function createWrapper(bp, task){
let methodName = ">>> [createWrapper]: ";  

  try{

      var assignee = findOccurenceInString(task.name, '[', ']');

      var found = allParticipants.find( e => e.name == assignee);

      if(found == undefined){
        allParticipants.push({name: assignee});
      }

      var shortenedAssignee;
      var updatedName;
      var oldName = task.name;

      // shorten the names

      switch (assignee) {
        case "General Practitioner":

          shortenedAssignee = "GP"
          updatedName = oldName.replace(assignee, shortenedAssignee);        
          break;
        
        case "Diagnosis Institute":

          shortenedAssignee = "DI"
          updatedName = oldName.replace(assignee, shortenedAssignee); 
          break;
        
        case "Rehabilitation Specialist":

          shortenedAssignee = "R"
          updatedName = oldName.replace(assignee, shortenedAssignee);
          break;

        case "Insurance Company":

          shortenedAssignee = "I"
          updatedName = oldName.replace(assignee, shortenedAssignee);
          break;

      }

      var newWrapperTask = {
        "id": task.id,
        "name": task.name,
        "camunda:formKey": "embedded:deployment:formInput.html",
        "camunda:assignee": assignee,
        "bpmn:documentation": {'$t': undefined},
        "bpmn:outgoing": task[c_out],
        "bpmn:incoming": task[c_in]
      }
      
      if(task[c_outData] != null){
        newWrapperTask[c_outData] = task[c_outData];    
      }

      if(task[c_inData] != null){
        newWrapperTask[c_inData] = task[c_inData];
        newWrapperTask[c_property] = task[c_property];    
      }

      if(bp[c_definitions][c_process][c_userTasks] == null){
        bp[c_definitions][c_process][c_userTasks] = [];
      }

      if(!Array.isArray(bp[c_definitions][c_process][c_userTasks])){
        bp[c_definitions][c_process][c_userTasks] = [bp[c_definitions][c_process][c_userTasks]];
      }

      var userTaskExists = bp[c_definitions][c_process][c_userTasks].find( currentUserTask => currentUserTask.id == newWrapperTask.id);

      if(userTaskExists == undefined){
        bp[c_definitions][c_process][c_userTasks].push(newWrapperTask);
      }

      return newWrapperTask;

  }catch(e){
    console.error(methodName, e);
  }

}

function createID(bp, mode){
let methodName = ">>> [createID]: ";  

  try {
    if(mode == c_tasks){  
      var result = 'Task_';
      var onlyTaskArray = bp[c_definitions][c_process][c_tasks];
      var onlyUserTaskArray = bp[c_definitions][c_process][c_userTasks];
      if(!Array.isArray(onlyTaskArray)){
        onlyTaskArray = [onlyTaskArray];
      }
      if(!Array.isArray(onlyUserTaskArray)){
        onlyUserTaskArray = [onlyUserTaskArray];
      }

      var elementsArray = onlyTaskArray.concat(onlyUserTaskArray);

    }

    if(mode == c_serviceTasks){

      var result = "Service_"

      var serviceTaskArray = bp[c_definitions][c_process][c_serviceTasks];

      if(serviceTaskArray != undefined){
        if(!Array.isArray(serviceTaskArray)){
          serviceTaskArray = [serviceTaskArray];
        }
      }else{
        serviceTaskArray = [];
      }

      var elementsArray = serviceTaskArray;

    }

    if(mode == c_sequenceFlow){
      var result = 'SequenceFlow_';
      var elementsArray = bp[c_definitions][c_process][c_sequenceFlow];
    }  
    var valid = false;

    while(!valid){
      valid = true;
      result += crypto.randomBytes(4).toString('hex').slice(1);
      elementsArray.find( element => {
        if(element.id == result){
          valid = false;
        }
      });
    }

    return result;

  }catch(e){
    console.error(methodName, e);
  }
}

function debug(message){
  if(debugMode==true){
    console.log(message);
  }
}